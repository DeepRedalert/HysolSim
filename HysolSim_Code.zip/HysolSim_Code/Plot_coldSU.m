function D1=Plot_coldSU(Mode,Add_path)
Mode;
global Type
load Type.mat
if Type==0
    load Day1_over_Const.mat
elseif Type==1
    load Day1_over_Step.mat
elseif Type==2
    load Day1_over_Real.mat
elseif Type==3
    load Day1_over_Quad.mat
end

% global SD OP Xa XA  Xax  LFRsim POW POWeT_pos_pow LFR

set(0,'DefaultLineLineWidth',6)
set(0,'DefaultLineMarkerSize',10)
set(0,'DefaultAxesFontSize',18);
set(0,'DefaultTextFontSize',20);

SetGraphics;

if Type==0
    cd iMAGE/Type0/Day1_hybrid/
elseif Type==1
    cd iMAGE/Type1/Day1_hybrid/
elseif Type==2
    cd iMAGE/Type2/Day1_hybrid/
elseif Type==3
    cd iMAGE/Type3/Day1_hybrid/
end


%figure('units','normalized','outerposition',[0 0 1 1])
figure(1)
figure1=figure(1);
axes1 = axes('Parent',figure1); % Create axes
plot(Xaxis_water,lfr_I_sec(:,1:length(Xaxis_water)))
legend('Solar radiation','fontsize',20)
grid on
xlabel('Time (Hrs)','FontWeight','bold')
ylabel('w/m^2','FontWeight','bold')
if Type==0
    title('Constant radiation','FontWeight','bold')
elseif Type==1
    ylim([300 800])
    title('Step change radiation','FontWeight','bold')
elseif Type==2
    title('Real-time radiation','FontWeight','bold')
elseif Type==3
    title('Quadratic radiation','FontWeight','bold')
end
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(1).jpg');

%figure('visible','off');
%figure('units','normalized','outerposition',[0 0 1 1])
figure(2)
figure1=figure(2);
axes1 = axes('Parent',figure1); % Create axes
plot(SD.IP_mwin_time/3600,SD.IP_mwin)
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('Mass flow rate  kg/s','FontWeight','bold');
grid on
%xlim(axes1,[1 9]);
l=legend('$\dot{m}_{(w,i,SD)}$','Location','southeast','fontsize',20);
set(l,'Interpreter','Latex');
title('Mass flow rate of water entering SD from dearator','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(2).jpg');

%figure('visible','off')
%figure('units','normalized','outerposition',[0 0 1 1])
figure(3)
figure1=figure(3);
axes1 = axes('Parent',figure1); % Create axes
% plot(Xaxis(:,1:end),TW_in_HX)
plot(XA.X_SG,TW_in_HX);
hold on
% plot(Xaxis(:,1:end),Twin_SD)            %problem step down
plot(Twin_SD_axis/3600,Twin_SD)            %problem step down
% hold off
xlabel('Time (Hrs)','FontWeight','bold')
ylabel('Temperature ^oC','FontWeight','bold')
grid on
hx = legend('$T_{W,i,HX}$','$T_{W,i,SD}$','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex')
title('Temperature profile of water in HX & SD','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(3).jpg');

%figure('visible','off')
%figure('units','normalized','outerposition',[0 0 1 1])
figure(4)
figure1=figure(4);
axes1 = axes('Parent',figure1); % Create axes
plot(Xaxis,OP.SCF(15,1:end),'b','LineWidth',3)
hold on
plot(Xaxis,OP.HT_Temp(:,1:end),'g','LineWidth',3)
hold on
plot(Xa.X_SH,OP.SH(1,:),'k','LineWidth',3)
hold on
plot(XA.X_SG,OP.SG_temp,'m','LineWidth',3)
hold on
plot(Xa.X_PH,OP.PH(2,1:end),'r','LineWidth',3)
hold on
plot(Xaxis,OP.LT_Temp(1:end),'c','LineWidth',3)
hold off
grid on
hx=legend('$T_{(o,o,PTC)}$','$T_{(o,o,HT)}$','$T_{(o,o,SH)}$','$T_{(o,o,SG)}$','$T_{(o,o,PH)}$','$T_{(o,o,LT)}$','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex')
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('Temperature ^oC','FontWeight','bold');
ylim([0 400])
title('Output Oil Temprature profile','FontWeight','bold')
text(XA.X_SG(1),OP.SG_temp(1),'\bf \leftarrow SG connected cold startup','FontSize',11)
text(Xa.X_SH(1),OP.SH(1,1),'\bf \leftarrow SH connected cold startup','FontSize',11)
text(Xa.X_PH(1),OP.PH(2,1),'\bf \leftarrow PH connected cold startup','FontSize',11)
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(4).jpg');

%figure('units','normalized','outerposition',[0 0 1 1])
figure(5)
figure1=figure(5);
axes1 = axes('Parent',figure1); % Create axes
plot(Xa.X_SH,OP.sh_tsout,'b','LineWidth',3)
hold on
plot(XA.X_SG,OP.SGTw,'g','LineWidth',3)
hold on
plot(Xa.X_PH,OP.ph_twout,'r','LineWidth',3)         %see graph
hold on
plot(Xax.SD/3600,drum_Twat(:,1:end),'c','LineWidth',3)
hold on
plot(Xax.SD_steam/3600,drum_Tsteam(:,1:end),'m','LineWidth',3)
hold off
grid on
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('Temperature ^oC','FontWeight','bold');
hx=legend('$T_{(st,o,SH)}$','$T_{(w,SG)}$','$T_{(w,o,PH)}$','$T_{(w,SD)}$','$T_{(st,SD)}$','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex')
title('Water/Steam outlet temperature profile','FontWeight','bold')
text(Xa.X_SH(1),OP.sh_tsout(1),'\bf \leftarrow SH connected cold startup','FontSize',11)
text(XA.X_SG(1),OP.SGTw(1),'\bf \leftarrow SG connected cold startup','FontSize',11)
text(Xa.X_PH(1),OP.ph_twout(1),'\bf \leftarrow PH connected cold startup','FontSize',11)
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(5).jpg');

%figure('units','normalized','outerposition',[0 0 1 1])
figure(6)
figure1=figure(6);
axes1 = axes('Parent',figure1); % Create axes
plot(Xaxis,OP.SCF(1,1:end),'m','LineWidth',3)
hold on
plot(Xaxis,OP.SCF(8,1:end),'b','LineWidth',3)
hold on
plot(Xaxis,OP.SCF(15,1:end),'g','LineWidth',3)
hold off
grid on
ylim([0 400])
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('Temperature ^oC','FontWeight','bold');
hx=legend('T(o,o,33m)','T(o,o,264m)','T(o,o,500m)','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex')
title('PTC oil outlet temperature profile','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(6).jpg');

%figure('units','normalized','outerposition',[0 0 1 1])
figure(7)
figure1=figure(7);
axes1 = axes('Parent',figure1); % Create axes
plot(time_lfr(1:LFR_n),LFRsim.T(1:LFR_n,10),'b')
hold on
plot(time_lfr(1:LFR_n),LFRsim.T(1:LFR_n,end/2),'--g')
hold on
plot(time_lfr(1:LFR_n),LFRsim.T(1:LFR_n,end),'--r')
hold off
grid on
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('Temperature ^oC','FontWeight','bold');
hx=legend('T(w,o,33m)','T(st,o,240m)','T(st,o,480m)','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex')
title('LFR steam/water profile','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(7).jpg');

%figure('units','normalized','outerposition',[0 0 1 1])
figure(8)
figure1=figure(8);
axes1 = axes('Parent',figure1); % Create axes
plot(time_lfr(1:LFR_n), LFRsim.h(1:LFR_n,10),'b')
hold on
plot(time_lfr(1:LFR_n), LFRsim.h(1:LFR_n,end/2),'g')
hold on
plot(time_lfr(1:LFR_n), LFRsim.h(1:LFR_n,end),'r')
hold off
grid on
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('kJ/kg','FontWeight','bold');
hx=legend('T(w,o,33m)','T(st,o,240m)','T(st,o,480m)','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex')
title('Enthalpy water in the LFR','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(8).jpg');

%figure('units','normalized','outerposition',[0 0 1 1])
figure(9)
figure1=figure(9);
axes1 = axes('Parent',figure1); % Create axes
plot(time_lfr(1:LFR_n), LFRsim.P(1:LFR_n,10),'b')
hold on
plot(time_lfr(1:LFR_n), LFRsim.P(1:LFR_n,end/2),'g')
hold on
plot(time_lfr(1:LFR_n), LFRsim.P(1:LFR_n,end),'r')
hold off
grid on
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('bar','FontWeight','bold');
ylim([39 46])
hx=legend('T(w,o,33m)','T(st,o,240m)','T(st,o,480m)','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex')
title('Pressure profile of LFR','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(9).jpg');

%figure('units','normalized','outerposition',[0 0 1 1])
figure(10)
figure1=figure(10);
axes1 = axes('Parent',figure1); % Create axes
plot(time_lfr(1:LFR_n), LFRsim.Qst(1:LFR_n,10),'b')
hold on
plot(time_lfr(1:LFR_n), LFRsim.Qst(1:LFR_n,end/2),'g')
hold on
plot(time_lfr(1:LFR_n), LFRsim.Qst(1:LFR_n,end),'r')
hold off
grid on
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('Steam quality','FontWeight','bold');
ylim([-0.05 0.35])
hx=legend('Q(st,o,33m)','Q(st,o,240m)','Q(st,o,480m)','Location','northeast','fontsize',20);
set(hx,'Interpreter','latex')
title('Steam quality of LFR','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(10).jpg');

%figure('units','normalized','outerposition',[0 0 1 1])
figure(11)
figure1=figure(11);
axes1 = axes('Parent',figure1); % Create axes
plot(XA.X_SG,OP.SG_pressure)
hold on
plot(Xaxis_water,drum_pressure)
hold off
xlabel('Time (Hrs)','FontWeight','bold')
ylabel('bar','FontWeight','bold')
grid on
title('Pressure Profiles','FontWeight','bold')
hx = legend('$P_{SG}$','$P_{SD}$','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(11).jpg');

%figure('units','normalized','outerposition',[0 0 1 1])
figure(12)      %see graph
figure1=figure(12);
axes1 = axes('Parent',figure1); % Create axes
plot(Xaxis_water,LFR_msteam_out_nos_pipe)%by Xaxis_water min to hrs
hold on
plot(Xaxis,POW.LFR)%Drum.msout;
hold on
plot(Xaxis,POW.ms_SG)%SG.msgen
hold on
plot(Xaxis,POW.ms_turb)%Drum.msout+SG.msgen
hold off
xlabel('Time (Hrs)','FontWeight','bold')
ylabel('kg/s','FontWeight','bold')
grid on
title('Flowrate of steam Profile','FontWeight','bold')
hx = legend('$\dot{m}_{(st,o,LFR)}$','$\dot{m}_{(st,o,SD)}$','$\dot{m}_{(st,o,SG)}$','$\dot{m}_{(st,o,SH)}$','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(12).jpg');

%figure('units','normalized','outerposition',[0 0 1 1])
figure(13)
figure1=figure(13);
axes1 = axes('Parent',figure1); % Create axes
plot(Xax.POW/3600,POWeT_pos_pow.powgen)
xlabel('Time(Hrs)','FontWeight','bold')
ylabel('MWe','FontWeight','bold')
legend('Total Power','Location','southeast','fontsize',20)
grid on
ylim([0 0.7])
title('Power Generation Electrical','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(13).jpg');

%figure('units','normalized','outerposition',[0 0 1 1])
figure(14)
figure1=figure(14);
axes1 = axes('Parent',figure1); % Create axes
plot(time_lfr(1:LFR_n),LFR.IP_mwin)
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('Mass flow rate  kg/s','FontWeight','bold');
grid on
l=legend('$\dot{m}_{(w,i,LFR)}$','fontsize',20);
set(l,'Interpreter','Latex');
title('Mass flow rate of water in to LFR','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(14).jpg');

%figure('units','normalized','outerposition',[0 0 1 1])
figure(15)
figure1=figure(15);
axes1 = axes('Parent',figure1); % Create axes
plot(XA.X_SD/3600,OP.Drum_Temp_wat)  %drum_Twat
hold on
plot(XA.X_SD/3600,OP.LFR_Temp)   %LFR_temp_fluid
hold off
grid on
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('Temperature oC','FontWeight','bold');
legend('Drum temperature','LFR temperature','Location','southeast','fontsize',20)
title('Drum & LFR water/steam temp profile (At o/p)','FontWeight','bold');
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(15).jpg');

%figure('units','normalized','outerposition',[0 0 1 1])
figure(16)
figure1=figure(16);
axes1 = axes('Parent',figure1); % Create axes
colororder({'m','b'})
yyaxis left
plot(XA.X_SG,OP.SG_temp,'m','LineWidth',3)
ylim([0 300])
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('Temperature ^oC','FontWeight','bold');
%set(gca, 'YColor','m')
yyaxis right
plot(XA.X_SG,OP.SG_pressure,'b','LineWidth',3)
ylim([0 45])
ylabel('SG Pressure (bar)','FontWeight','bold');
grid on
title('SG Output Oil Temprature profile and SG pressure','FontWeight','bold')
%set(gca, 'YColor','b')
hx=legend('$T_{(o,o,SG)}$','$P_{SG}$','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex', 'fontsize', 20)
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(16).jpg');

%figure('units','normalized','outerposition',[0 0 1 1])
figure(17)
figure1=figure(17);
axes1 = axes('Parent',figure1); % Create axes
plot(Xaxis,OP.LT_Temp(1:end),'c','LineWidth',3);
% plot1=plot(Xaxis,OP.LT_Temp(1:end),'c','LineWidth',3);
% datatip(plot1,'DataIndex',885,'Location','northwest');
% datatip(plot1,'DataIndex',8650,'Location','northwest');
% ylabel('Temperature ^oC','FontWeight','bold')
hold on
%yyaxis right
plot(XA.X_SG,TW_in_HX,'b','LineWidth',3);
% datatip(plot2,'DataIndex',885,'Location','southeast');
% datatip(plot2,'DataIndex',8650,'Location','southeast');
ylabel('Temperature ^oC','FontWeight','bold')
hold off
xlabel('Time,hours','FontWeight','bold')
grid on
ylim([0 300])
hx = legend('$T_{(o,o,LT)}$','$T_{W,i,HX}$','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex', 'fontsize', 20)
title('LT oil outlet temp & HX water inlet temp','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(17).jpg');

%figure('units','normalized','outerposition',[0 0 1 1])
figure(18)
figure1=figure(18);
axes1 = axes('Parent',figure1);
plot(Xa.X_SH_U,OP.SHU)
%plot(Xa.X_SH,OP.SHU)
hold on
plot(XA.X_SG,OP.SGU,'m','LineWidth',3)
hold on
plot(Xa.X_PH,OP.PHU,'r','LineWidth',3)
hold off
grid on
ylim([100 1000])
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('W/(m^2 K)','FontWeight','bold');
hx=legend('$U_{SH}$','$U_{SG}$','$U_{PH}$','Location','northeast','fontsize',20);
set(hx,'Interpreter','latex')
title('Heat transfer coefficient','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(18).jpg');

%figure('units','normalized','outerposition',[0 0 1 1])
figure(19)
figure1=figure(19);
axes1 = axes('Parent',figure1); % Create axes
plot(time_lfr(1:LFR_n), LFRsim.Ck(1:LFR_n,10),'b')
hold on
plot(time_lfr(1:LFR_n), LFRsim.Ck(1:LFR_n,end/2),'g')
hold on
plot(time_lfr(1:LFR_n), LFRsim.Ck(1:LFR_n,end),'r')
hold off
grid on
ylim([0.25 0.65])
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('Ck','FontWeight','bold');
hx=legend('Ck(w,o,33m)','Ck(st,o,240m)','Ck(st,o,480m)','Location','northeast','fontsize',20);
set(hx,'Interpreter','latex')
title('Friction factor profile of LFR','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(19).jpg');

%figure('units','normalized','outerposition',[0 0 1 1])
figure(20)
figure1=figure(20);
axes1 = axes('Parent',figure1); % Create axes
plot(time_lfr(1:LFR_n), LFRsim.rho(1:LFR_n,10),'b')
hold on
plot(time_lfr(1:LFR_n), LFRsim.rho(1:LFR_n,end/2),'g')
hold on
plot(time_lfr(1:LFR_n), LFRsim.rho(1:LFR_n,end),'r')
hold off
grid on
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('Density (kg/m^3)','FontWeight','bold');
hx=legend('rho(w,o,33m)','rho(st,o,240m)','rho(st,o,480m)','Location','northeast','fontsize',20);
set(hx,'Interpreter','latex')
title('Density profile of LFR pipe','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(20).jpg');

%figure('units','normalized','outerposition',[0 0 1 1])
figure(21)
figure1=figure(21);
axes1 = axes('Parent',figure1); % Create axes
plot(XA.X_SG,OP.SGhtube,'r','LineWidth',3)%not same 
hold on
plot(XA.X_SG,OP.SGhshell,'g','LineWidth',3)
hold on
plot(Xa.X_SH_U,OP.SHhtube,'b','LineWidth',3)
%plot(Xa.X_SH,OP.SHhtube,'b','LineWidth',3)
hold on
plot(Xa.X_SH_U,OP.SHhshell,'k','LineWidth',3)
%plot(Xa.X_SH,OP.SHhshell,'k','LineWidth',3)
hold on
plot(Xa.X_PH,OP.PHhtube,'m','LineWidth',3)
hold on
plot(Xa.X_PH,OP.PHhshell,'c','LineWidth',3)
hold off
grid on
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('W/(m^2 K)','FontWeight','bold');
ylim([0 10000])
hx=legend('$htube_{SG}$','$hshell_{SG}$','$htube_{SH}$','$hshell_{SH}$','$htube_{PH}$','$hshell_{PH}$','Location','northeast','fontsize',20);
set(hx,'Interpreter','latex')
title('Heat transfer coefficient shell side and tube side','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(21).jpg');



%Steam

figure(22)
figure1=figure(22);
axes1 = axes('Parent',figure1);
plot(Xax.SD/3600,drum_hsteam,'b','LineWidth',3)
grid on
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('kJ/kg','FontWeight','bold');
ylim([0 3000]);
title('Drum enthalpy of steam','FontWeight','bold')
hx=legend('$h_{(st,SD)}$','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex', 'fontsize', 20)
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(22).jpg');

figure(23)
figure1=figure(23);
axes1 = axes('Parent',figure1); % Create axes
plot(Xax.SD/3600,drum_row_st,'m','LineWidth',3)
grid on
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('kg/m^3','FontWeight','bold');
title('Drum density of steam','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(23).jpg');

figure(24)
figure1=figure(24);
axes1 = axes('Parent',figure1); 
plot(Xax.SD/3600,drum_Mass_steam,'b','LineWidth',3)
grid on
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('kg','FontWeight','bold');
title('Drum Mass of steam','FontWeight','bold')
hx=legend('$m_{(st,SD)}$','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex', 'fontsize', 20)
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(24).jpg');


%Water

figure(25)
figure1=figure(25);
axes1 = axes('Parent',figure1); 
plot(Xax.SD/3600,drum_Mass_wat,'b','LineWidth',3)
grid on
ylim([0 4500])
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('kg','FontWeight','bold');
title('Drum Mass of water','FontWeight','bold')
hx=legend('$m_{(w,SD)}$','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex', 'fontsize', 20)
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(25).jpg');


figure(26)
figure1=figure(26);
axes1 = axes('Parent',figure1);
plot(Xax.SD/3600,drum_hwat,'b','LineWidth',3)
grid on
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('kJ/kg','FontWeight','bold');
ylim([0 1000])
title('Drum enthalpy of water','FontWeight','bold')
hx=legend('$h_{(w,SD)}$','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex', 'fontsize', 20)
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(26).jpg');

D1=1;
cd(Add_path)
end