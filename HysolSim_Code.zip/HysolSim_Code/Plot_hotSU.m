function D2=Plot_hotSU(Mode,Add_path)

global Type test

if Type==0
    load Day2_over_Const.mat
elseif Type==1
    load Day2_over_Step.mat
elseif Type==2
    load Day2_over_Real.mat
elseif Type==3
    load Day2_over_Quad.mat
end

set(0,'DefaultLineLineWidth',6)
set(0,'DefaultLineMarkerSize',10)
set(0,'DefaultAxesFontSize',18);
set(0,'DefaultTextFontSize',20);

SetGraphics;

if Type==0
    cd iMAGE/Type0/Day2_hybrid/
elseif Type==1
    cd iMAGE/Type1/Day2_hybrid/
elseif Type==2
    cd iMAGE/Type2/Day2_hybrid/
elseif Type==3
    cd iMAGE/Type3/Day2_hybrid/
end


%figure('units','normalized','outerposition',[0 0 1 1])
figure(31)
figure31=figure(31);
axes1 = axes('Parent',figure31); % Create axes
plot(Xaxis_water,lfr_I_sec(:,1:length(Xaxis_water)))
legend('Solar radiation','fontsize',20)
grid on
xlabel('Time (Hrs)','FontWeight','bold')
ylabel('w/m^2','FontWeight','bold')
if Type==0
    title('Constant radiation','FontWeight','bold')
elseif Type==1
    title('Step change radiation','FontWeight','bold')
elseif Type==2
    title('Real-time radiation','FontWeight','bold')
elseif Type==3
    title('Quadratic radiation','FontWeight','bold')
end
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(31).jpg');
% exportgraphics(gcf,'figure(31).jpg','Resolution',300)


% figure('units','normalized','outerposition',[0 0 1 1])
figure(32)
figure1=figure(32);
axes1 = axes('Parent',figure1); % Create axes
plot(SD.IP_mwin_time/3600,SD.IP_mwin)
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('Mass flow rate  kg/s','FontWeight','bold');
grid on
l=legend('$\dot{m}_{(w,i,SD)}$','Location','southeast','fontsize',20);
set(l,'Interpreter','Latex');
title('Mass flow rate of water entering SD from LFR','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(32).jpg');
% exportgraphics(gcf,'figure(32).jpg','Resolution',300)


%figure('units','normalized','outerposition',[0 0 1 1])
figure(33)
figure1=figure(33);
axes1 = axes('Parent',figure1); % Create axes
%plot(Xaxis(:,1:end),TW_in_HX,'-.b')
plot(XA.X_SG,TW_in_HX,'-p');
hold on
%plot(Xaxis(:,1:end),Twin_SD,'--r')            %problem step down
plot(Twin_SD_axis/3600,Twin_SD,'-') 
hold off
xlabel('Time (Hrs)','FontWeight','bold')
ylabel('Temperature ^oC','FontWeight','bold')
grid on
hx = legend('$T_{W,i,HX}$','$T_{W,i,SD}$','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex')
ylim([30 80])
title('Temperature profile of water in HX & SD','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(33).jpg');
% exportgraphics(gcf,'figure(33).jpg','Resolution',300)


%figure('units','normalized','outerposition',[0 0 1 1])
figure(34)
figure1=figure(34);
axes1 = axes('Parent',figure1); % Create axes
plot(Xaxis,OP.SCF(15,1:end),'b','LineWidth',3)
hold on
plot(Xaxis,OP.HT_Temp(:,1:end-1),'g','LineWidth',3)
hold on
plot(Xa.X_SH,OP.SH(1,1:end-1),'k','LineWidth',3)
hold on
plot(XA.X_SG,OP.SG_temp,'m','LineWidth',3)
hold on
plot(Xa.X_PH,OP.PH(2,1:end-1),'r','LineWidth',3)
hold on
plot(Xaxis,OP.LT_Temp(1:end-1),'c','LineWidth',3)
hold off
grid on
ylim([0 400])
hx=legend('$T_{(o,o,PTC)}$','$T_{(o,o,HT)}$','$T_{(o,o,SH)}$','$T_{(o,o,SG)}$','$T_{(o,o,PH)}$','$T_{(o,o,LT)}$','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex')
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('Temperature ^oC','FontWeight','bold');
title('Output Oil Temprature profile','FontWeight','bold')
text(XA.X_SG(1),OP.SG_temp(1),'\bf \leftarrow SG connected 2nd day','FontSize',11)
text(Xa.X_SH(1),OP.SH(1,1),'\bf \leftarrow SH connected 2nd day','FontSize',11)
text(Xa.X_PH(1),OP.PH(2,1),'\bf \leftarrow PH connected 2nd day','FontSize',11)
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(34).jpg');
% exportgraphics(gcf,'figure(34).jpg','Resolution',300)


%figure('units','normalized','outerposition',[0 0 1 1])
figure(35)
figure1=figure(35);
axes1 = axes('Parent',figure1); % Create axes
plot(Xa.X_SH,OP.sh_tsout,'b','LineWidth',3)
hold on
plot(XA.X_SG,OP.SGTw(1:end-1),'g','LineWidth',3)
hold on
plot(Xa.X_PH,OP.ph_twout,'r','LineWidth',3)         %see graph
hold on
plot(Xax.SD/3600,drum_Twat(:,1:end),'c','LineWidth',3)
hold on
plot(Xax.SD_steam/3600,drum_Tsteam(:,1:end),'m','LineWidth',3)
hold off
grid on
ylim([0 350])
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('Temperature ^oC','FontWeight','bold');
hx=legend('$T_{(st,o,SH)}$','$T_{(w,SG)}$','$T_{(w,o,PH)}$','$T_{(w,SD)}$','$T_{(st,SD)}$','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex')
title('Water/Steam outlet temperature profile','FontWeight','bold')
text(Xa.X_SH(1),OP.sh_tsout(1),'\bf \leftarrow SH connected 2nd day','FontSize',11)
text(XA.X_SG(1),OP.SGTw(1),'\bf \leftarrow SG connected 2nd day','FontSize',11)
text(Xa.X_PH(1),OP.ph_twout(1),'\bf \leftarrow PH connected 2nd day','FontSize',11)
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(35).jpg');
% exportgraphics(gcf,'figure(35).jpg','Resolution',300)


%figure('units','normalized','outerposition',[0 0 1 1])
figure(36)
figure1=figure(36);
axes1 = axes('Parent',figure1); % Create axes
plot(Xaxis,OP.SCF(1,1:end),'m','LineWidth',3)
hold on
plot(Xaxis,OP.SCF(8,1:end),'b','LineWidth',3)
hold on
plot(Xaxis,OP.SCF(15,1:end),'g','LineWidth',3)
hold off
grid on
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('Temperature ^oC','FontWeight','bold');
hx=legend('T(o,o,33m)','T(o,o,264m)','T(o,o,500m)','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex')
title('PTC oil outlet temperature profile','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(36).jpg');
% exportgraphics(gcf,'figure(36).jpg','Resolution',300)


%figure('units','normalized','outerposition',[0 0 1 1])
figure(37)
figure1=figure(37);
axes1 = axes('Parent',figure1); % Create axes
plot(time_lfr(1:LFR_n),LFRsim.T(1:LFR_n,10),'b')
hold on
plot(time_lfr(1:LFR_n),LFRsim.T(1:LFR_n,end/2),'--g')
hold on
plot(time_lfr(1:LFR_n),LFRsim.T(1:LFR_n,end),'--r')
hold off
grid on
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('Temperature ^oC','FontWeight','bold');
hx=legend('T(w,o,33m)','T(st,o,240m)','T(st,o,480m)','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex')
title('LFR steam/water profile','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(37).jpg');
% exportgraphics(gcf,'figure(37).jpg','Resolution',300)


%figure('units','normalized','outerposition',[0 0 1 1])
figure(38)
figure1=figure(38);
axes1 = axes('Parent',figure1); % Create axes
plot(time_lfr(1:LFR_n), LFRsim.h(1:LFR_n,10),'b')
hold on
plot(time_lfr(1:LFR_n), LFRsim.h(1:LFR_n,end/2),'g')
hold on
plot(time_lfr(1:LFR_n), LFRsim.h(1:LFR_n,end),'r')
hold off
grid on
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('kJ/kg','FontWeight','bold');
hx=legend('T(w,o,33m)','T(st,o,240m)','T(st,o,480m)','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex')
title('Enthalpy water in the LFR','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(38).jpg');
% exportgraphics(gcf,'figure(38).jpg','Resolution',300)


%figure('units','normalized','outerposition',[0 0 1 1])
figure(39)
figure1=figure(39);
axes1 = axes('Parent',figure1); % Create axes
plot(time_lfr(1:LFR_n), LFRsim.P(1:LFR_n,10),'b')
hold on
plot(time_lfr(1:LFR_n), LFRsim.P(1:LFR_n,end/2),'g')
hold on
plot(time_lfr(1:LFR_n), LFRsim.P(1:LFR_n,end),'r')
hold off
grid on
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('bar','FontWeight','bold');
ylim([39 46])
hx=legend('T(w,o,33m)','T(st,o,240m)','T(st,o,480m)','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex')
title('Pressure profile of LFR','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(39).jpg');
% exportgraphics(gcf,'figure(39).jpg','Resolution',300)


%figure('units','normalized','outerposition',[0 0 1 1])
figure(40)
figure1=figure(40);
axes1 = axes('Parent',figure1); % Create axes
plot(time_lfr(1:LFR_n), LFRsim.Qst(1:LFR_n,10),'b')
hold on
plot(time_lfr(1:LFR_n), LFRsim.Qst(1:LFR_n,end/2),'g')
hold on
plot(time_lfr(1:LFR_n), LFRsim.Qst(1:LFR_n,end),'r')
hold off
grid on
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('Steam quality','FontWeight','bold');
ylim([-0.05 0.35])
hx=legend('Q(st,o,33m)','Q(st,o,240m)','Q(st,o,480m)','Location','northeast','fontsize',20);
set(hx,'Interpreter','latex')
title('Steam quality of LFR','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(40).jpg');
% exportgraphics(gcf,'figure(40).jpg','Resolution',300)


%figure('units','normalized','outerposition',[0 0 1 1])
figure(41)
figure1=figure(41);
axes1 = axes('Parent',figure1); % Create axes
plot(XA.X_SG,OP.SG_pressure(1:end-1))
hold on
plot(Xaxis_water,drum_pressure)
hold off
xlabel('Time (Hrs)','FontWeight','bold')
ylabel('bar','FontWeight','bold')
grid on
title('Pressure Profiles','FontWeight','bold')
hx = legend('$P_{SG}$','$P_{SD}$','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(41).jpg');
% exportgraphics(gcf,'figure(41).jpg','Resolution',300)


%figure('units','normalized','outerposition',[0 0 1 1])
figure(42)      %see graph
figure1=figure(42);
axes1 = axes('Parent',figure1); % Create axes
plot(Xaxis_water,LFR_msteam_out_nos_pipe)%by Xaxis_water min to hrs
hold on
plot(Xaxis,POW.LFR)%Drum.msout;
hold on
plot(Xaxis,POW.ms_SG)%SG.msgen
hold on
plot(Xaxis,POW.ms_turb)%Drum.msout+SG.msgen
hold off
xlabel('Time (Hrs)','FontWeight','bold')
ylabel('kg/s','FontWeight','bold')
grid on
title('Flowrate of steam Profile','FontWeight','bold')
hx = legend('$\dot{m}_{(st,o,LFR)}$','$\dot{m}_{(st,o,SD)}$','$\dot{m}_{(st,o,SG)}$','$\dot{m}_{(st,o,SH)}$','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(42).jpg');
% exportgraphics(gcf,'figure(42).jpg','Resolution',300)


%figure('units','normalized','outerposition',[0 0 1 1])
figure(43)
figure1=figure(43);
axes1 = axes('Parent',figure1); % Create axes
plot(Xax.POW/3600,POWeT_pos_pow.powgen)
xlabel('Time(Hrs)','FontWeight','bold')
ylabel('MWe','FontWeight','bold')
legend('Total Power','Location','southeast','fontsize',20)
grid on
ylim([0 0.7])
title('Power Generation Electrical','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(43).jpg');
% exportgraphics(gcf,'figure(43).jpg','Resolution',300)


%figure('units','normalized','outerposition',[0 0 1 1])
figure(44)
figure1=figure(44);
axes1 = axes('Parent',figure1); % Create axes
plot(time_lfr(1:LFR_n),LFR.IP_mwin)
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('Mass flow rate  kg/s','FontWeight','bold');
grid on
l=legend('$\dot{m}_{(w,i,LFR)}$','fontsize',20);
set(l,'Interpreter','Latex');
title('Mass flow rate of water in to LFR','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(44).jpg');
% exportgraphics(gcf,'figure(44).jpg','Resolution',300)


%figure('units','normalized','outerposition',[0 0 1 1])
figure(45)
figure1=figure(45);
axes1 = axes('Parent',figure1); % Create axes
plot(XA.X_SD/3600,OP.Drum_Temp_wat)  %drum_Twat
hold on
plot(XA.X_SD/3600,OP.LFR_Temp)   %LFR_temp_fluid
hold off
grid on
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('Temperature oC','FontWeight','bold');
legend('Drum temperature','LFR temperature','Location','southeast','fontsize',20)
title('Drum & LFR water/steam temp profile (At o/p)','FontWeight','bold');
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(45).jpg');
% exportgraphics(gcf,'figure(45).jpg','Resolution',300)


figure(46)
figure1=figure(46);
axes1 = axes('Parent',figure1); % Create axes
colororder({'m','b'})
yyaxis left
plot(XA.X_SG,OP.SG_temp,'m','LineWidth',3)
ylim([0 300])
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('Temperature ^oC','FontWeight','bold');
%set(gca, 'YColor','m')
yyaxis right
plot(XA.X_SG,OP.SG_pressure(1:end-1),'b','LineWidth',3)
ylim([0 45])
ylabel('SG Pressure (bar)','FontWeight','bold');
grid on
title('SG Output Oil Temprature profile and SG pressure','FontWeight','bold')
hx=legend('$T_{(o,o,SG)}$','$P_{SG}$','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex', 'fontsize', 20)
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(46).jpg');
% exportgraphics(gcf,'figure(46).jpg','Resolution',300)


%figure('units','normalized','outerposition',[0 0 1 1])
figure(47)
figure1=figure(47);
axes1 = axes('Parent',figure1); % Create axes
plot(Xaxis,OP.LT_Temp(1:end-1),'c','LineWidth',3);
%plot1=plot(Xaxis,OP.LT_Temp(1:end),'c','LineWidth',3);
% datatip(plot1,'DataIndex',885,'Location','northwest');
% datatip(plot1,'DataIndex',8650,'Location','northwest');
% ylabel('Temperature ^oC','FontWeight','bold')
hold on
%yyaxis right
plot(XA.X_SG,TW_in_HX,'b','LineWidth',3);
% datatip(plot2,'DataIndex',885,'Location','southeast');
% datatip(plot2,'DataIndex',8650,'Location','southeast');
ylabel('Temperature ^oC','FontWeight','bold')
hold off
xlabel('Time,hours','FontWeight','bold')
grid on
ylim([0 300])
hx = legend('$T_{(o,o,LT)}$','$T_{W,i,HX}$','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex', 'fontsize', 20)
title('LT oil outlet temp & HX water inlet temp','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(47).jpg');
% exportgraphics(gcf,'figure(47).jpg','Resolution',300)


%figure('units','normalized','outerposition',[0 0 1 1])
figure(48)
figure1=figure(48);
axes1 = axes('Parent',figure1);
plot(Xa.X_SH_U,OP.SHU)
%plot(Xa.X_SH,OP.SHU)
hold on
plot(XA.X_SG,OP.SGU,'m','LineWidth',3)
hold on
plot(Xa.X_PH,OP.PHU,'r','LineWidth',3)
hold off
grid on
ylim([100 1000])
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('W/(m^2 K)','FontWeight','bold');
hx=legend('$U_{SH}$','$U_{SG}$','$U_{PH}$','Location','northeast','fontsize',20);
set(hx,'Interpreter','latex')
title('Heat transfer coefficient','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(48).jpg');
% exportgraphics(gcf,'figure(48).jpg','Resolution',300)

%figure('units','normalized','outerposition',[0 0 1 1])
figure(49)
figure1=figure(49);
axes1 = axes('Parent',figure1); % Create axes
plot(time_lfr(1:LFR_n), LFRsim.Ck(1:LFR_n,10),'b')
hold on
plot(time_lfr(1:LFR_n), LFRsim.Ck(1:LFR_n,end/2),'g')
hold on
plot(time_lfr(1:LFR_n), LFRsim.Ck(1:LFR_n,end),'r')
hold off
grid on
ylim([0.25 0.65])
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('Ck','FontWeight','bold');
hx=legend('Ck(w,o,33m)','Ck(st,o,240m)','Ck(st,o,480m)','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex')
title('Friction factor profile of LFR','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(49).jpg');
% exportgraphics(gcf,'figure(49).jpg','Resolution',300)


%figure('units','normalized','outerposition',[0 0 1 1])
figure(50)
figure1=figure(50);
axes1 = axes('Parent',figure1); % Create axes
plot(time_lfr(1:LFR_n), LFRsim.rho(1:LFR_n,10),'b')
hold on
plot(time_lfr(1:LFR_n), LFRsim.rho(1:LFR_n,end/2),'g')
hold on
plot(time_lfr(1:LFR_n), LFRsim.rho(1:LFR_n,end),'r')
hold off
grid on
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('Density (kg/m^3)','FontWeight','bold');
hx=legend('rho(w,o,33m)','rho(st,o,240m)','rho(st,o,480m)','Location','northeast','fontsize',20);
set(hx,'Interpreter','latex')
title('Density profile of LFR pipe','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(50).jpg');
% exportgraphics(gcf,'figure(50).jpg','Resolution',300)


%figure('units','normalized','outerposition',[0 0 1 1])
figure(51)
figure1=figure(51);
axes1 = axes('Parent',figure1); % Create axes
plot(XA.X_SG,OP.SGhtube,'r','LineWidth',3)%not same 
hold on
plot(XA.X_SG,OP.SGhshell,'g','LineWidth',3)
hold on
plot(Xa.X_SH_U,OP.SHhtube,'b','LineWidth',3)
%plot(Xa.X_SH,OP.SHhtube,'b','LineWidth',3)
hold on
plot(Xa.X_SH_U,OP.SHhshell,'k','LineWidth',3)
%plot(Xa.X_SH,OP.SHhshell,'k','LineWidth',3)
hold on
plot(Xa.X_PH,OP.PHhtube,'m','LineWidth',3)
hold on
plot(Xa.X_PH,OP.PHhshell,'c','LineWidth',3)
hold off
grid on
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('W/(m^2 K)','FontWeight','bold');
ylim([0 10000])
hx=legend('$htube_{SG}$','$hshell_{SG}$','$htube_{SH}$','$hshell_{SH}$','$htube_{PH}$','$hshell_{PH}$','Location','northeast','fontsize',20);
set(hx,'Interpreter','latex')
title('Heat transfer coefficient shell side and tube side','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(51).jpg');
% exportgraphics(gcf,'figure(51).jpg','Resolution',300)

%Steam
figure(52)
figure1=figure(52);
axes1 = axes('Parent',figure1);
plot(Xax.SD/3600,drum_hsteam,'b','LineWidth',3)
grid on
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('kJ/kg','FontWeight','bold');
ylim([0 3000]);
title('Drum enthalpy of steam','FontWeight','bold')
hx=legend('$h_{(st,SD)}$','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex', 'fontsize', 20)
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(52).jpg');


figure(53)
figure1=figure(53);
axes1 = axes('Parent',figure1); % Create axes
plot(Xax.SD/3600,drum_row_st,'m','LineWidth',3)
grid on
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('kg/m^3','FontWeight','bold');
title('Drum density of steam','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(53).jpg');

figure(54)
figure1=figure(54);
axes1 = axes('Parent',figure1); % Create axes
plot(Xax.SD/3600,drum_Mass_steam,'b','LineWidth',3)
grid on
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('kg','FontWeight','bold');
title('Drum Mass of steam','FontWeight','bold')
hx=legend('$m_{(st,SD)}$','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex', 'fontsize', 20)
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(54).jpg');


%Water

figure(55)
figure1=figure(55);
axes1 = axes('Parent',figure1); 
plot(Xax.SD/3600,drum_Mass_wat,'b','LineWidth',3)
grid on
ylim([0 4500])
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('kg','FontWeight','bold');
title('Drum Mass of water','FontWeight','bold')
hx=legend('$m_{(w,SD)}$','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex', 'fontsize', 20)
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(55).jpg');


figure(56)
figure1=figure(56);
axes1 = axes('Parent',figure1);
plot(Xax.SD/3600,drum_hwat,'b','LineWidth',3)
grid on
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('kJ/kg','FontWeight','bold');
ylim([0 1000])
title('Drum enthalpy of water','FontWeight','bold')
hx=legend('$h_{(w,SD)}$','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex', 'fontsize', 20)
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(56).jpg');

D2=1;
cd(Add_path)
end