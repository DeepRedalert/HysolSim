%Function file for Steam drum. Due to mixing the inside temperature will change.
%Due to mixing the oinside temp of SD will change
%Primary:
%Input: Dearator water
%Output: Mass of steam out to Mixer
%Secondary: 
%Input: LFR 2 phase mixer
%Output: Water to LFR

%%

function [dt]= SD_dynamics_updated_ode(t,SDintial)

global   Drum  LFRsim  LFR Dear SD flag Type
%SD_intial=[Drum.Mass  Drum.Mass_wat  Drum.Mass_steam  Drum.hwat   Drum.hst];
Drum.Mass_wat1=SDintial(2);         %Mass of water in SD
Drum.Mass_steam1=SDintial(3);       %Mass of steam in SD
Drum.hwat1=SDintial(4);             %Enthalpy of water in Sd
Drum.hst1=SDintial(5);              %Enthalpy of steam in Sd

Drum.mwin=(1-LFRsim.phase)*LFR.total_mw_in;                 %Mass of water in to the SD from LFR
Drum.msin=LFRsim.phase*LFR.total_mw_in;                     %Mass flow rate of steam entering SD from LFR
Drum.row_wat=(XSteam('rho_pT',Drum.press,Drum.Temp_wat));   %rho_pT	Density as a function of pressure and temperature.
%Above line it not used in this file.. Main file I have to see..VNU
%% To find Density of water present in SD
if Drum.Temp_wat > floor(Drum.int_Tsat-1) && Drum.Temp_wat< ceil(Drum.int_Tsat+0.5)  %This is for band purpose**between Subcooled and Saturation
    Drum.row_w=XSteam('rhoL_T',Drum.int_Tsat);               %rhoL_T=Saturated liquid density    %Density of water present in SD
else %IF not saturated
    Drum.row_w=XSteam('rho_ph',Drum.press,Drum.hwat1*10^-3); %May be giving some odd no  %rho_ph=Density as a function of pressure and enthalpy %Density of water present in SD
    if  Drum.row_w <800
        Drum.row_w=XSteam('rhoL_T',Drum.Temp_wat);           %From phase rule, it is a const value =Drum.Temp_wat
    end
end

Drum.msgen=0;

Drum.VLwat=Drum.Mass_wat1/Drum.row_w;                      %Total volume of water in the drum
%row_w=Drum.row_w;

%% To find density of steam present in SD and specific enthalpy of fresh water flowing into the SD
if LFRsim.phase > 0                                        %Steam quality
    Drum.hwintoSD = (XSteam('hL_p',LFR.press_end))*1000;   %%%Drum.hwin_drum=hwin*1000;
    Drum.hst1_in= (XSteam('hV_p',LFR.press_end))*1000 ;
    Drum.hsout=(XSteam('hV_p',LFR.press_end))*1000 ;
    row_s=Drum.Mass_steam1/(Drum.Vsys-Drum.VLwat);         %Drum.Vsys-Drum.VLwat=Vol of steam
    Drum.Vsteam=Drum.Mass_steam1/row_s;
    hwx=XSteam('hL_p',Drum.press);
    hs=0;
    hc=(hs-hwx)*1000;
else
    Drum.hwintoSD=Drum.hwin_SD;                     %1. Specific enthalpy of fresh water flowing into the SD
    Drum.hst1_in=0 ;
    Drum.hsout= 0;
    row_s=Drum.Mass_steam1/(Drum.Vsys-Drum.VLwat);  %2. row_s=Drum.Mass_steam1/(2);
    Drum.Vsteam=Drum.Mass_steam1/row_s;
    hwx=Drum.hwat1;                                 %Specific enthalpy of water present in SD
    hs=0;
    hc=(hs-hwx);
end
Drum.rho_st=row_s;                                  %Density of steam present in SD
%% Equation 13 in IECER paper
%Drum.press=XSteam('p_hrho', round(Drum.hst1*10^(-3),3),round(Drum.rho_st,3));  %For real time it is not working     %SD pressure, it was taking to o much time if N>3
% if Type==0 || Type==1 || Type==3
    Drum.press=XSteam('p_hrho', round(Drum.hst1*10^(-3),1),round(Drum.rho_st,1));  %For constant solar radiation     %SD pressure, it was taking to o much time if N>3
% else
%     Drum.press=XSteam('p_hrho', Drum.hst1*10^-3,Drum.rho_st);                      %For real time solar radiation
% end
%% equation 14 in IECER paper
msgenout_drum=max(Drum.valve_constant*sqrt(max(Drum.press-Drum.exit_press,0)),0);%1st max is not needed, check it


if Drum.press > SD.press_st                         %If Drum pressure > Setpoint pressure, 1 bar band
    Drum.msout=msgenout_drum;

    if  Drum.Mass_steam1 < 1                        %There is no steam
        Drum.msout=0;
    end
else
    Drum.msout=0;                                   %Mass of steam out from SD
end

%% Toal mass balance: Water(dMwdt) + Steam(dMsdt)
dMassdt=Dear.mwin+Drum.mwin - Drum.msout-Drum.mwout+(LFRsim.phase*LFR.total_mw_in)+Drum.msgen;%Drum.msgen=0 ,**
%% Mass balance of water, Equation 9 in IECER paper
dMwdt=((1-LFRsim.phase)*LFR.total_mw_in)-Drum.mwout+Dear.mwin- Drum.msgen;
%% Mass balance of steam, Equation 10 in IECER paper
dMsdt=(LFRsim.phase*LFR.total_mw_in)-Drum.msout+ Drum.msgen;
%% Enthalpy of water, Equation 11 in IECER paper
dhw_drum=((Dear.mwin*Dear.hwin)-(Drum.mwout*Drum.hwat1)+(Drum.mwin*Drum.hwintoSD)-(Drum.hwat1* dMwdt))/Drum.Mass_wat1; % See your note
%% Enthalpy of steam, Equation no 12 in IECER paper
%*if LFRsim.phase > 0                                 %Steam quality
dhsdt=((Drum.msin*Drum.hst1_in)-(Drum.msout*Drum.hst1)-(Drum.hst1*dMsdt))/(Drum.rho_st*(Drum.Vsys-(Drum.Mass_wat1/Drum.row_w)));
%*else
%*  dhsdt=0;
%*end
%%
dt=[dMassdt; dMwdt; dMsdt; dhw_drum; dhsdt];        %Return all the states

end