%Funtion file for calculating Enthalpy of oil
%Polynomial has been taken form Therminol-PV1 PDF

function Enthalpy=h_oil(T)

 Enthalpy=(0.0014*T^2)+(1.49681*T)-18.17454;  %KJ/KG

end
