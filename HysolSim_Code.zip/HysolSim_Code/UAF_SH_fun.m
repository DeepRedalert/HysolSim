%% Superheater HTC
%For calculation of U we need two HTC,one is shell side another is tube side.
%_she=Shell side
%_t= tuibe side

function [UAF,hi_t_turb,ho_sh,F,U]=UAF_SH_fun(mo,Toi,Too,mw,Tsi,Tso,Pres)

global SH

if isreal(Tsi)~=1
    disp('Tsi contain imaginary in fun UAF_SH_fun')
    pause
end
if isreal(Tso)~=1
    disp('Tso contain imaginary in fun UAF_SH_fun')
    pause
end
if isnan(Tsi)==1
    disp('Tsi contain NAN in fun UAF_SH_fun')
    pause
end
if isnan(Tso)==1
    disp('Tso contain NAN in fun UAF_SH_fun')
    pause
end

Ts_av=(Tsi+Tso)/2;              %Avg steam temperature=(Temp of steam coming in+Temp of steam coming out from PH)/2
Toil_av=(Toi+Too)/2;            %Avg oil temperature=(Temp of Oil coming out from SG+Temp of Oil from coming out from PH)/2

% All units in meters
tube_ID=SH.tube_ID;             %Tube input diameter
ri_t=tube_ID/2;                 %Tube input radius
tube_OD= SH.tube_OD;            %Tube output diameter
ro_t=tube_OD/2;                 %Tube outer radius
L_t=SH.tube_length;             %Tube length
No_tub= SH.No_tubes;            %Total no of tubes
SH.nopass_t=2;                  %Number of passes?
Area=pi*tube_OD*L_t*(No_tub*2); %Area of heat transfer    m^2
Therma=49;                      %Thermal conductivity

%% Tube side HTC calculation: Petukhov & Kirillov correlation
%TUBE side LAMINAR flow
Pres=round(Pres,3);
den_t=XSteam('rho_pT',Pres,Ts_av) ;         %Density of oil, Here pressure=
cpW_t=( XSteam('Cp_pT',Pres,Ts_av) );
cp_t=cpW_t*1000;                            %Sp. Heat capacity

dyn_vis_t=XSteam('my_pT',Pres,Ts_av);       %Dynamic viscosity

if isnan(dyn_vis_t)==1
    disp('Dynamic viscosity Contain NAN in SH UAF')
    pause
end

Th_t=XSteam('tc_pT',Pres,Ts_av) ;           %Thermal conductivity

if  isnan(cpW_t)==1                         %If cpW_t is empty       
    cpW_t=( XSteam('CpV_p',Pres) );
    cp_t=cpW_t*1000;                            %Sp. Heat capacity
    den_t=XSteam('rhoV_p',Pres) ;  
    Th_t=XSteam('tcV_p',Pres) ;
end
if isnan(cp_t)==1
    disp('Sp. Heat capacity Contain NAN in SH UAF')
    pause
end

kvis_t=dyn_vis_t/den_t;                     %Kinematic viscocity

At_t=(pi*(tube_ID^2))/4;                    %Area of tube side
Atp_t=(No_tub*At_t)/SH.nopass_t;
Gt_t=(mw /Atp_t);                           %Mass velocity of tube=Mass flow rate of water or steam in/Atp
Ut_t=Gt_t/den_t;                            %Velocity
Ren_t=(Ut_t*den_t*tube_ID)/dyn_vis_t;       %Reynolds number on tube side
Pr_t=(cp_t*dyn_vis_t)/Th_t;                 %Prandtl number=(Sp. Heat capacity*Dynamic viscosity)/Thermal conductivity

%TUBE side TURBULENT flow
f_t=(3.64*log10(Ren_t)-3.28)^-2;                                                 %f=Friction factor
NUs_t=( (f_t/2)*Ren_t*Pr_t)/(1.07+(12.7*((f_t/2)^(1/2)))*((Pr_t^(2/3))-1));      %Nusselt number
hi_t_turb=(NUs_t*Th_t)/tube_ID;                                                  %Tube side HTC

%% Shell side HTC calculation
Di_s= SH.shell_ID;              %Shell side inner diameter
ls=(SH.tube_length/13);         %Baffle spacing
Dotl=0.3;                       %ds-Bundle clearence
Pn=0.0238; 
Pt=Pn;                          %Pitch/square

den_sh=density_oil(Toil_av);    %Denisity of oil
cp_sh=Cp_sf(Toil_av);           %Specific heat capacity of fluid on shell side
Kvis_sh=Kin_vis(Toil_av);       %Kinetic viscocity
Th_sh=Ther_con(Toil_av);        %Thermal conductivity on shell side
dyn_vis_sh= (Kvis_sh *den_sh);  %Dynamic Viscocity of fluid on shell side

%% Calculation of HTC on shell side by 2 method

%1. Paper Kern method
%  Cl=Pn-(2*(tube_OD/2));
%  As_sh=(Di_s*Cl*ls)/Pt;
%  Gs_sh=mo/As_sh;
%  De_sh=(4*((Pt^2)-((pi*tube_OD^2)/4)))/(pi*tube_OD);
%  Res_sh=(De_sh*Gs_sh)/dyn_vis_sh;
%  Nu_sh=0.36*(Res_sh^0.55)*(((cp_sh*dyn_vis_sh)/Th_sh)^0.33);%*((ub/uw)^0.14);
%  ho_sh1=(Nu_sh*Th_sh)/De_sh;

%Overall HTC calculation by paper karn method
% U1=( (ro_t/ri_t)*(1/hi_t_turb) )+(1/ ho_sh1)+((ro_t*log(ro_t/ri_t))/Therma);
% U1=1/U1;

%2. BELL Delaware method
sm=ls*(Di_s-Dotl+(((Dotl-tube_OD)/Pn)*(Pt-tube_OD)));
Re_s=(tube_OD*mo)/(dyn_vis_sh*sm);                      %Reynolds number=(tube outer diameter*Mass flow rate of fluid on shell side)/(Dyn viscocity*Sm)
j1= 0.185*(Re_s^-0.324);                                %Colburn j-factor
Cs=cp_sh  ;                                             %Specific heat capacity of fluid shell side

ho_sh=j1*Cs*(mo/sm)*(Th_sh/(Cs*dyn_vis_sh));            %Shell side HTC

%% Overall HTC calculation by Delaware method
U=((ro_t/ri_t)*(1/hi_t_turb) )+(1/ ho_sh)+((ro_t*log(ro_t/ri_t))/(Therma));
U=1/U;

if isreal(U)~=1
    disp('HTC of SH contain imaginary no')
    pause
end
if isnan(U)==1
    disp('HTC of SH contain NAN')
    pause
end
%% Correction factor of SH
Rr=(Toi-Too)/(Tso-Tsi);             %Range on shell side temperature/Range on tube side temperature
Ss=(Tso-Tsi)/(Toi-Tsi);             %Range on tube side temerature/Maximum temperature diff on HX

%Sometime num_F may come zero, at that case check Rr & Ss. When log(.) term
%or Rr becomes 1, it will give zero. When Rr becomes 1 , Deno_F will be
%zero. and than NAN will come. Rr*Ss should be less than 1, otherwise
%Imaginaary number will come.

num_F=(sqrt((Rr^2)+1))*log ((1-Ss)/(1-(Rr*Ss)));      %Numerator of correction factor

F_d1=2-(Ss*(Rr+1-(sqrt(Rr^2+1))));
F_d2=2-(Ss*(Rr+1+(sqrt(Rr^2+1))));
Deno_F=(Rr-1)*log(F_d1/F_d2);                         %Denominator of correction factor

F=num_F/Deno_F;                                         %Correction factor

if isreal(F)~=1
    disp('HTC of SH contain imaginary no')
    %pause
end
if isnan(F)==1
    disp('HTC of SH contain NAN')
    pause
end
%%
%SH_fact=F;

if F>1
    F=1;
elseif F<0
    F=0;
else

end

if U <0
    U=0;
end

%% Final UAF
UAF=U*Area*F;           %By delawara method
%UA1=U1*Area*F;         %By kern paper method

UAF=UAF*10^-3;
end