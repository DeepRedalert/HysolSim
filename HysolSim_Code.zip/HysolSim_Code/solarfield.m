%Function file for Solar Collector Field (PTC)

function [dT] =solarfield(t,T)
t
global  PTC_scf stef_const PTC_scf_OD scfhp PTC_SCF LT

%PTC_scf.grid(1)=LT.Toout;

TF=T(1:PTC_scf.grid);                                   %Fluid temperture
TA=T(((PTC_scf.grid)+1):(2*PTC_scf.grid));              %Absorber pipe  temperture
TE=T(((2*PTC_scf.grid)+1):(PTC_scf.grid*3));            %Glass envelope temperature
TEg=TE;

if PTC_scf_OD==0             %In main script file PTC_scf_OD=1, So this is only for generalized purpose
    for j=1:1:PTC_scf.grid
        if (j==1)
            dF(j)=0;
        else
            dF(j)=0;
        end
        dA(j)=0;
        dE(j)=0;
    end
else
    for j=1:1:PTC_scf.grid                       %PTC_scf.grid=15

        den_htf=density_oil(TF(j));              %Density of fluid
        cp_htf=Cp_sf(TF(j));                     %Specific heat
        kvis_htf=Kin_vis(TF(j));                 %Kinematic viscosity  %m^2/s
        Th_htf=Ther_con(TF(j));                  %Thermal conductivity

        der_den_htf=dbyden_sf(TF(j));            %Derivative of density of oil
        der_cp_htf=dbyCp_sf(TF(j));              %Derivative Specific heat capacity (Cp)

        dia_ab=PTC_scf.rai*2;                    %Diameter of absorber pipe                             m

        VOL_htf=PTC_scf.moil/den_htf;                   %Volumatric flow of heat transfer fluid     m^3/s    (Volume/Time) or (Area*velocity)
        vel_htf=(1.2734*VOL_htf)/(dia_ab^2);            %Velocity of heat transfer fluid            m/s      Volumetric flow rate for cylindrical pipe =π*(d/2)²*v, where d is the pipe diameter
        renold_htf=((2*PTC_scf.rai)*vel_htf)/kvis_htf;  %Reynolds number = (Fluid velocity x Internal pipe diameter) / Kinematic viscosity, unitless
        pr_no=(cp_htf*kvis_htf*den_htf)/Th_htf;         %Prandtl number=(Specific heat*Kinemetic viscocity*Density)/Thermal conductivity, m^2/s
        PTC_scf.hp=0.023*((renold_htf)^0.8)*(pr_no^0.4)*(Th_htf/dia_ab);    %Heat transfer coefficient of Heat transfer fluid   W/(m^2 oC)   , Dittus bolter equation

        scfhp(j)=PTC_scf.hp;
        %Partial fraction of 1a(PTC)
        one=PTC_scf.Aai*cp_htf*TF(j)*der_den_htf;       %w.r.t density of HTF
        two=PTC_scf.Aai*TF(j)*den_htf*der_cp_htf;       %w.r.t density of specific heat capacity
        three=PTC_scf.Aai*cp_htf*den_htf;               %w.r.t density of Fluid temperture
        denom=one+two+three;

        if (j==1)
            TAb=TA(j);
            Thtf=TF(j);
            dF(j)=((PTC_scf.moil*cp_htf*((PTC_scf.Toilin-TF(j))/PTC_scf.dx))+(PTC_scf.hp*PTC_scf.pai*(TAb-Thtf)))/denom;
        else
            TAb=TA(j);
            Thtf=TF(j);
            dF(j)=((PTC_scf.moil*cp_htf*((TF(j-1)-TF(j))/PTC_scf.dx))+(PTC_scf.hp*PTC_scf.pai*(TAb-Thtf)))/denom;
        end

        TEgi=TEg(j);                                %Temperature of Glass envelope

        dA(j)=((PTC_scf.hp*PTC_scf.pai*(Thtf-TAb))...
            -((stef_const/((1/PTC_scf.ea)+(((1-PTC_scf.ee)/PTC_scf.ee)*(PTC_scf.rao/PTC_scf.rei))))...
            *(PTC_scf.pao*(((TAb+273.15)^4)-((TEgi+273.15)^4))))...
            +(PTC_scf.I*PTC_scf.effici*PTC_scf.aper_wid))...
            /(PTC_scf.den_abso*PTC_scf.CPabso*PTC_scf.Aai);

        dE(j)=(((stef_const/((1/PTC_scf.ea)...
            +((1-PTC_scf.ee)/PTC_scf.ee)*(PTC_scf.rao/PTC_scf.rei)))*(PTC_scf.pai*(((TAb+273.15)^4)-((TEgi+273.15)^4))))...
            -(stef_const*PTC_scf.ee*PTC_scf.peo*(((TEgi+273.15)^4)-((PTC_scf.Tsky+273.15)^4)))-(PTC_scf.hair*PTC_scf.peo*(TEgi-PTC_scf.Tair)))...
            /(PTC_scf.den_gla*PTC_scf.ce_gla*PTC_scf.Ae);
    end
end
dT_SCF=[ dF dA  dE];

dT=[dT_SCF]';           %Return dF,dA,dE

end

