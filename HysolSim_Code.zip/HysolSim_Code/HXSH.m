%Function file for Super Heater

function [dHX_SH] =HXSH(t,Tr)

format shortG

global SH HX SD SG LFR Drum HT Mode

if isreal(Tr)~=1
    disp('Tr contain imaginary in fun HXSH')
    pause
end

SH.Toout=Tr(1); %1.325
SH.Tsout=Tr(2); %1.250 prb in this



if isnan(Tr)==1    %Element of T is empty or not
    Tr
    SH
    %SG
    %pause
end
%Mass flow rate of oil to SH, SG, PH is same i.e. Mass flow rate of oil out from HT
    SH.moil=HT.moilout;
%%
if  Drum.press>SD.press_st     %If drum pressure> Setpoint pressure

    LFR.Tfluid_phase=XSteam('T_ph',Drum.press,Drum.hst*10^-3);  %LFR.Tfluid;??
    SG.LFR_Tsout=(SG.Twater+LFR.Tfluid_phase)/2;                %Avg output temp of Mixture (SG+LFR)
    LFR.drum_msout=LFR.msteam_pipeout8;                         %Mass of steam out from LFR  %%mass or massflow??

    if SG.press > SG.press_st-0.2    %??  If SG pressure>Setpoint pressure
        SG.msgen_SH=SG.msgen;        %Mass of steam generation coming from SG to SH
    else
        SG.msgen_SH=0;               %Mass of steam generation coming from SG to SH
    end
else
    LFR.Tfluid_phase=0;
    SG.LFR_Tsout=SG.Twater;
    LFR.drum_msout=0;

    if SG.press > SG.press_st-0.2
        SG.msgen_SH=SG.msgen;
    else
        SG.msgen_SH=0;
    end
end
%%

if (SH.ODE==0)
    dTdt1=0;
    dTdt2=0;
else
%% Function calling for calculating UAF
    if Mode==1
        SH.msin=SG.msgen_SH+0;         %Mass of steam in from SD and SG goes to SH
    else
        SH.msin=SG.msgen_SH+Drum.msout;         %Mass of steam in from SD and SG goes to SH
    end
    

    %Function return [UAF, tube side HTC, Shell sideHTC,Correctionfactor,Overall HTC]=[Mass flowrate of fluid on shell side,Temp of Oil coming out from HT,Temp of Oil from coming out from SH,Mass flow rate of steam in,Temp of steam coming in to SH,Temp of steam coming out from SH, pressure of steam from SG]
    [SH.UAF,SH.htctube,SH.htcshell,SH.htcF,SH.htcU] =UAF_SH_fun(SH.moil, SH.Toilin,SH.Toout,SH.msin,SG.LFR_Tsout,SH.Tsout,SG.press);    %SG.LFR_Tsout=MAin 1849 line

%% Scaling down UAF
    SH.UAF=0.6*SH.UAF;      %From Validation see

%% Calculation of LMTD
    hot_sh= SH.Toilin - SH.Tsout;           %Hot side temp diff
    cold_sh=SH.Toout - SG.LFR_Tsout;        %Cold side temp diff
    %lm_sh= SH.Toout-SH.Tsout;
    oilside=(SH.Toilin+ SH.Toout)/2;        %Avg oil temp for SH in and out 
    waterside= (SG.LFR_Tsout +SH.Tsout)/2;  %Avg steam temp for SH in and out


    if (hot_sh/cold_sh)==1 || (SG.LFR_Tsout > SH.Toout)
        SH.lmtd=oilside- waterside;                             %LMTD
        disp('AR SH');
    else
        SH.lmtd=(hot_sh-cold_sh)/(log(hot_sh/cold_sh) );        %LMTD
    end
%% Some parameter calculation

    oil_diff_sh= SH.Toilin - SH.Toout;
    oil_avg_sh=( SH.Toilin + SH.Toout)/2;

%% Equation no 20 in IECER paper: Oil temp at outlet of SH

    deno_HX_1=(SH.shell_side_volume*SH.Toout*density_oil(SH.Toout)*(dbyCp_sf (SH.Toout)*10^(-3)))+...
        (SH.shell_side_volume*SH.Toout*dbyden_sf(SH.Toout)*(Cp_oil(SH.Toout) * 10^(-3)))+...
        (SH.shell_side_volume*density_oil(SH.Toout)*(Cp_oil(SH.Toout) * 10^(-3)));

    dTdt1 = ((SH.moil*(Cp_oil(oil_avg_sh)*10^(-3)*(oil_diff_sh)))...
        - (SH.UAF *SH.lmtd)-(SH.Uloss*SH.loss_A*(SH.Toout- HX.Ambient_Tempr)) )/deno_HX_1;

%% Equation no 21 in IECER paper: Steam temp at outlet of SH

    %Specific isobaric heat capacity as a function of pressure and temperature.
    CP_S_SH=( XSteam('Cp_pT',SG.press,SH.Tsout) );
    %rho_pT	Density as a function of pressure and temperature.
    row_S_SH=XSteam('rho_pT',SG.press,SH.Tsout) ;
    %Saturated vapour heat capacity: Central diff method by purturbation
    dCp=((XSteam('CpV_p',(SG.press+0.1)))-(XSteam('CpV_p',(SG.press-0.1))))/(2*0.1);
    %Saturated vapour density: Central diff method by purturbation
    drow_s_T=((XSteam('rhoV_T',(SH.Tsout+0.1)))-(XSteam('rhoV_T',(SH.Tsout-0.1))))/(2*0.1);
    %Saturated vapour heat capacity: Central diff method by purturbation
    dCps_T=((XSteam('CpV_T',(SH.Tsout+0.1)))-(XSteam('CpV_T',(SH.Tsout-0.1))))/(2*0.1);

    %Appendix A29 equation number. Page no 161 from Surrender thesis.
    SH_deno1=((drow_s_T)*SH.Tsout*SH.tube_side_volume*CP_S_SH);
    SH_deno2=((dCps_T)*SH.Tsout*SH.tube_side_volume*row_S_SH);
    SH_deno3=CP_S_SH*SH.tube_side_volume*row_S_SH;

    deno_SH=SH_deno1+SH_deno2+SH_deno3;
    
    %h_pt=Entalpy as a function of pressure and temperature.
    dt2cha=(SH.mixh) - (XSteam('h_pT',SG.press,SH.Tsout) );                 %Enthalpy=Cp*T  
    %Enthalpy=Enthalpy in- Enthalpy out. Here presurre is assuming constant so SG pressure is concidered

    dTdt2 = (((SH.msin) * dt2cha) + (SH.UAF*SH.lmtd) )/deno_SH ;
end
dHX_SH=[dTdt1 dTdt2]';          %Returning both unknown temperature
end