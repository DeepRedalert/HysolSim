%Function file for SG height
function [HXSG_height] =HXSG_height(hei)

global HXSG

HXSG.h=hei;

HXSG_height=HXSG.Mass-(HXSG.den*HXSG.L)*(HXSG.R^2*acos((HXSG.R-HXSG.h)/HXSG.R)-(HXSG.R-HXSG.h)*(sqrt((2*HXSG.R*HXSG.h)-(HXSG.h^2))));

end
