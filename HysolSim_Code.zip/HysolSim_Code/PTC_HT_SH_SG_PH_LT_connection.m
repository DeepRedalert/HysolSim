%Function file for connection of PTC-HT-SH-SG-PH-LT-PTC

function [HT_out_temp,LT_out_temp]=PTC_HT_SH_SG_PH_LT_connection(Tspan)

global PTC_SCF PTC_scf HT LT HX SH SG PH PTC_HT_OD PTC_HT PTC_LT OP Mode
% global latent_s row_l_s row_v_s sur_s  cpW_s  Te dyn_vis_s Ther_s hb2_sg hb1_sg
% global den_t cp_t Kvis_t Therm_t dyn_vis_t f_t Ren_t mosat NUs_t  term1 term2 Pra_Sg
% Tspan=[0,1];
%Connect HT with PTC
HT.moilin=PTC_scf.moil*3;
HT.moilout=HT.moilin;
HT.hin=h_oil(PTC_SCF.Xintial(PTC_scf.grid));

if PTC_HT_OD==1
    options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
    [Ts,Y_HT]=ode15s(@HTtank,Tspan,PTC_HT.Xintial,options);
    PTC_HT.Xintial=(Y_HT(length(Ts),:)');

    HT.hout=PTC_HT.Xintial(2);
    %opts = optimset('TolFun',1e-12,'Display','off') ;
    %HT.Toout=fsolve('enthal_Temp_HT',HT.Toout,opts);
    HT.Toout=(-1.49681+sqrt(1.49681^2-4*0.0014*(-18.17454-HT.hout)))/(2*0.0014);
    HT_out_temp=HT.Toout;
    
    HX.Toin=HT.Toout;
else
    SG.Toilin=PTC_SCF.Xintial(PTC_scf.grid);                              % outlet SCF connectedSG
end
HT_out_temp=HT.Toout;

%if Mode~=1
%Mixture connection
mix_sh_intial=[0 0];

options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
[Ts,mixsh]=ode15s(@mixer_SH,Tspan,mix_sh_intial,options);
mix_sh_intial=(mixsh(length(Ts),:)');
%Check
SH.mixh=mix_sh_intial(2);   %This SH.mixh will go to HXSH function file
%else
% SH.mixh=SG.msgen_SH;
%end

%Connect HT/PTC to SH
if PTC_HT_OD==1
    SH.Toilin=HT.Toout;
else
    SH.Toilin=PTC_SCF.Xintial(PTC_scf.grid);
end

SH.ODE=1;
%[~,sh_tsout]=HXSH(Tspan,HX.SHintial);
SH.moil=HT.moilout;
% options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
% [Ts,Y_HXSH]=ode15s(@HXSH,Tspan,HX.SHintial,options);
[Ts,Y_HXSH]=ode15s(@HXSH,Tspan,HX.SHintial);
HX.SHintial=(Y_HXSH(length(Ts),:)');
SH.ODE=1;
    
% OP.SHuaf=[OP.SHuaf SH.UAF]; %                   
% OP.SHhtube=[OP.SHhtube  SH.htctube];
% OP.SHhshell=[OP.SHhshell SH.htcshell];
% OP.SHF=[OP.SHF SH.htcF];
% OP.SHU=[OP.SHU SH.htcU];

%Connect SH to SG
SG.Toilin=HX.SHintial(1); %Temp of oil outlet of Sh goes into SG
SG.moil=HT.moilout;       

SG.Wsat=XSteam('hL_p',SG.press_int);
check_Wsat_SG=(SG.Wsat-HX.SGintial(5));

SG.hs= XSteam('hV_p',HX.SGintial(6));
SG.hw=XSteam('hL_p',HX.SGintial(6));

%Just to check is the pressure is near to 40 bar or not, if yes then both
%condition will not satisfy.
if  HX.SGintial(6)>41
    disp('Pressure more than 41');
%     HX.SGintial(6)=40;                       %pressure more than 40 bar will vented out from SG
%     disp('Pressure more than 40 vented out');
end
if HX.SGintial(6) < 38
    disp('pressure less than 38');
end

% if   PH.ODE==1
%     SG.Twin =HX.PHintial(1);
% end
SG.Twin;
options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
[Ts,Y_HXSG]=ode15s(@HXSG_sat,Tspan,HX.SGintial,options);
HX.SGintial=(Y_HXSG(length(Ts),:)');
SG.ODE=1; 
% if SG.htcshell>600
%     SG.htcshell=600;
%     disp('wait')
% end
% if SG.htctube<1275 && SG.press>1
%     SG.htctube=1275;
% end
% if SG.htcU>250
%     SG.htcU=250;
% end
if HX.SGintial(6)<40.002
    disp('')
end
OP.SGuaf=[OP.SGuaf SG.UAF];
OP.SGhtube=[OP.SGhtube  SG.htctube];
OP.SGhshell=[OP.SGhshell SG.htcshell];
OP.SGF=[OP.SGF SG.htcF];
OP.SGU=[OP.SGU SG.htcU];

% OP.HGSG7=[OP.HGSG7 latent_s];%lamda
% OP.HGSG8=[OP.HGSG8 row_l_s];%rho_L
% OP.HGSG9=[OP.HGSG9 row_v_s];%rho_V
% OP.HGSG10=[OP.HGSG10 sur_s];%Surface tension , sigma
% OP.HGSG11=[OP.HGSG11 cpW_s];
% OP.HGSG12=[OP.HGSG12 Te];
% OP.HGSG13=[OP.HGSG13 dyn_vis_s];
% OP.HGSG14=[OP.HGSG14 Ther_s];
% OP.HGSG15=[OP.HGSG15 hb2_sg];
% OP.HGSG16=[OP.HGSG16 hb1_sg];
% OP.HGSG17=[OP.HGSG17 Pra_Sg];
% OP.term1=[OP.term1 term1];
% OP.term2=[OP.term2 term2];
% 
% OP.tube1=[OP.tube1 den_t];
% OP.tube2=[OP.tube2 cp_t];
% OP.tube3=[OP.tube3 Kvis_t];
% OP.tube4=[OP.tube4 Therm_t];
% OP.tube5=[OP.tube5 dyn_vis_t];
% OP.tube6=[OP.tube6 f_t];
% OP.tube7=[OP.tube7 Ren_t];
% OP.tube8=[OP.tube8 mosat];
% OP.tube9=[OP.tube9 NUs_t];

%Connect SG to PH
PH.Toilin=HX.SGintial(1);   %Temp of oil outlet of SG goes into PH
PH.moil=HT.moilout;
% OP.PH=[OP.PH  HX.PHintial];

PH.ODE=1;
options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
[Ts,Y_HXPH]=ode15s(@HXPH,Tspan,HX.PHintial,options);
HX.PHintial=(Y_HXPH(length(Ts),:)');
PH.ODE=1;

OP.PHuaf=[OP.PHuaf PH.UAF];
OP.PHhtube=[OP.PHhtube  PH.htctube];
OP.PHhshell=[OP.PHhshell PH.htcshell];
OP.PHF=[OP.PHF PH.htcF];
OP.PHU=[OP.PHU PH.htcU];

%Connect PH to LT
LT.moilin=HT.moilout;
LT.moilout=LT.moilin;
LT.hin=h_oil(HX.PHintial(2));

options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
[Ts,Y_LT]=ode15s(@LTtank,Tspan,PTC_LT.Xintial,options);
PTC_LT.Xintial=(Y_LT(length(Ts),:)');

LT.hout=PTC_LT.Xintial(2);
%opts = optimset('TolFun',1e-12,'Display','off') ;
%LT.Toout=fsolve('enthal_Temp_LT',LT.Toout,opts);

%Enthalpy polynomial fit equation:
%Enthalpy=(0.0014*T^2)+(1.49681*T)-18.17454; (TAken from thermino VP1 pdf file)
%Concidering only +ve part
LT.Toout=(-1.49681+sqrt(1.49681^2-4*0.0014*(-18.17454-LT.hout)))/(2*0.0014);
LT_out_temp=LT.Toout;
%LT again connected to PTC
PTC_SCF.Xintial(1)=LT.Toout;
%PTC_scf.moil=LT.moilout;
end


