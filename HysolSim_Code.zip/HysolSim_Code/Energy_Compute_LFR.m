%Function file for compute energy produced from LFR loop

function [Eng_gain_arr_LFR1]=Energy_Compute_LFR(E_lfr_num,time_run)

global LFRsim LFR Eng_gain_arr_LFR1

h_in_lfr=LFRsim.h(time_run+1,1);                %Enthalpy at the input point of LFR
h_out_lfr=LFRsim.h(time_run+1,end);             %Enthalpy at the output point of LFR
Enge_gain_LFR1=((LFR.mw_indi*(h_out_lfr *(10^-3)-h_in_lfr*(10^-3)))*LFR.dt) ;
%Eng_gain_arr_LFR1(E_lfr_num)=Enge_gain_LFR1;
Eng_gain_arr_LFR1=[Eng_gain_arr_LFR1 Enge_gain_LFR1];
end

%%

% h_in_lfr=LFRsim.h(time_run,1);
% h_out_lfr=LFRsim.h(time_run+1,end);
% Enge_gain_LFR=((LFR.mw_indi*(h_out_lfr*10^-3-h_in_lfr*10^-3) )* LFR.dt) ;
% Eng_gain_arr_LFR(time_run+1)=Enge_gain_LFR;