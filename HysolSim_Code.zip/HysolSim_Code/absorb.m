%Function for Energy balance for LFR pipe

function [Temps] =absorb(Tabsorber)

global LFR Tabsor_pre%%Tabsor_pre=[Temp of absorber pipe    %Temp of glass absorber]

TEgi=Tabsorber(2);
%Equation A.13: Energy balance for Absorber pipe equation: Same as PTC only
TT(1)=((LFR.hppoint*LFR.pai*(LFR.Tfluid-Tabsorber(1)))-((LFR.sig/((1/LFR.ea)+(((1-LFR.ee)/LFR.ee)*(LFR.rao_ab/LFR.rei))))...
                         *(LFR.pao*(((Tabsorber(1)+273.15)^4)-((TEgi+273.15)^4))))+(0.25*(LFR.I*LFR.no*LFR.width)))/(LFR.den_abso*LFR.Cp_abso*LFR.Aai);

%Equation A.14: Energy balance for Glass envelope equation: Same as PTC only
TT(2)=(((LFR.sig/((1/LFR.ea)+((1-LFR.ee)/LFR.ee)*(LFR.rao_ab/LFR.rei)))*(LFR.pao*(((Tabsorber(1)+273.15)^4)-((TEgi+273.15)^4))))...
                -(LFR.sig*LFR.ee*LFR.peo*(((TEgi+273.15)^4)-((LFR.Tsky+273.15)^4)))...
                 -(LFR.hair*LFR.peo*(TEgi-LFR.Tair)))/(LFR.den_gla*LFR.Ce_gla*LFR.Ae);  
             
Temps1= ( Tabsorber(1) - Tabsor_pre(1)-(LFR.dt*TT(1)) );  %?? Why this is needed?? 
Temps2= ( Tabsorber(2) - Tabsor_pre(2)-(LFR.dt*TT(2)) );  %??
Temps=[Temps1 Temps2];
end
 

 
 
 