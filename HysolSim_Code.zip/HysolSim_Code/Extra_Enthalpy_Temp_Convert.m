% File for find Temperature from Enthalpy

clc
clear all
close all

%% BY fsolve
% Guess_Temp=40;
% Solution=fsolve(@enthal_Temp_LT,Guess_Temp)

% function f=enthal_Temp_LT(hoilout_LT)
%     Current_Enthalpy=250;
%     f=h_oil(hoilout_LT)-Current_Enthalpy;            %hoilout_HT ----KJ/Kg
% end

% function Enthalpy=h_oil(T)
%     Enthalpy=(0.0014*T^2)+(1.49681*T)-18.17454;  %KJ/KG
% end

%% By Direct quadratic equation

Enthalpy=250;
%Concidering only +ve part, it gives one -ve and one +ve temperature
Temperature=(-1.49681+sqrt(1.49681^2-4*0.0014*(-18.17454-Enthalpy)))/(2*0.0014)

