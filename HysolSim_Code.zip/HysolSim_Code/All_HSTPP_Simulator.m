% HYBRID SOLAR THERMAL POWER PLANT(HSTPP) SIMULATOR   

% Developed by Dibyajyoti Baidya under the guidence of Dr. K. Surrender, Prof. Mani Bhushan, Prof. Sharad Bhartiya 
% Indian Institute of Technology, Bombay, Maharashtra, India
% Developed Year: 2025
% https://github.com/DeepRedalert/HysolSim
%***********************************************************************************************************

% Mode of Operation: 1. Full Hybrid plant (PTC+LFR)  2. Only PTC plant

% Type of Solar radiation: 1. Constant 2. Step 3. Real-time  4. Quadratic
               

%* The HSTPP simulator is free and provided as is.                                                         *
%* We take no responsibilities for any errors in the code or damage thereby.                               *
%* You are free to use, modify and distribute the code as long as authorship is properly acknowledged.     *
%* Please notify us at "dibya_25@iitb.ac.in/dtwin.dibya@gmail.com" if the code is used in commercial applications                     *
%***********************************************************************************************************


% HSTPP Simulator includes both Parabolic Trough Collector(PTC) and Linear Fresnel Reflector(LFR).
% Main Components of HSTPP as follow:
%                               1. Parabolic Trough Collector(PTC)
%                               2. Linear Fresnel Reflector(LFR)
%                               3. High temperature Tank (HT)
%                               4. Low temperature Tank (LT)
%                               5. Super Heater (SH)
%                               6. Steam Generator (SG)
%                               7. Pre Heater (PH)
%                               8. Steam Drum (SD)
%                               9. Steam Turbine
%                               10. Generator



%_________________________________________________________________________________
clc
clear all
close all

Type=input(['HSTPP is going to simulate now.' ...
    '\n Select Types of Solar radiation you want to simulate for, ' ...
        '\n 1. Constant Solar radiation Type "0" ' ...
        '\n 2. Constant with step change radiation Type "1" ' ...
        '\n 3. Real-time Solar radiation Type "2" ' ...
        '\n 4. Quadratic Solar radiation Type "3" ' ...
        '\n \n Type:']);

Mode=input(['\n Select Mode of Simulation. ' ...
        '\n 1.For only PTC plant simulation Type "1" ' ...
        '\n 2. For Hybrid plant simulation (PTC+LFR) Type "2" ' ...
        '\n \n Mode:']);

Startup=input(['\n Select Startup.' ...
        '\n 1. For cold Startup type "1"' ...
        '\n 2. For Hot startup type "2"' ...
        '\n 3. For complete 2 day Cold & Hot startup type "3"' ...
        '\n \n Startup:']);

if Mode==1
    X=Oil_only(Mode,Type,Startup);      %Only oil loop 
elseif Mode==2
    X=Hybrid(Mode,Type,Startup);        %Oil+Water loop
else
    disp("Be sure in which mode you want to run the simulation, ..." + ...
        "specify first then I will run. May be by mistake you have Type other than 1 and 2")
end

% ******************************************* END ***********************************************%
