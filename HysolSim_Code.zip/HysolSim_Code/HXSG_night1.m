%% This is for SG night time. No control work has been done by surrender sir for this. 
% Only for case study purpose it has been done. 
% At night time steam changes to water again due to condensation.


function [dpdt_SG1] =HXSG_night1(t,T)

global SG U

SG_press=T(1);                              %SG pressure
Mass_wat=T(2);                              %Mass of water in SG
Mass_st=T(3);                               %Mass of steam in SG

SG.Twater=XSteam('Tsat_p',SG_press);        %SG water temp  oC
row_st=XSteam('rhoV_p',SG_press);           

%SG pressure unit conversion
Press_SG=SG_press;
Press_SG_n=Press_SG*10^5;

%hV_p	Saturated vapour enthalpy
dhst_n= ( (XSteam('hV_p',(SG_press+(1*10^-6))))-(XSteam('hV_p',(SG_press-(1*10^-6)))) )/(2*(0.1));
%rhoV_p	Saturated vapour density
drow_st=( (XSteam('rhoV_p',(SG_press+(1*10^-6))))-(XSteam('rhoV_p',(SG_press-(1*10^-6)))) )/(2*(0.1));
%hL_p	Saturated liquid enthalpy
dhw_n=( (XSteam('hL_p',(SG_press+(1*10^-6))))-(XSteam('hL_p',(SG_press-(1*10^-6)))) )/(2*(0.1));
%Tsat_p	Saturation temperature
dts=( (XSteam('Tsat_p',(SG_press+(1*10^-6))))-(XSteam('Tsat_p',(SG_press-(1*10^-6)))) )/(2*(0.1));

dhst_n=dhst_n*1000;     %Saturated vapour enthalpy
dhw_n=dhw_n*1000;       %Saturated liquid enthalpy

U_SG=U.SG_night;        %HTC of SG
F_SG=0.6;               %Correction factor

%% To calculate A_wair
R=SG.radius;            %Radius
L=SG.L;                 %Length
den_wat=XSteam('rhoL_p',SG_press);      %rhoL_p	Saturated liquid density
Vol_wat=SG.Mw/den_wat;                  %Water volume
hw=Vol_wat/ (pi*R^2);                   %Enthalpy of water
conv=(pi/180);

if  (R-hw) >0
    Rmhw=R-hw;
    R2hm2=R^2-hw^2;
    anglee=(((Rmhw)/R)*conv);
    angle1=(180*(conv)-2*asin(anglee));
    A_wair=(2*pi*R^2*angle1-((sqrt(R2hm2))))+(((pi*R*L)/360)*angle1 );
else
    angle1=((hw-R)/R);
    angle1=angle1*conv;
    A_wair=((pi*R*L)/(360*conv))*((180*conv)+2*asin(angle1));
end

if  isreal(A_wair)~=1
    A_wair
    pause
end

%% For pressure equation
Total_area=(2*pi*R^2)+(pi*R*L); %Total area of SG
A_stair= Total_area-A_wair;     %Area of steam=Area of SG-Area of water
A_SG=Total_area;                
SG.area_shell=A_SG;             %Total area of SG

deltaT_stair=SG.Twater-40;      %Temp diff of steam and air
deltaT_wair=SG.Twater-40;       %Temp diff of water and air

hwx=XSteam('hL_p',SG_press);    %Water enthalpy........%hL_p	Saturated liquid enthalpy
hs=XSteam('hV_p',SG_press);     %Steam enthalpy........%hV_p	Saturated vapour enthalpy
h_cond=(hs-hwx)*1000;           %Condensation enthalpy

%g in equation (D) in the night time SG model derivation
GG=(Mass_st*dhst_n)-(SG.Vsys)+(Press_SG_n*(Mass_st/(row_st^2))*drow_st);
%alpha in equation (F) in the night time SG model derivation
alpha_SG= (U_SG*A_stair*F_SG*deltaT_stair)+ (U_SG*A_wair*F_SG*deltaT_wair);
alpha_SG=-1*alpha_SG;
%X in equation (G) in the night time SG model derivation
XX_SG=(Mass_wat*dhw_n)+(Mass_st*dhst_n)-(SG.Vsys)+(SG.Mmeta*SG.Cpmeta*dts);
%Rate of change of Pressure equation: *in the night time SG model derivation
dpdt_SG=((alpha_SG -(h_cond*(row_st/Press_SG_n)*U_SG*A_stair*F_SG*deltaT_stair) )/(XX_SG+h_cond*GG*(row_st/Press_SG_n)))*(1/10^5);
GG=GG*(1/10^5);     %Unit conversion
%% For mass of water and mass of steam equation
m_cond_SG =( (-1*U_SG*A_SG*F_SG*deltaT_stair) -(GG*dpdt_SG) )*(row_st/Press_SG_n);
SG.m_cond_SG=m_cond_SG*1;

if  Mass_st < 0.1
    dmwdt=0;
    dmsdt=0;
else
    dmwdt=-m_cond_SG;
    dmsdt= m_cond_SG;
end
%%
dpdt_SG1=[dpdt_SG dmwdt dmsdt]';        %Returning Rate of change of pressure in SG, Mass of water, Mass of steam
end