%% Steam generator HTC: Saturated condition
%For calculation of U we need two HTC,one is shell side another is tube side.
%_she=Shell side
%_t= tube side


function[ UAF,hi_t_turb,hb_sg,F,U]=UAF_SG_fun(mo,Toi,Too,mw,Twi,Two,press,t)

global SG
global latent_s row_l_s row_v_s sur_s  cpW_s  Te dyn_vis_s Ther_s hb2_sg hb1_sg term1 term2
global den_t cp_t Kvis_t Therm_t dyn_vis_t f_t Ren_t NUs_t mosat Pra_Sg
P=press;                    %Pressure
To_av=(Toi+Too)/2;          %Avg oil temperature=(Temp of Oil coming in to SG+Temp of Oil from coming out from SG)/2
Tw_av=(Twi+Two)/2;          %Avg steam temperature=(Temp of steam coming in+Temp of steam coming out from SG)/2 , Here press<40 bar then Two=Temp of water/steam inside the SG 

g=9.8;                      %Gravity
Pc=220;                     %Critical pressure      bar

Nt=SG.No_tubes;             %No of tubes=75
Di_t=SG.tube_Id ;           %Tube input diameter
ri_t=SG.tube_Id/2;          %Tube input radius
Do_t=SG.tube_OD;            %Tube output diameter
ro_t=SG.tube_OD/2;          %Tube outer radius
nopass_t=2;                 %No of passes
L_t=SG.tube_length;         %Tube length
Area=pi*Do_t*L_t*(Nt*2);    %Area of heat transfer    m^2
Therma=49;                  %Thermal conductivity

%% Shell side HTC calculation
%T_shell=XSteam('Tsat_p',SG.press);     %Tsat_p	Saturation temperature
% den_s=XSteam('rhoL_p',SG.press);      %rhoL_p	Saturated liquid density
sur_s= XSteam('st_p',SG.press);         %st_p	Surface tension for two phase water/steam as a function of T            N/m
row_l_s=XSteam('rhoL_p',SG.press) ;     %rhoL_p	Saturated liquid density            kg/m^3
row_v_s=XSteam('rhoV_p',SG.press);      %rhoV_p	Saturated vapour density            kg/m^3
latent_s=(XSteam('hV_p',SG.press))-(XSteam('hL_p',SG.press));       %hV_p	Saturated vapour enthalpy
latent_s=latent_s*1000;                 %Enthalpy of liquid vaporization            J/Kg
h_w_sg=XSteam('hL_p',SG.press);         %hL_p	Saturated liquid enthalpy
dyn_vis_s=XSteam('my_ph',SG.press,h_w_sg); %my_ph	Viscosity as a function of pressure and enthalpy, Dynamic viscosity   Pa.s

if isnan(dyn_vis_s)==1
    vis_L=h2o_muf(SG.press*100);
    %vis_g=h2o_mug(SG.press*100);
    dyn_vis_s=vis_L;
end

cpW_s=XSteam('CpL_p',SG.press)*1000;        %Specific heat of liquid        J/kg K
Ther_s=XSteam('tcL_p',SG.press);

if (Too-Two)>0
    Te=(0.3*((Too-Two)/3));                 %Te= Excess temp of the boiling surface     K
else
    disp('CHECK TE');
    Te=abs(0.001*((Too-Two)/3));
end
% if (Too-Two)>0
%     Te=Too-Two;                 %Te= Excess temp of the boiling surface     K
% else
%     Te=abs(Too-Two);
% end
%Prandtl number controls the relative thickness of the momentum and thermal boundary layers. When Pr is small, it means that the heat diffuses quickly compared to the velocity (momentum).
Pra_Sg=(cpW_s*dyn_vis_s)/Ther_s;        %Liquid prandtl number   (Cp mu/k)   K=Saturated vapour thermal conductivity
Csf=0.001;          %Constant that depend on the liquid and heating surface combination for boiling operation.
n=1;                %Experimental constant equal to 1 for water and 1.7 for other fluids

%1. Rosenhow correlation
q_sg=dyn_vis_s*latent_s*(((g*(row_l_s-row_v_s))/sur_s)^(1/2))*(((cpW_s*Te)/(Csf*latent_s*(Pra_Sg^n)))^3);
Q_sbyA_SG=q_sg;     %Heat flux in nucleation boiling
term1=(((g*(row_l_s-row_v_s))/sur_s)^(1/2));
term2=(((cpW_s*Te)/(Csf*latent_s*(Pra_Sg^n)))^3);

%2. Mostinski method
%hb1_sg=0.00658*Pc^0.69*((Q_sbyA_SG)^0.7);       %In thesis 170 page 0.00658~0.00417
hb1_sg=0.00417*Pc^0.69*((Q_sbyA_SG)^0.7);       %In thesis 170 page 0.00658~0.00417
hb2_sg=(1.8*((P/Pc)^0.17))+(4*((P/Pc)^1.2))+(10*((P/Pc)^10));
hb_sg=hb1_sg*hb2_sg;        %Shell side HTC
% if hb_sg>=1500
%     disp('Check')
%     hb_sg=1500;
% end
%% Tube side HTC calculation: Petukhov & Kirillov correlation
%TUBE side LAMINAR flow

den_t=density_oil(To_av);                %Density of oil
cp_t=Cp_sf(To_av);                       %Sp. Heat capacity
Kvis_t=Kin_vis(To_av);                   %Kinematic viscocity
Therm_t=Ther_con(To_av);                 %Thermal conductivity
dyn_vis_t=(Kvis_t *den_t);               %Dynamic viscosity

At_t=(pi*(Di_t^2))/4;                    %Area of tube side
Atp_t=(Nt*At_t)/nopass_t;
Gt_t=(mo/Atp_t);                         %Mass velocity of tube=Mass flow rate of oil in/Atp
Ut_t=Gt_t/den_t;                         %Velocity
Ren_t=(Ut_t*den_t*Di_t)/dyn_vis_t;       %Reynolds number on tube side
Pr_t=(cp_t*dyn_vis_t)/Therm_t;           %Prandtl number=(Sp. Heat capacity*Dynamic viscosity)/Thermal conductivity
mosat=mo;
%TUBE side TURBULENT flow
f_t=(1.58*log(Ren_t)-3.28)^-2;                                              %f=Friction factor
NUs_t=((f_t/2)*Ren_t*Pr_t)/(1.07+(12.7*((f_t/2)^(1/2)))*((Pr_t^(2/3))-1));  %Nusselt number
hi_t_turb=(NUs_t*Therm_t)/Di_t;                                             %Tube side HTC


% if hb_sg>450
%     hb_sg=450;   %3
%     %disp('wait')
% end
% if hi_t_turb<1275 && SG.press>1
%     hi_t_turb=1275;  %2
% end
% 

%% Overall HTC calculation by Delaware method
U=((ro_t/ri_t)*(1/hi_t_turb) )+(1/ hb_sg)+((ro_t*log(ro_t/ri_t))/(Therma));
U=1/U;


% if U>250      %Drop is not visible
%     U=250;
% end

if isreal(U)~=1
    hi_t_turb
    hb_sg
    disp('HTC is imag for SG');
    pause
end
%% Correction factor of SG
if mw==0
    F=1;
else
    Rr=(Toi-Too)/(Two-Twi);     %Range on shell side temperature/Range on tube side temperature
    Ss=(Two-Twi)/(Toi-Twi);     %Range on tube side temerature/Maximum temperature diff on HX

    num_F=(sqrt((Rr^2)+1))*log((1-Ss)/(1-(Rr*Ss))); %Numerator of correction factor

    F_d1= 2- (Ss*(Rr+1- (sqrt(Rr^2+1))) );
    F_d2= 2- (Ss*(Rr+1+ (sqrt(Rr^2+1))) );
    Deno_F=(Rr-1)*log(F_d1/F_d2);       %Denominator of correction factor

    F=num_F/Deno_F;                     %Correction factor
end

F=1;  %For boiling correction factor is one

%% Final UAF
UAF=U*Area*F;
UAF=UAF*10^-3;
end