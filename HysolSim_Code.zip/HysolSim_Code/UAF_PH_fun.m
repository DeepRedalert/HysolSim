%% Preheater HTC
%For calculation of U we need two HTC,one is shell side another is tube side.
%_she=Shell side
%_t= tuibe side

function [UAF,hi_t_turb, ho_she,F,U]=UAF_PH_fun(mo,Toi,Too,mw,Twi,Two,Pres)

global PH

Tw_av=(Twi+Two)/2;          %Avg water temperature=(Temp of fresh water (30 oC)+Temp of water coming out from PH)/2
Toil_av=(Toi+Too)/2;        %Avg oil temperature=(Temp of Oil coming out from SG+Temp of Oil from coming out from PH)/2

%All units in meters
tube_ID=PH.tube_ID;                 %Tube input diameter
ri_t=tube_ID/2;                     %Tube input radius
tube_OD= PH.tube_OD;                %Tube output diameter
ro_t=tube_OD/2;                     %Tube outer radius
L_t=PH.tube_length;                 %Tube length
No_tub= PH.No_tubes;                %Total no of tubes
PH.nopass_t=2;                      %Number of passes?
Area=pi*tube_OD*L_t*(No_tub*2);     %Area of heat transfer    m^2
Therma=49;                          %Thermal conductivity

%% Tube side HTC calculation: Petukhov & Kirillov correlation
%TUBE side LAMINAR flow
den_t=XSteam('rho_pT',Pres,Tw_av);      %Density of oil, Here pres=1 bar
cpW_t=(XSteam('Cp_pT',Pres,Tw_av));
cp_t=cpW_t*1000;                        %Sp. Heat capacity
dyn_vis_t=XSteam('my_pT',Pres,Tw_av);   %Dynamic viscosity
Th_t=XSteam('tc_pT',Pres,Tw_av);        %Thermal conductivity
kvis_t=dyn_vis_t/den_t;                 %Kinematic viscocity

At_t=(pi*(tube_ID^2))/4;                %Area of tube side
Atp_t=(No_tub*At_t)/PH.nopass_t;        %
Gt_t=(mw /Atp_t);                       %Mass velocity of tube=Mass flow rate of water in/Atp
Ut_t=Gt_t/den_t;                        %Velocity
Ren_t=(Ut_t*den_t*tube_ID)/dyn_vis_t;   %Reynolds number on tube side
Pr_t=(cp_t*dyn_vis_t)/Th_t;             %Prandtl number=(Sp. Heat capacity*Dynamic viscosity)/Thermal conductivity

%TUBE side TURBULENT flow
f_t=(3.64*log10(Ren_t)-3.28)^-2;                                                %f=Friction factor
NUs_t=((f_t/2)*Ren_t*Pr_t)/(1.07+(12.7*((f_t/2)^(1/2)))*((Pr_t^(2/3))-1));      %Nusselt number
hi_t_turb=(NUs_t*Th_t)/tube_ID;                                                 %Tube side HTC

%% Shell side HTC calculation
Di_s= PH.shell_ID;                      %Shell side inner diameter
ls=(PH.tube_length/17);                 %Baffle spacing
Dotl=0.25;                              %ds-Bundle clearence
Pn=0.0238;
Pt=Pn;                                  %Pitch/square

% den_she=density_oil(Toil_av);
% cp_she=Cp_sf(Too);
% Kvis_she=Kin_vis(Too);
% Th_she=Ther_con(Too);

den_she=density_oil(Toil_av);           %Denisity of oil
cp_she=Cp_sf(Toil_av);                  %Specific heat capacity of fluid on shell side
Kvis_she=Kin_vis(Toil_av);              %Kinetic viscocity
Th_she=Ther_con(Toil_av);               %Thermal conductivity on shell side
dyn_vis_she= (Kvis_she *den_she);       %Dynamic Viscocity of fluid on shell side

%% Calculation of HTC on shell side by 2 method

%1. Paper Kern method
%  Cl=Pn-(2*(tube_OD/2));
%  A_she=(Di_s*Cl*ls)/Pt;
%  Gs_she=mo/A_she;
%  De_she=(4*((Pt^2)-((pi*tube_OD^2)/4)))/(pi*tube_OD);
%  Re_she=(De_she*Gs_she)/dyn_vis_she;
%  Nu_she=0.36*(Re_she^0.55)*(((cp_she*dyn_vis_she)/Th_she)^0.33);%*((ub/uw)^0.14);
%  ho_she1=(Nu_she*Th_she)/De_she;                          %Shell side HTC

%Overall HTC calculation by paper karn method
% U1=( (ro_t/ri_t)*(1/hi_t_turb) )+(1/ ho_she1)+((ro_t*log(ro_t/ri_t))/Therma);
% U1=1/U1;

%2. BELL Delaware method
sm=ls*(Di_s-Dotl+(((Dotl-tube_OD)/Pn)*(Pt-tube_OD)));
Re_s=(tube_OD*mo)/(dyn_vis_she*sm);                         %Reynolds number=(tube outer diameter*Mass flow rate of fluid on shell side)/(Dyn viscocity*Sm)
j1= 0.185*(Re_s^-0.324);                                    %Colburn j-factor
Cs=cp_she  ;                                                %Specific heat capacity of fluid shell side

ho_she=j1*Cs*(mo/sm)*(Th_she/(Cs*dyn_vis_she));             %Shell side HTC

%Overall HTC calculation by Delaware method
U=(1/ ho_she)+((1/hi_t_turb)* (tube_OD/tube_ID) )+((ro_t*log(ro_t/ri_t))/(Therma));
U=1/U;


%% Correction factor of PH
Rr=(Toi-Too)/(Two-Twi);                                 %Range on shell side temperature/Range on tube side temperature
Ss=(Two-Twi)/(Toi-Twi);                                 %Range on tube side temerature/Maximum temperature diff on HX
%Here Rr should not be 1, otherwise Deno_F will be 0 and hence F will be NAN.
%Also Rr and Ss should be positive. Otherwise complex number will come in
%num_F. Rr*Ss should be less than 1, otherwise imaginary number will come.
if Rr==0
    disp('Rr value should not be zero in PH UAF, kindly check in the code')
    pause
end
if Rr<0 || Ss<0
    disp('Rr or Ss contain negative number in PH UAF, Complex value will come for other variable')
    pause
end
num_F=(sqrt((Rr^2)+1))*log ((1-Ss)/(1-(Rr*Ss)));        %Numerator of correction factor

F_d1= 2-(Ss*(Rr+1-(sqrt(Rr^2+1))));
F_d2= 2-(Ss*(Rr+1+(sqrt(Rr^2+1))));
Deno_F=(Rr-1)*log(F_d1/F_d2);                           %Denominator of correction factor

F=num_F/Deno_F;                                         %Correction factor

%%
if U<0
    U=0;
end

%% Final UAF
UAF=U*Area*F;           %By delawara method
%UA1=U1*Area*F;         %By kern paper method

UAF=UAF*10^-3;
end
