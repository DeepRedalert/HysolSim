%Function file for Connect HT and LT with PTC

function [HT_out_temp,LT_out_temp]=PTC_HT_LT_connection(Tspan)

global PTC_SCF PTC_scf HT LT PTC_HT PTC_LT

%Connect HT with PTC
HT.moilin=PTC_scf.moil*3;           %Because 3 PTC loop, all loop behaviour concidered as same
HT.moilout=HT.moilin;
HT.hin=h_oil(PTC_SCF.Xintial(PTC_scf.grid));

HT_initial_temp=(-1.49681+sqrt(1.49681^2-4*0.0014*(-18.17454-PTC_HT.Xintial(2))))/(2*0.0014);
display('HT initial temperature');
HT_initial_temp;

display('HT inlet temperature');
HT_inlet_temp=(-1.49681+sqrt(1.49681^2-4*0.0014*(-18.17454-HT.hin)))/(2*0.0014);
HT_inlet_temp;

options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
[Ts,Y_HT]=ode15s(@HTtank,Tspan,PTC_HT.Xintial,options);
PTC_HT.Xintial=(Y_HT(length(Ts),:)');
HT.hout=PTC_HT.Xintial(2);
%opts = optimset('TolFun',1e-12,'Display','off') ;
%HT.Toout=fsolve('enthal_Temp_LT',HT.Toout,opts);

%Enthalpy polynomial fit equation:
%Enthalpy=(0.0014*T^2)+(1.49681*T)-18.17454; (TAken from thermino VP1 pdf file)
%Concidering only +ve part
HT.Toout=(-1.49681+sqrt(1.49681^2-4*0.0014*(-18.17454-HT.hout)))/(2*0.0014);
HT_out_temp=HT.Toout;
display('HT exit temp after integration')
HT_out_temp
%pause
%Connect LT with HT
LT.moilin=HT.moilout;
LT.moilout=LT.moilin;
LT.hin=h_oil(HT.Toout);

options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
[Ts,Y_LT]=ode15s(@LTtank,Tspan,PTC_LT.Xintial,options);
PTC_LT.Xintial=(Y_LT(length(Ts),:)');

LT.hout=PTC_LT.Xintial(2);
%opts = optimset('TolFun',1e-12,'Display','off') ;
%LT.Toout=fsolve('enthal_Temp_LT',LT.Toout,opts);

%Enthalpy polynomial fit equation:
%Enthalpy=(0.0014*T^2)+(1.49681*T)-18.17454; (TAken from thermino VP1 pdf file)
%Concidering only +ve part
LT.Toout=(-1.49681+sqrt(1.49681^2-4*0.0014*(-18.17454-LT.hout)))/(2*0.0014);
LT_out_temp=LT.Toout;

%LT again connected to PTC
PTC_SCF.Xintial(1)=LT.Toout;
% PTC_scf.moil=LT.moilout;
end