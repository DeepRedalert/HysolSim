function Hot_startup=day2(Type)
%No water loop here
clear all

global PTC_scf PTC_SCF  steamgen_LFR_bef_PTC  PTC_HT_OD w_iter_scf Type HT HX SH SG PH LT dt OP PTC_Fullplant LFRsim lfr_I_sec
global tim_iter phase_enth drum_msgen  LFR Drum SD first_LFR_IC break_time timestart break_time_stop Xa XA  Xax POW POWeT_pos_pow PTC_HT PTC_LT

global  stef_const msgenout PTC_scf_OD LFR_n Mode mwin_dear msgen_drum LFR_msteam
global SCF_TF_implic SCF_TA_implic SCF_TE_implic HT_Mass_implic  HT_Entha_implic theta  sin_zero steaystate

load Type.mat

%Load Day 1 saved variable values
if Type==0
    load Day1_over_Oil_Const.mat
elseif Type==1
    load Day1_over_Oil_step.mat
elseif Type==2
    load Day1_over_Oil_Real.mat
elseif Type==3
    load Day1_over_Oil_Quad.mat
end
%% All saved data of Day1(Last day) should be null or removed so that frest 2nd day (Next day) data will only store

%PTC
OP.SCF=[];
Eng_gain_arr_PTC=[];
Eng_gain_arr_PTC1=[];

%HT/LT
OP.LT=[];
OP.HT=[];
OP.LT_Temp=[];
OP.HT_Temp=[];

%SG
OP.SG_pressure=[];
OP.SGmsgen=[];
OP.SGTw=[SG.Twater];
OP.SG_temp=[];
OP.Tsteam=[];
OP.SGuaf=[];
OP.SGhtube=[];
OP.SGhshell=[];
OP.SGF=[];
OP.SGU=[];
XA.X_SG=[];

%SH/PH
OP.ph_twout=[];
OP.PH=[HX.PHintial];
OP.sh_tsout=[];
OP.SH=[HX.SHintial];
Xa.X_SH=[];
Xa.X_SH_U=[];
Xa.X_PH=[];
Tur.msin=[];
OP.SHU=[];
OP.SHF=[];
OP.SHhshell=[];
OP.SHhtube=[];
OP.SHuaf=[];
OP.PHU=[];
OP.PHF=[];
OP.PHhshell=[];
OP.PHhtube=[];
OP.PHuaf=[];

%Power
Xax.POW=[];
POW.ms_turb=[];
POW.Ts_turb=[];
pow_PTC_arr=[];
POWei.lfr_powgen=[];
POWeT.powgen=[];
POWeT_pos_pow.powgen=[];
pow_PTC_arr=[];
POW.ms_SG=[];

%Other
OP.I_solar=[];
OP.Ambient_T=[];
Xaxis=[];
Xaxis_water=[0];
TW_in_HX=[];
bypass_plant=0;
% note_time_day_end=[];
%% Initialization
time_run=1;
xx=1;
%% Second day simulation start ______ Initial condition for secnd day simulation

%%PTC
Amb_T=Ambient_Temp_ind(ip1);   %ip1=506 min i.e 8hr 43min, so at Amb_T is 506th value of Ambient temp which is basically when plant stop
% As in the morning ambient temp is same as evening temp (Last day evening temp taken)
PTC_SCF.Xintial=[Amb_T*ones(1,PTC_scf.grid)    Amb_T*ones(1,PTC_scf.grid)   Amb_T*ones(1,PTC_scf.grid)]';
PTC_SCF.Xintial1=PTC_SCF.Xintial;
PTC_Fullplant=0;

%% HT Tank
PTC_HT.Xintial(2)=h_oil(HT.Toout);  %Enthalpy of oil at cooldown temp
PTC_HT_OD=0;

%% LT tank
PTC_LT.Xintial(2)=h_oil(LT.Toout);  %Enthalpy of oil at cooldown temp


%% SG
HX.SGintial(2)= SG.Mw ;             %Mass of water (After cooldown)
HX.SGintial(3)= SG.Mw+SG.Msteam;    %Mass of system (After cooldown)
HX.SGintial(4)= SG.Msteam;          %Mass of steam (After cooldown)
SG.press_int=SG.press;              %Cooldown SG pressure as Initial SG pressure for Hot startup
Twat_SG= XSteam('Tsat_p',SG.press); %WAter temp at cooldown SG pressure
HX.SGintial(5)=XSteam('hL_p',SG.press);%Enthalpy of water at cooldown pressure
HX.SGintial(6)= SG.press;           %SG pressure (after cooldown)
SG.Twin=45;                         %75 oC to 45 oC taken as SG temp of water in
SG.boiling=1;                       %SG water boiling
SG.ODE=0.
%% SH
SH.ODE=0;                           %SH not connected

%% PH
PH.ODE=0;                           %PH not connected

%%
break_time_stop=0;                                          %Used for stop the plant if it is 1
simulation_next=0;                                          
start_sim_next=1;
plant_shut_down=0;

first_LFR_IC=1;
ip1=ip3;
timestart=break_time;
timestart=0;
timend=timestart+dt.scf;
dayss=2;
time_hour=9;
simu_time_end=time_hour*3600;
i=1;
w_iter_scf;
note_time_day_end=[0 note_time_day_end(end)];
%%
tic
while plant_shut_down==0

    while (SG.boiling==1  && PTC_Fullplant==0)              %Taking SG boiling already happaning because within the nigh time SG.boiling can not be zero
        for w_iter_scf=timestart:dt.scf:simu_time_end
            shut_boil=w_iter_scf

            PTC_scf.Toilin=LT.Toout;                        %LT oil outlet temperature goes to PTC inlet

            if  mod( w_iter_scf,60)==0                      %Solar radiation keep as zero order hold for 60 sec
                PTC_scf.I= lfr_I_sec(ip1);                  %Solar radiation
                Ambient_Temp=Ambient_Temp_ind(ip1);         %Ambiant temperature
                ip1=ip1+1;                                  %Updating ip1 for solar radiation value extracting
            end

            HX.Ambient_Tempr=Ambient_Temp;

            %For storing purpose
            OP.I_solar=[OP.I_solar PTC_scf.I];             
            OP.Ambient_T=[OP.Ambient_T Ambient_Temp];

            %Condition for Bypass HX
            if  PTC_SCF.Xintial(PTC_scf.grid) < HT.Toout                        %Output of PTC oil temp < 150
                PTC_HT_LTalone=1;                                               %PTC, HT, LT form route and bypass rest(HX)
            else
                PTC_HT_LTalone=0;                                               %PTC,HT,LT not alone, HX added
            end

            if PTC_HT_LTalone==1
                %% Oil loop

                %Connect PTC
                Tspan=[0  dt.scf];                                              %o to 1 second
                options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                [Ts,Y_SCF]=ode15s(@solarfield,Tspan,PTC_SCF.Xintial,options);   %Integrate PTC tank ODEs
                PTC_SCF.Xintial=(Y_SCF(length(Ts),:)');
                PTC_out_temp=PTC_SCF.Xintial(15)

                if (HT.Toout<= PTC_SCF.Xintial(PTC_scf.grid))                   %If 40 oC (HT initial temp) <= Oil output temp of PTC
                    %Connect PTC-HT-LT
                    PTC_HT_OD=1;                                                %Then connect HT with PTC together and LT
                    PTC_LT_OD=0;
                    [HT_out_temp,LT_out_temp]=PTC_HT_LT_connection(Tspan);      %Calling function file with connection of PTC-HT-LT
                else
                    %Connect PTC-LT
                    PTC_LT_OD=1;                                                %Connect PTC with LT only when HT temp >PTC outlet
                    PTC_HT_OD=0;
                    [LT_out_temp]=PTC_LT_connection(Tspan);                     %%Calling function file with connection of PTC-LT

                end

                %TO compute energy from PTC
                % [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);            %Function file calling for energy computation from PTC component
                % E_ptc_num=E_ptc_num+1;

            end

            if  PTC_HT_LTalone==0
                %% Oil loop

                %Connect PTC
                Tspan=[0  dt.scf];                                             %o to 1 second
                options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                [Ts,Y_SCF]=ode15s(@solarfield,Tspan,PTC_SCF.Xintial,options);  %Integrate PTC tank ODEs
                PTC_SCF.Xintial=(Y_SCF(length(Ts),:)');
                PTC_out_temp=PTC_SCF.Xintial(15)                               %PTC outlet temp

                %Connect HT with PTC
                HT.moilin=PTC_scf.moil*3;                                       %Mass of oil out from SCF enters to HT
                HT.moilout=HT.moilin;                                           %Mass of oil out from HT same as mass of oil in to HT
                HT.hin=h_oil(PTC_SCF.Xintial(PTC_scf.grid));                    %Enthalpy of oil in to HT

                if  PTC_HT_OD==1                                                %If HT tank temp <= PTC outlet temp
                    %Connect HT
                    options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                    [Ts,Y_HT]=ode15s(@HTtank,Tspan,PTC_HT.Xintial,options);     %ODE integration of HT
                    PTC_HT.Xintial=(Y_HT(length(Ts),:)');

                    HT.hout=PTC_HT.Xintial(2);                                  %Enthalpy of oil coming out from HT

                    HT.Toout=(-1.49681+sqrt(1.49681^2-4*0.0014*(-18.17454-HT.hout)))/(2*0.0014);   %At current enthalpy HT output temperature
                    HT_out_temp=HT.Toout;                                       %For saving HT outlet Temp

                    %Connect HT with SG_Subcooled
                    SG.moil=HT.moilout;                                         %The mass of oil coming from HT goes into SG
                    SG.Toilin=HT.Toout;                                         %Temp of oil to SG=HT temp of oil out
                else
                    %Connect HT with SG_Subcooled
                    SG.moil=PTC_scf.moil*3;                                     %Mass of oil out from SCF enters to SG (When HT not conected)
                    SG.Toilin=PTC_SCF.Xintial(PTC_scf.grid);                    %Outlet of SCF connected to SG
                end


                %At 1 bar saturation enthalpy of water is 417.44 kJ/kg (Check unit)
                SG.Wsat=XSteam('hL_p',SG.press_int);
                check_Wsat_SG=(SG.Wsat-HX.SGintial(5));

                SG.hs= XSteam('hV_p',HX.SGintial(6));
                SG.hw=XSteam('hL_p',HX.SGintial(6));

                %SG.mwin=0;

                %Connect SG_Saturated
                options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                [Ts,Y_HXSG]=ode15s(@HXSG_sat,Tspan,HX.SGintial,options);
                HX.SGintial=(Y_HXSG(length(Ts),:)');
                SG_pressure=HX.SGintial(6)
                SG.ODE=1;

                %To check is there any imaginary part
                nedstop=isreal(HX.SGintial);
                if (nedstop)==0   %has img part
                    disp('Imaginary number in HX.SGintial')
                end

                %To store the variables
                OP.SGuaf=[OP.SGuaf SG.UAF];
                OP.SGhtube=[OP.SGhtube  SG.htctube];
                OP.SGhshell=[OP.SGhshell SG.htcshell];
                OP.SGF=[OP.SGF SG.htcF];
                OP.SGU=[OP.SGU SG.htcU];

                %Connect LT with SG
                LT.moilin=SG.moil;  %Not in sir code why
                LT.moilout=LT.moilin;
                LT.hin=h_oil(HX.SGintial(1));

                options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                [Ts,Y_LT]=ode15s(@LTtank,Tspan,PTC_LT.Xintial,options);
                PTC_LT.Xintial=(Y_LT(length(Ts),:)');

                LT.hout=PTC_LT.Xintial(2);

                LT.Toout=(-1.49681+sqrt(1.49681^2-4*0.0014*(-18.17454-LT.hout)))/(2*0.0014);
                LT_out_temp=LT.Toout;

                PTC_SCF.Xintial(1)=LT.Toout;                                    %It may disturbe while saving OP.scf 1st temp so initialize before this

                %TO compute energy
                % [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);
                % E_ptc_num=E_ptc_num+1;

            end

            POW.ms_SG(w_iter_scf+1)=SG.msgen;
            POW.Ts_turb(w_iter_scf+1)=HX.SHintial(2);

            if SG.ODE==1
                TW_in_HX(w_iter_scf+1)=HX.Twin;
            end

            POWeT.powgen(w_iter_scf+1)=0;
            %end

            if  POWeT.powgen(w_iter_scf+1) >0
                POWeT_pos_pow.powgen(xx)=POWeT.powgen(w_iter_scf+1);
                xx=xx+1;
            else
                POWeT_pos_pow.powgen(xx)=0;
                xx=xx+1;
            end
            Xax.POW=[Xax.POW w_iter_scf];

            OP.Tsteam=[OP.Tsteam SG.Twater ];

            if  msgenout>0
                HX.mwin= msgenout;
                SG.mwin=HX.mwin;                                                %Mass of water going in to Sg
                PH.mwin=HX.mwin;                                                %Mass of water going in to PH
            else
                HX.mwin=0.5;
                SG.mwin=HX.mwin;                                                %Mass of water going in to Sg
                PH.mwin=HX.mwin;                                                %Mass of water going in to PH
            end

            % SG.mwin=HX.mwin;                                                %Mass of water going in to Sg
            % PH.mwin=HX.mwin;                                                %Mass of water going in to PH

            %For storing purpose
            PH.sav_mwin(w_iter_scf+1)=PH.mwin;                                    %Mass of water in to PH
            SG.sav_mwin(w_iter_scf+1)=SG.mwin;                                    %Mass of water in to SG
            HX.sav_mwin(w_iter_scf+1)=HX.mwin;                                    %Mass of water in to HX

            %TO compute energy
            [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);
            E_ptc_num=E_ptc_num+1;

            OP.SCF=[OP.SCF  PTC_SCF.Xintial];

            OP.HT_Temp=[OP.HT_Temp HT_out_temp];                                %Store HT temp
            OP.LT_Temp=[OP.LT_Temp LT_out_temp];                                 %Store LT temp

            if SH.ODE==1
                OP.SH=[OP.SH  HX.SHintial];
                Xa.X_SH=[Xa.X_SH w_iter_scf];
                %                 OP.SH1=[OP.SH1  HX.SHintial];
                OP.sh_tsout=[OP.sh_tsout SH.Tsout];
                Tur.msin=[Tur.msin SH.msin];
                OP.SHuaf=[OP.SHuaf SH.UAF];
                OP.SHhtube=[OP.SHhtube  SH.htctube];
                OP.SHhshell=[OP.SHhshell SH.htcshell];
                OP.SHF=[OP.SHF SH.htcF];
                OP.SHU=[OP.SHU SH.htcU];
                Xa.X_SH_U=[Xa.X_SH_U iter_scf];
            end

            if SG.ODE==1
                OP.SG_temp=[OP.SG_temp HX.SGintial(1)];
                OP.SGTw=[ OP.SGTw SG.Twater];
                XA.X_SG=[XA.X_SG w_iter_scf];
                OP.SGmsgen=[OP.SGmsgen SG.msgen];
                OP.SG_pressure=[OP.SG_pressure HX.SGintial(6)];
            end

            Xaxis=[Xaxis  w_iter_scf];
            %             Xaxis2=[Xaxis2  w_iter_scf];
            if length(OP.LT_Temp(1:end))~=  length(Xaxis)
                disp('See')
            end

            pow_PTC_arr=[pow_PTC_arr pow_PTC];

            if  HX.SGintial(6)>=SG.press_st && PTC_HT_LTalone==0 && PTC_HT_OD==1
                disp('pressure reached');
                pressure_now=HX.SGintial(6)
                PTC_Fullplant=1;
                break
            end
        end
    end

    timestart=Xaxis(end);
    disp('SG Pressure reached 40bar, Now Full plant will work')

    steamgen_LFR_bef_PTC=0;

    SG.hs_steam= XSteam('hV_p',HX.SGintial(6));

    SG.LFR_Tsout=SG.Twater;
    %end

    mix_sh_intial=[0 0];

    HX.Twin=(SG.Twater/250)*75;
    SG.Twin=HX.Twin;
    HX.PHintial(1)= HX.Twin+1;
    PH.ODE=1;
    HX.SHintial(2)=SG.LFR_Tsout+1;
    SH.ODE=1;
    SH.msin=abs(SG.msgen);
    count=0;

    SG.Twin
    %% Full HSTPP component connected
    while (PTC_Fullplant==1 && simulation_next==0 && PTC_HT_LTalone==0 )

        for w_iter_scf=(timestart+1):dt.scf:simu_time_end
            shut_fullplant=w_iter_scf;
            shut_fullplant

            PTC_scf.Toilin=LT.Toout;

            if  mod(w_iter_scf,60)==0
                PTC_scf.I= lfr_I_sec(ip1);
                Ambient_Temp=Ambient_Temp_ind(ip1);
                ip1=ip1+1;
            end

            HX.Ambient_Tempr=Ambient_Temp;

            %For storing purpose
            OP.I_solar=[OP.I_solar PTC_scf.I];
            OP.Ambient_T=[ OP.Ambient_T Ambient_Temp];

            %% Oil loop
            %Connect PTC

            Tspan=[0  dt.scf];                      %o to 1 second
            options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
            [Ts,Y_SCF]=ode15s(@solarfield,Tspan,PTC_SCF.Xintial,options);       %Integrate PTC tank ODEs
            PTC_SCF.Xintial=(Y_SCF(length(Ts),:)');
            PTC_out_temp=PTC_SCF.Xintial(15);

            %TO compute energy for PTC
            % [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);
            % E_ptc_num=E_ptc_num+1;

            %Connect full plant
            [HT_out_temp,LT_out_temp]=PTC_HT_SH_SG_PH_LT_connection(Tspan);

            if HX.SGintial(6)<40
                disp('SG pressure geting lower then SP pressure')
            end

            %%
            %For storing purpose
            POW.ms_SG(w_iter_scf+1)=SG.msgen;
            POW.ms_turb(w_iter_scf+1)=0+SG.msgen;
            POW.Ts_turb(w_iter_scf+1)=HX.SHintial(2);

            %Power generation   %Taken reference from Desai paper
            POWeT.Tot_ms=-0.263+ (0.668*POW.ms_turb(w_iter_scf+1) );
            POWei.oil_ms=-0.263+ ( 0.668*SG.msgen );
            pow_PTC= POWei.oil_ms;
            POWeT.CP=0.4+0.15*4;
            POWeT.temp=0.125+0.0025*POW.Ts_turb(w_iter_scf+1);
            POWeT.powgen(w_iter_scf+1)=POWeT.Tot_ms*POWeT.CP*POWeT.temp;

            if  POWeT.powgen(w_iter_scf+1) >0
                POWeT_pos_pow.powgen(xx)=POWeT.powgen(w_iter_scf+1);
                xx=xx+1;
            else
                POWeT_pos_pow.powgen(xx)=0;
                xx=xx+1;
            end
            Xax.POW=[Xax.POW w_iter_scf];

            if SG.ODE==1
                TW_in_HX(w_iter_scf+1)=HX.Twin;
            end

            if  msgenout>0
                HX.mwin= msgenout;
                SG.mwin=HX.mwin;                                                %Mass of water going in to Sg
                PH.mwin=HX.mwin;                                                %Mass of water going in to PH
            else
                HX.mwin=0.5;
                SG.mwin=HX.mwin;                                                %Mass of water going in to Sg
                PH.mwin=HX.mwin;                                                %Mass of water going in to PH
            end

            % SG.mwin=HX.mwin;                                                %Mass of water going in to Sg
            % PH.mwin=HX.mwin;                                                %Mass of water going in to PH

            %For stroign purpose
            PH.sav_mwin(w_iter_scf+1)=PH.mwin;
            SG.sav_mwin(w_iter_scf+1)=SG.mwin;
            HX.sav_mwin(w_iter_scf+1)=HX.mwin;

            %TO compute energy
            [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);
            E_ptc_num=E_ptc_num+1;

            %% To save variables
            Xaxis=[Xaxis  w_iter_scf];
            OP.SCF=[OP.SCF  PTC_SCF.Xintial];                                   %Store PTC temp
            OP.HT_Temp=[OP.HT_Temp HT_out_temp];
            OP.LT_Temp=[OP.LT_Temp LT_out_temp];
            OP.HT=[OP.HT PTC_HT.Xintial];
            OP.LT=[OP.LT PTC_LT.Xintial];

            if length(OP.LT_Temp(1:end))~=length(Xaxis)
                disp('See')
            end

            if SH.ODE==1
                OP.SH=[OP.SH  HX.SHintial];
                OP.sh_tsout=[OP.sh_tsout SH.Tsout];             %TO store steam outlet temp of SH
                Xa.X_SH=[Xa.X_SH  w_iter_scf];
                Tur.msin=[Tur.msin SH.msin];                                    %Mass flow rate of steam out from SH and going in to Turbine
                OP.SHuaf=[OP.SHuaf SH.UAF];
                OP.SHhtube=[OP.SHhtube  SH.htctube];
                OP.SHhshell=[OP.SHhshell SH.htcshell];
                OP.SHF=[OP.SHF SH.htcF];
                OP.SHU=[OP.SHU SH.htcU];
                Xa.X_SH_U=[Xa.X_SH_U iter_scf];
                %                 sh_tsout=[sh_tsout SH.Tsout];   %To store steam outlet temp of SH
            end

            if PH.ODE==1
                OP.PH=[OP.PH  HX.PHintial];
                OP.ph_twout=[OP.ph_twout PH.Twout];             %TO store water outlet temp of PH
                Xa.X_PH=[Xa.X_PH  w_iter_scf];
            end

            if SG.ODE==1
                OP.SG_temp=[OP.SG_temp HX.SGintial(1)];
                OP.SGTw=[OP.SGTw SG.Twater];
                XA.X_SG=[XA.X_SG  w_iter_scf];
                OP.SGmsgen=[OP.SGmsgen SG.msgen];
                OP.SG_pressure=[OP.SG_pressure HX.SGintial(6)];
            end

            OP.Tsteam=[OP.Tsteam SG.Twater];
            pow_PTC_arr=[pow_PTC_arr pow_PTC];             %power generation from PTC
            %%
            %Condition for Stop the plant
            if Type==0
                if w_iter_scf>=(simu_time_end-1)%32339 instead of 32399
                    break_time_stop=1;
                    day_count=day_count+1;
                    note_time_day_end=[note_time_day_end iter_scf];
                    note_time_LFR=[note_time_LFR time_run+1];
                    iter_scf_1=iter_scf +4*3600;                            %iter_scf is the just before stop the plant. iter_scf_1 is 4 hrs after the plant stops. (Both in seconds)
                    ip2=ip1+(4*60);                                         %ip2 is basically updated ip1 after 4 hrs. (ip1 updated after every 60 sec)
                    simulation_night=1;                                     %Nighttime cooling will start
                    break_time_stop=1;
                    break
                end
            else
                PTC_SCF.Xintial(PTC_scf.grid)
                if  (PTC_SCF.Xintial(PTC_scf.grid)) < 300 &&  HT.Toout < 300
                    PTC_SCF.Xintial(PTC_scf.grid)
                    stop_time_1=w_iter_scf;
                    bypass_plant=bypass_plant+1;

                    if  bypass_plant > 300 %5 min repeated
                        if bypass_plant==299
                            disp('Check')
                        end
                        day_count=day_count+1;
                        note_time_day_end=[note_time_day_end w_iter_scf];
                        w_iter_scf_1=w_iter_scf +1*3600;
                        w_iter_scf21=ip1+(1*60);
                        simulation_night=1;
                        simulation_next=1;
                        break  %Go to simulation_night==1
                    end
                end
            end
        end

        if  simulation_night==1
            disp('Break in full plant occur');
            PTC_Fullplant=0;
        end

        leng_shut_down= length(note_time_day_end);

        if  (leng_shut_down == dayss+1)
            plant_shut_down=1;
            break;
        end

    end

    %%
    if  plant_shut_down==1
        disp(' Plant run for days is Over');
        break;
    end
end
Simu_time=toc


%Time axis converted to Seconds to Hours.
Xaxis=Xaxis/3600;  %3600 (sec) instant converted to 1 (hr)
Xa.X_SH=Xa.X_SH/3600;
XA.X_SG=XA.X_SG/3600;
Xa.X_PH=Xa.X_PH/3600;

if Type==0
    save('Day2_over_Oil_Const')
elseif Type==1
    save('Day2_over_Oil_step')
elseif Type==2
    save('Day2_over_Oil_Real')
elseif Type==3
    save('Day2_over_Oil_Quad')
end
Hot_startup=1;

end