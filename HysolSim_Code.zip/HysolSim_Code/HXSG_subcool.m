% Main file for SG subcooled. Here no change in pressure. Whatever water
% coming in it get accumulated and temperature and enthalpy will increase.
% Pressure change only occure in saturation condition.

function [dHX_SG] =HXSG_subcool(t,T)

global SG HX

SG.Toout=T(1);              %Temp of oil out
SG.Mw=T(2);                 %Mass of water inside the SG
SG.Msteam=T(4);             %Mass of steam
SG.hw=T(5);                 %Enthalpy of water inside SG            Kg*
SG.press=T(6);              %SG Pressure

% msout=0;                    %Mass os steam out
% msgen=0;                    %Mass of steam generation

if SG.mwin==0               %mass of water in
    SG.Twin=0;              %Temp of water in     
    SG.hwin=0;              %Enthalpy of water in
else
    SG.hwin=XSteam('h_pT', SG.press,SG.Twin);       
end

SG.Twater=XSteam('T_ph', SG.press,SG.hw);       %Temp of water inside SG

%% Function for calculating UAF
if  SG.mwin==0
    SG.UAF =UAF_SG_sub_mw0(SG.moil,SG.Toilin,SG.Toout, SG.mwin,SG.Twin,SG.Twater, SG.press);%wHAT IS THE DIFF? NOT USED ? IN CONTROL?
else
    [SG.UAF,SG.htctube,SG.htcshell, SG.htcF,SG.htcU]=UAF_SG_sub_fun(SG.moil,SG.Toilin,SG.Toout, SG.mwin,SG.Twin,SG.Twater, SG.press);
end
SG.UAF=0.6*SG.UAF;


%% Calculation of LMTD

SG.hot=SG.Toilin - SG.Twater;           %Hot side temp diff
SG.cold=SG.Toout- SG.Twin;              %Cold side temp diff
oilside= (SG.Toilin+SG.Toout)/2;        %Avg oil temp for PH in and out
waterside= (SG.Twater+SG.Twin)/2;       %Avg water temp for PH in and out

if (SG.hot/SG.cold)==1 || ( SG.Twin > SG.Toout )|| (SG.Twater > SG.Toilin)
    SG.Lmtd=oilside-waterside;
    disp('AR SG');
else
    SG.Lmtd=(SG.hot-SG.cold)/( log(SG.hot/SG.cold) );       %LMTD
end
%% Some parameter calculation

%lm_sg=SG.Toout-SG.Twater;
oil_diff_sg=SG.Toilin - SG.Toout;           %Temp diff of oil of in & out of SG
oil_avg_sg=(SG.Toilin+ SG.Toout)/2;         %Avg Temp of oil of in & out of SG: HOT
cold_avg_sg=(SG.Twater+ SG.Twin)/2;         %Avg Temp of water of in & out of SG: COLD
SG.AMTD=(oil_avg_sg-cold_avg_sg);           %Avg temp diff of hot and cold fluid
%% Oil side temp equation is same as PH & SH. Not mentioned in IECER paper.   1.

deno_HX_3=(SG.tube_side_volume*SG.Toout*density_oil(SG.Toout)*dbyCp_sf (SG.Toout)*10^(-3))+...
    (SG.tube_side_volume*SG.Toout*dbyden_sf(SG.Toout)*Cp_oil(SG.Toout) * 10^(-3))+...
    (SG.tube_side_volume*density_oil(SG.Toout)*Cp_oil(SG.Toout) * 10^(-3));

dTdt3=((SG.moil*(Cp_oil(oil_avg_sg)*10^(-3))*(oil_diff_sg))-(SG.UAF*SG.Lmtd)-...
    (SG.Uloss*SG.loss_A*(SG.Toilin- HX.Ambient_Tempr)))/ (deno_HX_3);
%% Water temperature profile   

%Equation no 23 in IECER paper: Mass balance    
dmwatbydt=SG.mwin;      %Mass of water                            2.
dmsysbydt=SG.mwin;      %RAte of change of Mass of system=Mass flow rate of water   3.
dmsteabydt=0;           %Mass of steam                                      4.
%Equation no 24 in IECER paper: Energy balance                              5.
dhwbydt= ((SG.mwin*(SG.hwin-SG.hw))+(SG.UAF*SG.Lmtd)-(SG.Uloss*SG.loss_A*(SG.Toilin- HX.Ambient_Tempr)))/ SG.Mw;    %Enthalpy of water
dpbydt=0;               %Rate of change of pressure: For subcooled no change in pressure   6.

%msgen=0;                
SG.msgen=0;             %Mass of steam generation
%dpx=0;
%hs= XSteam('hV_p',SG.press);
%hw=XSteam('hL_p',SG.press);

dHX_SG=[dTdt3 dmwatbydt dmsysbydt dmsteabydt dhwbydt dpbydt]';   %Return all 6 output
%**[Rate of change of oil, Mass flow rate of water,Mass of system,Mass flow rate of steam, Enthalpy of water, Pressure]

end