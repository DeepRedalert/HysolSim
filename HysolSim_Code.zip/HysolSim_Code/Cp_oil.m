%Function file for Specific heat capacity oil flowing in towards PH

function [Cp]=Cp_oil(T)
Cp=(0.002414*T)+(5.9591*10^-6*(T^2))+(-2.9879*10^-8*T^3)+( 4.4172*10^-11*T^4  )+1.498;       %KJ/Kg.K
Cp=Cp*1000;
end

%% Other polynomial fit

%2nd order fit
% Cp=(0.003313*T)+(0.0000008970785*(T^2))+1.496005;                                          %KJ/Kg.K
% Cp=Cp*1000;

%4th order fit
%Cp=(3.79511*10^(-11)*T^4)-(2.50280*10^(-8)*T^3)+(4.74208*10^(-6)*T^2)+2.52123*10^(-3)*T+1.49573
%Cp=Cp*1000;
