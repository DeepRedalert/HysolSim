%Function file for Derivative Specific heat capacity (Cp)
%This is for Therminol-PV1 (Polynomial fit is taken from Therminol-pv1 PDF)

function [dcpbydt]=dbyCp_sf(T)

dcpbydt=(0.002414)+(5.9591*10^-6*(2*T))+(-2.9879*10^-8*3*T^2)+( 4.4172*10^-11*4*T^3);       %KJ/Kg.K
dcpbydt=dcpbydt*1000;

end
