%Function file for calculating Enthalpy of HT oil

function f=enthal_Temp_HT(hoilout_HT)

global HT 

   f=h_oil(hoilout_HT)-HT.hout;            %KJ/Kg
   
end