%% HT storage tank function file

%%
function [dT_HT] =HTtank(t,T)

global HT
global PTC_HT_OD

%T(1)=Mass of oil present in HT
%T(2)=Enthalpy of oil flowing out of HT

if  PTC_HT_OD==0
    Maccumulation_HT=0;                         %Mass accumulation in HT
    dh_HT_tank=0;                               %Enthalpy of oil flowing out of HT
else
    Maccumulation_HT=HT.moilin- HT.moilout;     %Mass accumulation in HT, Equation 15a in IECER paper
    %Total_Mass_HT=HT.int_Mass+Maccumulation_HT;
    enthalpy_HT=T(2);                           %Enthalpy of oil flowing out of HT
    dh_HT_tank=(((HT.moilin*HT.hin)-(HT.moilout*enthalpy_HT)-(enthalpy_HT*(HT.moilin-HT.moilout)))/T(1));   %Enthalpy of oil flowing out of HT, equation 15b in IECER paper
    %Not matching with equation, loss term not here
end
dT_HT=[Maccumulation_HT  dh_HT_tank]';
end