% Script file for set parameters value and solar radiation type

%_____________________________________Combine plant____________________________________________
clc
clear all
close all


Type=input(['Choose for which solar radiation need to simulate.' ...
        '\n Select Types of Solar radiation you want to simulate for, ' ...
        '\n 1. Constant Solar radiation Type "0" ' ...
        '\n 2. Constant with step change radiation Type "1" ' ...
        '\n 3. Real-time Solar radiation Type "2" ' ...
        '\n 4. Quadratic Solar radiation Type "3" ' ...
        '\n \n Type:']);

disp('Please wait')

global PTC_scf PTC_SCF  steamgen_LFR_bef_PTC PTC_scf_OD PTC_HT_OD
global dt stef_const
global SCF_TF_implic SCF_TA_implic SCF_TE_implic

global HT HX SH SG PH LT
global HT_Mass_implic  HT_Entha_implic

global OP PTC_Fullplant LFRsim  lfr_I_sec 
global theta  sin_zero steaystate tim_iter phase_enth

global msgen_drum drum_msgen mwin_dear 

global single_scaling two_scaling
global LFR Drum  Dear SD first_LFR_IC iter_scf

global U he_supp lfr_press_sec  dru_press_sec hwin_dear   msteam_lfr Two  Two_sec   dea_flo phase_pipeend
global delta_absor dt_par Tabsor_pre hs_drum hp rho P h u T x TAbo  Tglass Ck  hpp Ckk g dpbydt  scfhp LFR_Temp_WAT LFR_msteam


%% Initialization of PTC Solar collector field

PTC_scf_OD=1;
%Absorber pipe parameters
PTC_scf.leng=500;                     %Total PTC length                                      m                   
PTC_scf.grid=15;                      %15 grid point of PTC                                                                     
PTC_scf.dx=PTC_scf.leng/PTC_scf.grid;                   
PTC_scf.rai=0.025;                    %Inner absorber pipe radius                            m  
PTC_scf.rao=0.03;                     %Outer absorber pipe radius                            m
PTC_scf.pai=2*pi*PTC_scf.rai;         %Inner absorber pipe perimeter                         m
PTC_scf.pao=2*pi*PTC_scf.rao;         %Outer absorber pipe perimeter                         m
PTC_scf.Aai=pi*PTC_scf.rai^2;         %Inner absorber pipe cross sectional area              m^2
PTC_scf.Aao=pi*PTC_scf.rao^2;         %Outer absorber pipe cross sectional area              m^2
PTC_scf.ea=0.18;                      %Emissivity of absorber pipe
PTC_scf.den_abso=7850;                %Absorber pipe density                                 kg/m^3
PTC_scf.CPabso=0460;                  %Specific heat capacity of absorber pipe               J/kg/K
% Glass envelope parameters
PTC_scf.Ae=2.8*10^-3;                 %Glass envelope cross sectional area                   m^2, *3.4 changed to 2.8 by Deep
PTC_scf.rei= (sqrt(PTC_scf.Ae/pi));   %Inner glass envelope radius                           m
PTC_scf.reo=PTC_scf.rei+0.001;        %Outer glass envelope radius                           m
PTC_scf.Aeo=pi*PTC_scf.reo^2;         %Outer glass envelope cross sectional area             m^2
PTC_scf.peo=(sqrt(PTC_scf.Aeo/pi))*2*pi;%Outer glass envelope parimeter                      m
PTC_scf.ee=0.9;                       %Emissivity of glass envelope
PTC_scf.den_gla=2400;                 %Glass envelope density                                kg/m^3
PTC_scf.ce_gla=0840;                  %Specific heat capacity of glass envelope              J/kg/K

PTC_scf.Toilin=230;                   %temperature of oil in flow                            Degree C       For alone PTC control it is constant
PTC_scf.moil=3;                       %Mass flow rate of HTF flowing in                      kg/s     (Mass/Time)
stef_const=5.670*10^-8;               %Stefan-Boltzmann constant                             W/(m^2 K^4)
PTC_scf.I=600;                        %Solar radiation incident on PTC collector surface     W/m^2
PTC_scf.effici=0.4;                   %Total optical efficiency of PTC 
PTC_scf.aper_wid=5.75;                %width of collector/mirror aperture                    m
PTC_scf.Tsky=40;                      %Effective sky temperature                             oC
PTC_scf.hair=25;                      %Convective heat transfer coefficient of Air-glass envelope     W/(m^2 oC)
PTC_scf.Tair=25;                      %Ambient temperature                                   oC

PTC_Fullplant=0;
Eng_gain_arr_PTC1=[];

E_ptc_num=1;
%% Initialization of HT
PTC_HT_OD=0;

HT.Vsys=20;                           %Not used here, Volume of the HT tank            m^3 =20,000 kg of liquid
HT.Tintial= 40;                       %Temp of oil at initial                          oC
HT.int_Mass=1440*pi;
%HT.int_Mass=15000;
dt.HT=1;                              %NOT USED HERE
HT.Ditank=2;                          %Daimeter of HT tank                             m
HT.radi=( HT.Ditank/2);               %Radius of HT tank                               m
HT.CSA=pi*( HT.Ditank^2)/4;           %Cross sectional Area                            m^2               
HT.height=6.5;                        %Height of HT tank                               m
HT.moilin=PTC_scf.moil*3;             %Mass flow rate of oil entering HT               kg/s
HT.moilout=PTC_scf.moil*3;            %Mass flow rate of oil flowing out of HT         kg/s      
HT.int_hei_oil=(HT.int_Mass/(density_oil(HT.Tintial)*HT.radi^2));   %NOT USED HERE
HT.Toout= HT.Tintial;                 %Temperture oil out from HT                      oC
HT_out_temp=HT.Tintial;
U.HT_night=0.22;
%% Heat exchanger initialisation
HX.Twin=30;
HX.mwin=0.5;

%% Initialization of SH
SH.check1=1;
SH.ODE=0;
SH.No_tubes = 73;                               %No of SH tubes 
SH.tube_length = 2.928*1;                       %Tube length                      m
SH.tube_ID = (15.875 - (2*2.3))*10^-3;          %SH Tube inner diameter           m
SH.tube_OD = 15.875*10^(-3);                    %SH Tube outer diameter           m
SH.shell_length = 2.992;                        %Shell length                     m
SH.shell_ID = 0.375;                            %Shell inner diameter             m 
SH.nopass_t=2;                                  %No of passes                     
SH.tube_side_volume = pi*(SH.tube_ID/2)^2*SH.tube_length*SH.No_tubes*2;   %Tube side volume        m^2
SH.shell_side_volume = (pi*(SH.shell_ID/2)^2*SH.shell_length)-(pi*(SH.tube_OD/2)^2*SH.tube_length*SH.No_tubes*2);   %Shell side volume        m^2
SH.Uloss=0.22;                                  %HTC for heat loss                W/(m^2.K)
SH.loss_A=3;                                    %Area of HTC in terms of loss     m^2
SH.Mass_oil=200;                                %Mass of oil                      ?
Tur.msin=[];                                    %Null array to save the mass flow rate of steam out from SH and going in to Turbine
% sh_tsout=[];                                  %Null array to save the steam outlet temp from PH
Xa.X_SH_U=[];
%% Initialization of SG
SG.radius=0.860;                                %NOT USED HERE
SG.L=6.86;                                      %Length of SG(Not tube length)                      m
SG.Vsys=16;                                     %Volume of system                                   %(16)  pi*0.860^2*6.6
SG.Twat=HX.Twin;                                %Temp of water in SG        0C, *Need value of this
SG.intial_Mw=1000;                              %mass of water in SG        kg
SG.Msteam=1;
SG.Mmeta=8500;                                  %Mass of metal
SG.Cpmeta=460;                                  %Specific heat capacity of metal
SG.mwin=HX.mwin;                                %flow rate
SG.Twin=HX.Twin;
SG.Twat=35;                                     %Temperature of water
SG.Twater=SG.Twat; 
SG.msgen=0;                                     %Initial mass of steam generation
SG.press_int=1;                                 %SG initial pressure                                bar
SG.press=SG.press_int;
denS_drum=XSteam('rhoV_p',SG.press_int);
denW_drum=XSteam('rho_pT',SG.press_int,SG.Twat);
Vol_water= SG.intial_Mw/denW_drum;              %Volume of water in SG
Vol_steam=SG.Vsys-Vol_water;                    %Volume of steam in SG
SG.Msteam=Vol_steam* denS_drum;                 %MAss of steam  
SG.No_tubes = 75;                               %No of tubes in SG
SG.tube_length = 5.8*1;                         %SG tube length                m
SG.tube_Id = (25.4 - (2*2.3))*10^-3;            %SG inner diameter of tube     m
SG.tube_OD = 25.4*10^(-3);                      %SG tube outer diameter        m
SG.shell_length_cyl = 5.8-(1.383);              %NOT IN USED
SG.shell_length_con = 1.383;                    %NOT IN USED
SG.shell_ID_cyl = 1.2;                          %NOT IN USED
SG.shell_ID_con = 0.6;                          %NOT IN USED            
SG.tube_side_volume = pi*(SG.tube_Id/2)^2*SG.tube_length*SG.No_tubes*2;      %SG tube side volume      m^3
SG.hwoutX=XSteam('h_pT',SG.press_int,SG.Twat);  %Entalpy as a function of pressure and temperature.
SG.loss_A=10;                                   %Area of HTC in terms of loss     m^2
SG.Uloss=0.22;                                  %HTC for heat loss                W/(m^2.K)
SG.boiling=0;
SG.press_st=40;
HX.SG_night_press_arr=[];           %Null array for SG night pressure store
SG.m_cond_SG_arr=[];                %Null array for SG mass of condensation store
SG_MW=[];                           %Null array for SG mass of water store    
SG_MS=[];                           %Null array for SG mass of steam store
SG.ODE=0;
shut_cou_sg=1;
U.SG_night=0.22;
%% Initialization of PH
PH.ODE=0;
PH.No_tubes = 37;                       %No of PH tubes 
PH.tube_length = 4.225*1;               %Tube length
PH.tube_ID = (15.875 - (2*2.3))*10^-3;  %PH Tube inner diameter    
PH.tube_OD = 15.875*10^(-3);            %PH Tube outer diameter    
PH.shell_length = 4.836-(0.415);        %Shell length
PH.shell_ID= 12*0.0254;                 %Shell inner diameter
PH.tube_side_volume = pi * (PH.tube_ID/2)^2 * PH.tube_length * PH.No_tubes*2;                                               %PH tube side volume
PH.shell_side_volume = (pi*(PH.shell_ID/2)^2*PH.shell_length)-(pi*(PH.tube_OD/2)^2*PH.tube_length*PH.No_tubes*2);           %PH Shell side volume
PH.sav_mwin(1)=HX.mwin;
PH.Toilin=39;                           %HX.SGintial(1), from below
PH.Mass_oil=200;                        %Mass of Oil in PH                kg
PH.Uloss=0.22;                          %HTC for heat loss                W/(m^2.K)
PH.loss_A=4;                            %Area of HTC in terms of loss     m^2
PH.ODE=1;
ph_twout=[];                        %Null array to save the water outlet temp from PH
%% Initialization of LT
LT.Vsys=20;                             %Not used here
LT.Tintial= 40;                         %Temp of oil at initial                          oC
LT.int_Mass=(1440*pi*1);
%LT.int_Mass=15000;
PTC_LT_OD=1;
dt.LT=1;
LT.Ditank=2;                            %Diameter of LT tank                             m
LT.radi=( LT.Ditank/2);                 %Radius of LT tank                               m
LT.CSA=pi*( LT.Ditank^2)/4;             %Cross sectional Area                            m^2
LT.height=6.5;                          %Height of LT tank                               m
LT.moilin=PTC_scf.moil*3;               %Mass flow rate of oil entering LT               kg/s
LT.int_hei_oil=(LT.int_Mass/(density_oil(LT.Tintial)*LT.radi^2));   %NOT USED HERE
PTC_LT.Xintial=[ LT.int_Mass  h_oil(LT.Tintial)]';
LT.Toout= LT.Tintial;                   %Temperture oil out from LT                      oC
LT_out_Temp=LT.Tintial;
U.LT_night=0.22;
%% Initialization of SD
SD.Vsys=6;                              %Volume of SD                       m^3
SD.radi=0.8;                            %SD redius, NOT USED HERE           m
SD.heig=3;                              %Height of SD, NOT used here        m
Drum.Temp_wat= HX.Twin;                 %Temp of water in SD                0C
Drum.Mass=4000;
Drum.Mass_wat=Drum.Mass;                %Initial mass of water in SD        kg
Drum.Vsys=SD.Vsys;                      %Volume of SD                       m^3    
Drum.press=1;                           %Drum initial pressure              bar
Drum.int_Tsat=XSteam('Tsat_p',Drum.press);%Saturation temperature           0C
Drum.hwat=XSteam('h_pT',Drum.press,Drum.Temp_wat)*1000 ;    %Entalpy as a function of pressure and temperature.
Drum.den_steam=XSteam('rhoV_p',Drum.press); %Saturated vapour density
Drum.rho_st= Drum.den_steam;            %Density of steam present in SD     kg/m^3
Drum.den_wat=XSteam('rho_pT',Drum.press,Drum.Temp_wat); %Density of water in SD     kg/m^3
Drum.Vol_wat= Drum.Mass/Drum.den_wat;  %Volume of water in SD              m^3
Drum.Vol_steam=Drum.Vsys-Drum.Vol_wat;  %Volume of steam in SD              m^3
Drum.Mass_steam=Drum.Vol_steam*Drum.den_steam;  %Mass of steam in SD        kg
Drum.msgen=0;                           %Initially mass of steam generation    kg
Drum.hst=(XSteam('hV_p',Drum.press))*1000;%Saturated vapour enthalpy, Enthalpy of steam
Drum.exit_press=40;                     %Drum exit pressure                 bar
Drum.valve_constant=0.2/(sqrt(2));      %Drum valve constant
SD.press_st=41;                         %SD setpoint pressure               bar
drum_Mass(1)=Drum.Mass_wat+Drum.Mass_steam; %Initial total Drum mass        kg
drum_Mass_wat(1)=Drum.Mass_wat;             %Initial mass of water in SD    kg
drum_Mass_steam(1)=Drum.Mass_steam;         %Initial mass of steam in SD    kg
drum_pressure(1)=Drum.press;                %Initial drum pressure          bar
Drum.fraction_ms_out=0.3;               %NOT USED IN HERE ??
SD.ODE=0;
IP_mwin_flag=0;
SD.IP_mwin_time=[];
XA.X_SD=[];
shut_cou_sd=1;
U.SD_night=0.22;
drum_hsteam(1)=Drum.hst*10^-3;
drum_row_st(1)=Drum.rho_st;                                                 %Density of steam present in SD     kg/m^3
drum_hwat(1)=Drum.hwat*10^-3;                            %Enthalpy of water
Twin_SD_axis=[];
Twin_SD=[];
TW_in_HX=[];  
Xax.SD_steam=[0];
Xax.SD=[0];

%% Initialization of LFR
% LFR.Press_in=5;                        %LFR initial pressure               bar
LFR.Press_in=45;                        %LFR initial pressure               bar
LFR.mwater_pipeout8=0;
LFR.msteam_pipeout8=0;
LFR.Twin=Drum.Temp_wat;                 %From SD water is coming
LFR.mw_indi=0.3;                        %Mass flow rate of water flowing in            kg/s
LFR.nos_pipe=8;                         %No of pipes
LFR.total_mw_in=LFR.nos_pipe*LFR.mw_indi;   %2.4 kg/s is coming/8 pipes=1 pipe flow
LFR.Length=480;                         %LFR length                         m
LFR.points=LFR.Length*1;               %Points: Length*(Grid point per meter)        
LFR.g=9.8;                              %Gravity                            m/s^2
LFR.sig=5.670*10^-8;                    %Stefan-Boltzmann constant          W/(m^2 K^4)
LFR.no=0.22;                            %Total optical efficiency of LFR
LFR.width=14;                           %width of collector/mirror aperture    m

% Absorber pipe Parameters
LFR.rai_ab=0.027/2;                     %Inner Radius of absorber pipe                         m
LFR.rao_ab=0.03/2;                      %Outer absorber pipe radius                            m
LFR.dia_ab=LFR.rai_ab*2;                %Diameter of absorber pipe                             m
LFR.pai=2*pi*LFR.rai_ab;                %Inner absorber pipe perimeter                         m
LFR.pao=2*pi*LFR.rao_ab;                %Outer absorber pipe perimeter                         m
LFR.Aai=pi*LFR.rai_ab^2;                %Inner absorber pipe cross sectional area              m^2
LFR.Aao=pi*LFR.rao_ab^2;                %Outer absorber pipe cross sectional area              m^2
LFR.den_abso=7850;                      %Absorber pipe density                                 kg/m^3
LFR.Cp_abso=0460;                       %Specific heat capacity of absorber pipe               J/kg/K
LFR.ea=0.18;                            %Emissivity of absorber pipe

% Glass envelope parameters
LFR.Ae=3.4*10^-3;                       %Glass envelope cross sectional area                   m^2
LFR.rei= (sqrt(LFR.Ae/pi));             %Inner glass envelope radius                           m
LFR.reo=LFR.rei+0.001;                  %Outer glass envelope radius                           m
LFR.Aeo=pi*LFR.reo^2;                   %Outer glass envelope cross sectional area             m^2
LFR.peo=(sqrt(LFR.Aeo/pi))*2*pi;        %Outer glass envelope parimeter                        m
LFR.den_gla=2400;                       %Glass envelope density                                kg/m^3
LFR.Ce_gla=0840;                        %Specific heat capacity of glass envelope              J/kg/K
LFR.rei= 0.25;                          %Inner glass envelope radius                           m
LFR.Aei=pi*LFR.rei^2;                   %Inner glass envelope cross sectional area             m^2
LFR.ee=0.9;                             %Emissivity of glass envelope
LFR.Tsky=40;                            %Effective sky temperature                             oC
LFR.hair=0.0250;                        %Convective heat transfer coefficient of Air-glass envelope     W/(m^2 oC)
LFR.Tair=10;                            %Ambient temperature                                   oC  
LFR.dx=LFR.Length/LFR.points;           %LFR segment length                                    m

E_lfr_num=1;
note_time_LFR=[];
Eng_gain_arr_LFR1=[];
%% Initiale value for LFR 
LFR.break1=0;
LFR.break_count=0;
LFR.hin=XSteam('h_pT',LFR.Press_in,LFR.Twin);                %Entalpy as a function of pressure and temperature        kJ/kg
LFRsim.h(1,1)=LFR.hin*1000;                                  %Specific Enthalpy                                        J/kg  
LFRsim.P(1,1)=LFR.Press_in;                                  %Pressure=45bar (Initialisation)                          bar
LFRsim.rho(1,1)=XSteam('rho_ph',LFR.Press_in,LFR.hin);       %Density as a function of pressure and enthalpy           kg/m^3
vis_L(1,1)=XSteam('my_ph',LFRsim.P(1,1),LFRsim.h(1,1)*10^-3);%Dynamic Viscosity as a function of pressure and enthalpy
LFRsim.T(1,1)=LFR.Twin;                                      %Temp of water in to LFR (Initial)       0C
volumetric=LFR.mw_indi/LFRsim.rho(1,1);                      %volumetric flow rate=Mass flow rate/Density
velocity=(1.2734*volumetric)/(LFR.dia_ab^2);                 %V=Q/A or V=(4/pi)*(Q/d^2)
LFRsim.u(1,1)=velocity;                                      %Velocity of the fluid
LFRsim.x(1,1)=LFRsim.rho(1,1);                               %LFRsim.x NOT USED HERE
LFRsim.Tabo(1,1)=LFR.Twin;                                   %Initial temp of absorber pipe of LFR
LFR.Tfluid=LFR.Twin;                                         %Initial temp of water in LFR
REY=(LFRsim.rho(1,1)*LFRsim.u(1,1)*LFR.dia_ab)/vis_L(1,1) ;  %Reynolds number=(Fluid density*Fluid velocity*Pipe diameter)/Fluid dynamic viscosity
f=ffrough(REY, LFR.dia_ab, 0);                               %Used to calcultae friction no
LFRsim.Ck(1,1)=f/(2*LFR.dia_ab);                             %Friction factor
LFRsim.phase=0;                                              %No steam prom LFR yet produced

%%
bypass_plant=0;
% speed_sound=XSteam('w_pT',LFR.Press_in,LFR.Twin);%Speed of sound as a function of pressure and temperature.
% dtt=LFR.dx/(2*speed_sound);                      %We should not run the simulation less than dtt.....NOT USED HERE
steaystate=0;                                      %Not in steadystate

%Simulation Time
Days=2;                                         %Total number of days for simulation
time_hour=Days*24;                              %Total number of hours for simulation
% time_hour=9;
simu_time_end=time_hour*3600;                    %in to seconds (Total number of seconds for simulation )
hour_s=time_hour;                                %48 hours

%Tramsient/Steadystate condition
if steaystate==0                                 %For transient condition
    LFR.dt=60;
    LFR.tot_run=(hour_s*3600)/LFR.dt;            %(48*3600)/60=2880;
    runLFR=LFR.tot_run;                          %2880
else                                             %For steadystate condition
    LFR.dt=3600*1;      
    LFR.tot_run=4;
end
Xaxis_water=[];
%% Initiale value for Dearator
Dear.mwin=2.0;                          %Mass flow rate of water entering SD        kg/s
Dear.Twin=HX.Twin;                      %Temp of water in to the SD                 30 0C
Dear.hwin=XSteam('h_pT',LFR.Press_in,Dear.Twin)*1000;   %Specific enthalpy of water flowing into SD      J/kg

Dear.mwin=0;                            %Recheck with orginal code
Dear.Twin=HX.Twin; 
Dear.hwin=XSteam('h_pT',LFR.Press_in,Dear.Twin)*1000;   %h_pT	Entalpy as a function of pressure and temperature.

mwin_dear_intial=0.8;                   %NOT USED HERE

%% Initial value for PTC SCF
Tintialpipe=29*ones(1,PTC_scf.grid);        %Initial Fluid temperature
Tabsor=Tintialpipe;                         %Initial absorber pipe temp same as fluid=29 0C
Tgla=PTC_scf.Tair*ones(1,PTC_scf.grid);     %Initial glass envelope temperature

PTC_SCF.Xintial=[Tintialpipe Tabsor Tgla]'; %All initial temperature vector

% It is used only in case of implicit Euler
SCF_TF_implic=PTC_SCF.Xintial(1:PTC_scf.grid);                              %Fluid temperture
SCF_TA_implic= PTC_SCF.Xintial(((PTC_scf.grid)+1):(2*PTC_scf.grid));        %Absorber pipe  temperture
SCF_TE_implic= PTC_SCF.Xintial(((2*PTC_scf.grid)+1):(PTC_scf.grid*3));      %Glass envelope temperature

%% Initial value for HT
%PTC_HT.Xintial=[HT.int_Mass  h_oil(HT.Tintial-1)]';     
PTC_HT.Xintial=[HT.int_Mass  h_oil(HT.Tintial)]';       %Initial mass accumulation in HT and Enthalpy of oil flowing out of HT
% It is used only in case of implicit Euler
HT_Mass_implic= PTC_HT.Xintial(1);          
HT_Entha_implic= PTC_HT.Xintial(2);

%% Initial value for SG

HX.SGintial=[HT.Tintial-1   SG.intial_Mw   SG.intial_Mw  SG.Msteam  SG.hwoutX  SG.press_int];
%Initially mass of water=mass of system (Subcooled), so 3rd variable is also taken as mass of water

%% Initial value for SH
HX.SHintial=[0 0];                                %For SH initially oil temp at outlet and steam outlet temp

%% Other parameters
single_scaling=1; 
two_scaling =1;

dt.scf=1;
timestart=0;
timstart=0; 
timend=timstart+dt.scf;
IP_mwin_flag=0;
Xaxis_water=[];
phase=0;
steam_phase=0;
sin_zero=0;
theta=0;
%% To save the output
OP.SCF=[];                      %To save the value of Solar collector field
OP.HT=[];                       %To save the value of High temp tank
OP.SH=[];                       %To save the value of Super heater
OP.SG=[];                       %To save the value of Steam generator
OP.PH=[];                       %To save the value of Preheater
OP.LT=[];                       %To save the value of Low temp tank
OP.scf_hp=[];

OP.HT_Temp=[];                  %To save the value of output temp of HT tank
OP.LT_Temp=[];                  %To save the value of output temp of LT tank

OP.SGU=[];                      %To save the value of U of SG(only HTC)
OP.SGF=[];                      %To save the value of correction factor(F) of SG
OP.SGhshell=[];                 %To save the value of HTC of shell side of SG
OP.SGhtube=[];                  %To save the value of HTC of tube side of SG
OP.SGuaf=[];                    %To save the value of SG UAF(Overall HTC)

OP.SHU=[];                      %To save the value of U of SH(only HTC)
OP.SHF=[];                      %To save the value of correction factor(F) of SH
OP.SHhshell=[];                 %To save the value of HTC of shell side of SH
OP.SHhtube=[];                  %To save the value of HTC of tube side of SH
OP.SHuaf=[];                    %To save the value of SH UAF(Overall HTC)

OP.PHU=[];                      %To save the value of U of PH(only HTC)
OP.PHF=[];                      %To save the value of correction factor(F) of PH
OP.PHhshell=[];                 %To save the value of HTC of shell side of PH
OP.PHhtube=[];                  %To save the value of HTC of tube side of PH
OP.PHuaf=[];                    %To save the value of PH UAF(Overall HTC)

OP.SGmsgen=[];                  %To save the value of mass of steam generation from SG            
OP.SGTw=[];                     %To save the value of Saturation Temp of water coming out from SG

OP.I_solar=[];                  %To save the solar radiation 
OP.Ambient_T=[];                %To save the ambient temp    
OP.SDr=[];

OP.SH_noZ=[];                                     %?
OP.PH_noZ=[];                                     %?
OP.Drum_Temp_wat=[];
OP.LFR_Temp=[];

OP.sh_tsout=[];                     %Null array to save the steam outlet temp from SH
OP.ph_twout=[];                     %Null array to save the water outlet temp from SH

OP.SG_pressure=[];
OP.SG_temp=[];
OP.SGTw=[];
OP.shut_oil_T_SH=[];
OP.shut_oil_T_PH=[];

SD_m_cond_arr=[];
SD_night_arr=[];
SD_MW=[];
SD_MS=[];
shut_SD=[];

HX.SG_night_press_arr=[];           %To store SG pressure
SG.m_cond_SG_arr=[];                          %SG.m_cond_SG:  Mass of water or Mass of steam based on sign (See HXSG_night1)
SG_MW=[];                                                      %SG mass of water
SG_MS=[];                                                   %SG mass of steam
shut_SG=[];

shut_PH=[];
shut_SH=[];
shut_HT=[];
shut_LT=[];
simulation_complete=0;

SD_night=[];
SG_night=[];

Before_Night_time_SG=[];
Before_Night_time_SD=[];
Before_Night_time_Tank=[];
Before_Night_time_HX=[];

After_Night_time_SG=[];
After_Night_time_SD=[];
After_Night_time_Tank=[];
After_Night_time_HX=[];
% simu_time_end=48*3600;
%% To save the time/iter no wrt X-axis
Xax.PTC=[];                     %TO save time time axis for PTC
Xax.HT=[];                      %TO save time time axis for HT
Xax.LT=[];                      %TO save time time axis for LT
Xax.LFR=[];                     %TO save time time axis for LFR
Xax.SD=[];                      %TO save time time axis for SD
Xax.PH=[];                      %TO save time time axis for PH
Xax.SG=[];                      %TO save time time axis for SG
Xax.SH=[];                      %TO save time time axis for SH
Xax.POW=[];                     %TO save time time axis for Power
Tur.msin=[0];                   %? check        

Xaxis=[];
xx=1;
XA.X_SG=[];
Xa.X_SH=[];
Xa.X_PH=[];
%% To save the variable values wrt Y-Axis

Yax.press_SD=[];                %To save the SD pressure wrt Y axis
note_time_next_start=[0];
%% To save the variables
LFR.IP_mwin=[];
SD.IP_mwin=[];
%% For loop for initialisation for LFR variables
for n=1:1:LFR.tot_run                           %Total run is 2880 for 2 days
    for poi=1:1:LFR.points                      %LFR points 4880 for 10 no of grid points (480*10)
        LFRsim.rho(n,poi)= LFRsim.rho(1,1);     %Density of fluid           kg/m^3
        LFRsim.P(n,poi) = LFRsim.P(1,1);        %Pressure                   bar
        %LFRsim.P(n,poi) = Drum.press;        %Pressure                   bar
        LFRsim.h(n,poi)=LFRsim.h(1,1);          %Enthalpy                   J/kg
        LFRsim.u(n,poi)=LFRsim.u(1,1);          %Velocity                   m/s
        LFRsim.T(n,poi)= LFRsim.T(1,1);         %Temperature of water       0C    
        LFRsim.x(n,poi)=0;
        LFRsim.Ck(n,poi)=LFRsim.Ck(1,1);        %Friction facotor     
        LFRsim.Tabo(n,poi)=LFR.Twin;            %Temp of absorber pipe      0C
        LFRsim.Tgla(n,poi)=LFR.Tsky;            %Temp of glass envelope     0C
    end
end

%% Check
Drum.msout(1)=0;
waterin_drum(1)=0;
Drum.mwin_n(1)=0;
Drum.msout_dear(1)=0;                
LFR_n=0;
count1=1;
%%
if ( HT.Tintial<= PTC_SCF.Xintial(PTC_scf.grid))  %if 40 oC (HT initial temp) <= Oil output temp of PTC 
    PTC_HT_OD=1;                                  %Then connect HT with PTC together
    SG.moil=HT.moilout;                           %Mass of oil to SG=HT mass of oil out
    SG.Toilin=HT.Toout;                           %Temp of oil to SG=HT temp of oil out
else
    SG.moil=PTC_scf.moil*3;                       %Mass of oil to SG=PTC mass of oil out
    SG.Toilin=PTC_SCF.Xintial(PTC_scf.grid);      %Temp of oil to SG=PTC temp of oil out
end

msgen_drum=0;                                     %No mass of steam generation from Drum now
Drum.msout=0;                                     %No mass of steam out from Drum
drum_Mass(1)=Drum.Mass;                           % 4000 kg
drum_Mass_wat(1)=Drum.Mass_wat;                   % 4000 kg same as Drum.Mass
drum_Mass_steam(1)=Drum.Mass_steam;               %2.2385 kg steam in the Drum ??
drum_pressure(1)=Drum.press;                      %2 bar drum pressure
drum_hwat(1)=Drum.hwat;                           %Enthalpy of water
drum_Twat(1)=Drum.Temp_wat;                       %same as HX.Twin
drum_msgen(1)=msgen_drum;                         %Initially mass of steam generation is zero
drum_ms_out40(1)=Drum.msout;                      %Initially No mass of steam out from Drum               

steamgen_LFR_bef_PTC=0;
steamgen_LFR_bef_PTC1=1;                          %NOT USED HERE

OP_TTsteam=XSteam('Tsat_p',SG.press_int);         %Saturation temperature           0C
OP.Tsteam=[ OP_TTsteam ];                         %To store output temp of steam from SG

PH.sav_mwin(1)=HX.mwin;                           %Mass flow of water in=0.5 kg/s to PH 
SG.sav_mwin(1)=HX.mwin;                           %Mass flow of water in=0.5 kg/s to SG
HX.sav_mwin(1)=HX.mwin;                           %Mass flow of water in=0.5 kg/s to Heat exchanger, why HX??
                                  
%% Initialisation for Steam DRUM 
SD_intial=[Drum.Mass  Drum.Mass_wat  Drum.Mass_steam  Drum.hwat  Drum.hst];

Drum.Mass=SD_intial(1);                           %Toal mass in Drum
Drum.Mass_wat=SD_intial(2);                       %Mass of water
Drum.Mass_steam=SD_intial(3);                     %Mass balance of steam
Drum.hwat=SD_intial(4);                           %Enthalpy of water
Drum.hst=SD_intial(5);                            %Enthalpy of steam

T_SPAN_SD=[0 LFR.dt];                             %Interval of integration for SD
%% For Energy computation
En_gain_PTC=0;
Eng_gain_arr_PTC(1)=En_gain_PTC;                  %For energy computation for SCF
En_gain_LFR=0;
Eng_gain_arr_LFR(1)=En_gain_LFR;                  %For energy computation for LFR

pow_LFR=0;                          %Initialization for LFR power
pow_LFR_arr=[];                     %Null array to save the power generated from LFR
pow_PTC= 0;                         %Initialization for LFR power
pow_PTC_arr=[];                     %Null array to save the power generated from PTC

simulation_night=0;                 %For nighttime silulation purpose
w_iter_scf=0;


SP_HT_LT_SH=1;
Temp_set_HT_SH=301;
HT_mass_HTSH=3000; 
LT_mass_HTSH_MAX=1440*pi*2;
%Save all the data in a matrix till here
%% To extract the solar radiation and ambient temp

aa=2;                             %To extract the data from DATALFR 2nd row           
%bb=1442;                          %To extract the data from DATALFR upto 1442 row  
bb=1886;
[DATALFR txt]=xlsread('maymonth.xlsx');           %To seperate data from the excel sheet
Solar_I=(DATALFR(aa:bb,7)-DATALFR(aa,7));      %Solar radiation
%solar_I_clean=Solar_I(425:end);                   %Solar radiation with better dataset
solar_I_clean=Solar_I(445:1884);                   %For 1 day simulation 9 hrs solar radiation , datas are in minutes
Ambient_T1=(DATALFR(aa:bb,5));                    %Ambient Temp 
Ambient_T2=Ambient_T1(425:end);

%% No use
%Solar_I_real= solar_I_clean';

% Solar_I_real=400;
% for% iw=1:1:dayss-1                         %May be for generalized code structure
%     Solar_I_real=[Solar_I_real Solar_I'];
% end
% lfr_I_sec=[Solar_I_real  0*ones(1,0.15*3600)];



if Type==0
    %% For constant
    %lfr_I_sec1=700*ones(1,(time_hour-1)*60);        % use this for constant Solar radiation

    lfr_I_sec1=700*ones(1,9.1*60);          % 700 Constant solar dadiation from 8 AM to 5.06 PM
    lfr_I_sec2=0*ones(1,14.9*60);           % 5.06 Pm to next day 8AM Night time cooling
    lfr_I_sec=[lfr_I_sec1 lfr_I_sec2];      % Complete 1 day solar radiation 8AM to 8AM

    lfr_I_sec=repmat(lfr_I_sec,1,Days);     % Reapeat the 1 day simulation as per Days requirement

elseif Type==1
    %% Step type solar radiation

    % lfr_I_sec2=400*ones(1,1*60);
    % lfr_I_sec=[lfr_I_sec1 lfr_I_sec2];
    %new  from here
    lfr_I_sec1=700*ones(1,6*60);            % 700 Constant solar dadiation from 8 AM to 2 PM
    lfr_I_sec2=400*ones(1,3.1*60);          % 400 Constant solar dadiation from 2 PM to 5.06 PM
    lfr_I_sec3=0*ones(1,14.9*60);           % 5.06 Pm to next day 8AM Night time cooling
    lfr_I_sec=[lfr_I_sec1 lfr_I_sec2 lfr_I_sec3];      % Complete 1 day solar radiation 8AM to 8AM

    lfr_I_sec=repmat(lfr_I_sec,1,Days);     % Reapeat the 1 day simulation as per Days requirement

elseif Type==2
    %% For real time solar radiation
    lfr_I_sec=solar_I_clean';                     % use this for real time

    lfr_I_sec=repmat(lfr_I_sec,1,Days);     % Reapeat the 1 day simulation as per Days requirement


elseif Type==3
    %% For Quadratic solar radiation
    Solar_I_quad=[];
    lfr_I_sec1=[];
    %lfr_I_sec2=[];
    y=60;

    for t=0:1:32400

        I=(-5.5962e-006*t^2) +( 0.1108*t )+ 56.5133+290;

        if  t >(4*3600) && t< (4*3800)
            I=300;
        else
            I=I-100;
        end

        if  I < 0.5
            I=0;
        end

        Solar_I_quad=[Solar_I_quad I];
        if t>50
            if mod(t,60)==0
                lfr_I_sec1=[lfr_I_sec1 Solar_I_quad(y)];
                y=y+60;
            end
        end
    end
    lfr_I_sec2=0*ones(1,15*60);
    lfr_I_sec=[lfr_I_sec1 lfr_I_sec2] ;      % Complete 1 day solar radiation 8AM to 8AM

    lfr_I_sec=repmat(lfr_I_sec,1,Days);     % Reapeat the 1 day simulation as per Days requirement
end
    %plot(lfr_I_sec)
%%
Ambient_Temp_V= Ambient_T2';
%for iw=1:1:dayss-1                         %May be for generalized code structure
    Amb_Temp=[Ambient_Temp_V  Ambient_T1'];
%end
Ambient_Temp_ind=[Amb_Temp  0*ones(1,0.15*3600)];

%%
leng_I=length(lfr_I_sec);           %2880, length of lfr_I_sec vector
leng_I=leng_I*60;                   %179880
ip1=1;                              %Dummy variable
day_count=1;                        %Dummy variable for day count
break_time_stop=0;
note_time_day_end=0;                
note_time_next_start=0;


%% To save workspace in mat file
if Type==0
    save('lfr_I_sec_700_all_Lgp')   %Constant with solar radiation 700 W/m^2
elseif Type==1
    save('lfr_I_sec_step_Lgp')
elseif Type==2
    save('lfr_I_sec_real_Lgp')
elseif Type==3
    save('lfr_I_sec_quad_Lgp')
end

disp('Parameter value has been updated')


