%% Preheater HTC
%For calculation of U we need two HTC,one is shell side another is tube side.
%_she=Shell side
%_t= tuibe side

function [UAF,hi_t_turb, ho_she,F,U]=UAF_PH_mw0(mo,Toi,Too,mw,Twi,Two,Pres)

global PH

Tw_av=(Twi+Two)/2;          %Avg water temperature=(Temp of fresh water (30 oC)+Temp of water coming out from PH)/2
Toil_av=(Toi+Too)/2;        %Avg oil temperature=(Temp of Oil coming out from SG+Temp of Oil from coming out from PH)/2

%All units in meters
tube_ID=PH.tube_ID;             %Tube input diameter
ri_t=tube_ID/2;                 %Inner radius of tube side
tube_OD= PH.tube_OD;            %Tube output diameter
ro_t=tube_OD/2;                 %Outer radius of tube side
L_t=PH.tube_length;             %Tube length
No_tub= PH.No_tubes;            %Total no of tubes
PH.nopass_t=2;                  %Number of passes?
Area=pi*tube_OD*L_t*(No_tub*2); %Area of heat transfer    m^2
Therma=49;                      %Thermal conductivity of tube wall

%% Tube side HTC calculation
%
den_t=XSteam('rho_pT',Pres,Tw_av);      %Density of oil, Here pres=? bar
cpW_t=(XSteam('Cp_pT',Pres,Tw_av));
cp_t=cpW_t*1000;                        %Sp. Heat capacity
dyn_vis_t=XSteam('my_pT',Pres,Tw_av);   %Dynamic viscosity
Th_t=XSteam('tc_pT',Pres,Tw_av);        %Thermal conductivity
den_t_av=XSteam('rho_pT',Pres,Tw_av);   %avg t
kvis_t=dyn_vis_t/den_t;                 %Kinematic viscocity
%when water not flowing through tube, no flow
g=9.8;                                  %Gravity
B=227.6*10^-6;
Ts=Toi;
Tinf=Two-0.5;
D=PH.tube_OD;
kvis=dyn_vis_t/den_t_av;                %Kinematic viscocity
alp=Th_t/(cp_t*den_t);
Ral=(g*B*(Ts-Tinf)*D^3)/(kvis_t*alp);
Pr=(cp_t*dyn_vis_t)/Th_t;               %Prandtl number=(Sp. Heat capacity*Dynamic viscosity)/Thermal conductivity
numer_ch1=0.387*(Ral^(1/6));
%numer_ch=0.67*(Ral^(1/6)) ;
deno_ch1=(1+(0.492/Pr)^(9/16))^(8/27);
%deno_ch2=(1+(0.492/Pr)^(9/16))^(4/9) ;
NU_1=(0.6+(numer_ch1/deno_ch1))^2 ;     %Nusselt number
hb_sg=(NU_1*Th_t)/D;                    %Tube side HTC
hi_t_turb=hb_sg;                        %Tube side HTC..Value**it may be smaller

%% Shell side HTC calculation
Di_s= PH.shell_ID;      %Shell side inner diameter
ls=(Di_s/5);            %Baffle spacing: Minimum baffle spacing should be one fifth of the Shell Internal Diameter (ID) OR 2 inch, whichever is greater
Dotl=0.25;              %ds-Bundle clearence
Pn=0.0238;
Pt=Pn;                  %Pitch/square

% den_she=density_oil(Toil_av);
% cp_she=Cp_sf(Too);
% Kvis_she=Kin_vis(Too);
% Th_she=Ther_con(Too);

den_she=density_oil(Toil_av);
cp_she=Cp_sf(Toil_av);
Kvis_she=Kin_vis(Toil_av);              %Kinematic viscosity
Th_she=Ther_con(Toil_av);
dyn_vis_she= (Kvis_she *den_she);       %Dynamic viscosity

%% Calculation of HTC on shell side by 2 method

%1. Kern method
Cl=Pn-(2*(tube_OD/2));
A_she=(Di_s*Cl*ls)/Pt;
Gs_she=mo/A_she;
De_she=(4*((Pt^2)-((pi*tube_OD^2)/4)))/(pi*tube_OD);
Re_she=(De_she*Gs_she)/dyn_vis_she;                                                 %Reynold no
Nu_she=0.36*(Re_she^0.55)*(((cp_she*dyn_vis_she)/Th_she)^0.33);%*((ub/uw)^0.14);    %Nussult no shell side
ho_she1=(Nu_she*Th_she)/De_she;                                                     %Shell side HTC

%Overall HTC calculation by Kern method
U1=(1/ ho_she1)+((1/hi_t_turb)* (tube_OD/tube_ID) )+((ro_t*log(ro_t/ri_t))/(Therma));
U1=1/U1;

%2. Bell-Delaware method
sm=ls*(Di_s-Dotl+(((Dotl-tube_OD)/Pn)*(Pt-tube_OD)));
Re_s=(tube_OD*mo)/(dyn_vis_she*sm);                     %Reynolds number=(tube outer diameter*Mass flow rate of fluid on shell side)/(Dyn viscocity*Sm)
j1= 0.185*(Re_s^-0.324);                                %Colburn j-factor
Cs=cp_she  ;                                            %Specific heat capacity of fluid shell side

ho_she=j1*Cs*(mo/sm)*(Th_she/(Cs*dyn_vis_she));         %Shell side HTC** wall temp not modeled,value tell

%Overall HTC calculation by Delaware method
U=(1/ ho_she)+((1/hi_t_turb)* (tube_OD/tube_ID) )+((ro_t*log(ro_t/ri_t))/(Therma));
U=1/U;



%% Correction factor of PH
Rr=(Toi-Too)/(Two-Twi);                                     %Range on shell side temperature/Range on tube side temperature
Ss=(Two-Twi)/(Toi-Twi);                                     %Range on tube side temerature/Maximum temperature diff on HX
%Here Rr should not be 1, otherwise Deno_F will be 0 and hence F will be NAN.
if Rr==0
    disp('Rr value should not be zero, kindly check in the code mw0')
    pause
end

diff_oil=Toi-Too;
diff_wat=Two-Twi;

if  diff_oil ==diff_wat
    disp('Difference Oil side same as Water side mw0');
    F=0.7974;                                               %Correction factor when diff_oil ==diff_wat
    pause
else
    num_F=(sqrt( (Rr^2)+1))*log ((1-Ss)/(1-(Rr*Ss))) ;      %Numerator of correction factor
    F_d1= 2- (Ss*(Rr+1- (sqrt(Rr^2+1))) );
    F_d2= 2- (Ss*(Rr+1+ (sqrt(Rr^2+1))) );
    Deno_F=(Rr-1) *log(F_d1/F_d2);                          %Denominator of correction factor
    F=num_F/Deno_F;                                         %Correction factor
end

if isreal(F)==0
    disp('F_PH not a real number')
end



%% no dyn,only for ss, varify 
if  F>1
    F=0.8;
elseif isreal(F)==0     
    F=0.7;
% elseif  F<0.8    *Never use
    %disp(**)
% else
end
%*include -ve part also

%% To Find UAF
UAF=U1*Area*F;      %By kern paper method
%UAF=U*Area*F;      %By delawara method
UAF=UAF*10^-3;

PH.UAF=UAF;
PH.U=U1;
PH.hi=hi_t_turb;    %Tube side HTC-SH-PH
PH.ht= ho_she;      %shell side HTC-SH-PH
PH.F=F;

end
