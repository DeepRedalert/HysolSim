%%Pre heater function file

function [dHX_PH] =HXPH(t,T)

global PH
global SG
global HX
%global iter_scf w_iter_scf

if isnan(T)==1              %Element of T is empty or not
    T
    PH
    pause
end

PH.Twout=T(1);              %Temp of water coming out from PH
PH.Toout=T(2);              %Temp of Oil from coming out from PH

if PH.Twout>250
    disp('PH water outlet temp should less than 250, otherwise steam will produce in PH itself')
    disp('Kindly increase the mass flow rate of water/Oil to PH as per your convinience')
    disp('Please Terminate the simulation')
    pause
end


%ph_tsout=[ph_tsout PH.Toout];

if isreal(PH.Twout)==0
    disp('Twout contain imaginary number, Kindly check the input for')
    pause
end
if isreal(PH.Toout)==0
    disp('Toout contain imaginary number, Kindly check the input for')
    pause
end
PH.mwin=(SG.mwin);          %Mass flow rate of water in to PH

%% Function calling for calculating UAF

%Function return [UAF, tube side HTC, Shell sideHTC,Correctionfactor,Overall HTC]=[Mass flowrate of fluid on shell side,Temp of Oil coming out from SG,Temp of Oil from coming out from PH,Mass flow rate of water in,Temp of fresh water (30 oC),Temp of water coming out from PH, pressure of water from SG]
if  PH.mwin < 0.01   %Mass flow rate of water in  to PH
    [PH.UAF,PH.htctube,PH.htcshell, PH.htcF,PH.htcU] =UAF_PH_mw0(PH.moil,SG.Toout,PH.Toout,PH.mwin,HX.Twin ,PH.Twout,SG.press);
else
    [PH.UAF,PH.htctube,PH.htcshell, PH.htcF,PH.htcU] =UAF_PH_fun(PH.moil,SG.Toout,PH.Toout,PH.mwin,HX.Twin ,PH.Twout,SG.press);
end

%% Scaling down UAF
PH.UAF=0.6*PH.UAF;  %Validation see

% if  (SG.Toout-PH.Twout) <10
%      PH.count=PH.count+1; PH.cc=[PH.cc iter_scf w_iter_scf];
%     PH.ODE=0;
% end

%%
%_________________________Differential equation for finding out two unknowntemperature___________________________________
if (PH.ODE==0)
    dTdt4=0;
    dTdt5=0;
else

    Pres_PH=SG.press;                                   %Water pressure out from PH*

    rho_stemp4=XSteam('rho_pT',Pres_PH,PH.Twout);       %Density of water based on avg temp of water in & out of PH
    Cpwatertemp4=XSteam('Cp_pT',Pres_PH,PH.Twout);      %SP heat capacity based on avg temp of water in and out of PH

%% Calculation of LMTD
    hot_ph=SG.Toout - PH.Twout;         %Hot side temp diff
    cold_ph=PH.Toout - HX.Twin;         %Cold side temp diff
    oilside=(SG.Toout+PH.Toout )/2;     %Avg oil temp for PH in and out
    waterside=(HX.Twin+PH.Twout)/2;     %Avg water temp for PH in and out
    %lm_ph=PH.Toout-PH.Twout;

    if (hot_ph/cold_ph)==1  || ( HX.Twin > PH.Toout )||  ( PH.Twout > SG.Toout )
        PH.lmtd=oilside-waterside;
        disp('Avg temp diff');                                             
    else
        PH.lmtd=(hot_ph-cold_ph)/(log(hot_ph/cold_ph));             %LMTD
    end

%% Some parameter calculation

    oil_diff_ph=SG.Toout - PH.Toout;            %Temp diff of oil of outlet of SG to PH
    oil_avg_ph=(SG.Toout + PH.Toout)/2;         %Avg Temp of oil of outlet of SG to PH
    dt4chg=XSteam('h_pT',Pres_PH,HX.Twin)-XSteam('h_pT',Pres_PH,PH.Twout);          %Specific enthalpy diff of PH  kJ/kg

%% For outlet water temperature of PH, equation 19 in the IECER paper
    dTdt4 = (((PH.mwin * dt4chg) +  (PH.UAF *PH.lmtd))/(rho_stemp4 * PH.tube_side_volume * Cpwatertemp4));

    deno_HX_5=(PH.shell_side_volume*PH.Toout*density_oil(PH.Toout)*(dbyCp_sf (PH.Toout)*10^(-3)))+...           %Den of dTdt5
        (PH.shell_side_volume*PH.Toout*dbyden_sf(PH.Toout)*(Cp_oil(PH.Toout) * 10^(-3)))+...
        (PH.shell_side_volume*density_oil(PH.Toout)*(Cp_oil(PH.Toout) * 10^(-3)));

%% For outlet oil temperature of PH, equation 18 in the IECER paper
    dTdt5 = ((PH.moil *(Cp_oil(oil_avg_ph) * 10^(-3))* (oil_diff_ph)) ...
        - (PH.UAF*PH.lmtd)-(PH.Uloss*PH.loss_A*(PH.Toout- HX.Ambient_Tempr)) )/(deno_HX_5);
end

dHX_PH=[dTdt4  dTdt5]';     %Returning both unknown temperature

end

% UAF_PH(7.2,260,230,1.12,105,230,40)




