% Drum.msout: Output from Steam Drum = Mass of steam out from stead Drum to Mixer
% SG.msgen_SH:SG mass of steam generation  

function [dhdtt] =mixer_SH(t,T)

global  SG LFR Drum SD Mode

hs_SG=(XSteam('hV_T',(SG.Twater)));      %hV_T	Saturated vapour enthalpy w.r.t. Saturation temp of water

if Mode~=1
    if Drum.press > SD.press_st             %If Drum pressure>41 bar, LFR output added to mixer
        LFR.hh_out_lfr=Drum.hst*10^-3;      %Enthalpy of steam in SD
        LFR.drum_msout=LFR.msteam_pipeout8; %Mass of steam out from LFR last pipe

        if SG.press > SG.press_st-0.2       %IF SG pressure>39.8 bar
            SG.msgen_SH=SG.msgen;           %SG mass of steam generation
        else
            SG.msgen_SH=0;                  %If cond not met mass of steam gen = 0
        end
    else                                    %If Drum pressure<41 bar
        LFR.hh_out_lfr=0;
        LFR.drum_msout=0;

        if SG.press > SG.press_st-0.2       %IF SG pressure>39.8 bar
            SG.msgen_SH=SG.msgen;           %SG mass of steam generation
        else
            SG.msgen_SH=0;                  %If cond not met mass of steam gen = 0
        end
    end
else
    if SG.press > SG.press_st-0.2       %IF SG pressure>39.8 bar
        SG.msgen_SH=SG.msgen;           %SG mass of steam generation
    else
        SG.msgen_SH=0;                  %If cond not met mass of steam gen = 0
    end
end
% Mass of steam generation
if Mode==1      %For PTC loop only that is steam wiil generate only from SG
    dmdt1= SG.msgen_SH;                     %Mass of steam generated from SG only
else
    dmdt1= SG.msgen_SH+Drum.msout;          %Mass of steam generated from SG+Mass of steam out from SD
end

%For Mode =1, if SG.msgen 0 then it will give NAN so carefull.
% Enthalpy
if Mode==1      %For PTC loop only that is steam wiil generate only from SG
    if SG.msgen_SH==0
        dhdt1=0;
    else
        dhdt1= (SG.msgen_SH*hs_SG) / (SG.msgen_SH) ;
    end
else            %For full plant that is steam will generate from SG+SD
    dhdt1= ((SG.msgen_SH*hs_SG) + (Drum.msout*(LFR.hh_out_lfr*1 ))) / (SG.msgen_SH+Drum.msout) ;
end

% Returning both States
dhdtt=[dmdt1 dhdt1]';

end