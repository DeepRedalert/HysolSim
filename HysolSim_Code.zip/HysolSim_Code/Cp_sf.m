%Function file for Specific heat capacity(Cp) of oil
%Density and CP vary with temperature

function [Cp]=Cp_sf(T)

Cp=(0.002414*T)+(5.9591*10^-6*(T^2))+(-2.9879*10^-8*T^3)+(4.4172*10^-11*T^4)+1.498;       %KJ/Kg.K
Cp=Cp*1000;
end



