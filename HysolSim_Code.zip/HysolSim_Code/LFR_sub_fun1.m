%Function file LFR initialization for water loop
function [time_run]=LFR_sub_fun1(LFR_n)

global LFR PTC_scf Drum LFRsim HX tim_iter phase_enth first_LFR_IC LFR_n

LFR_n=LFR_n+1;
time_run=LFR_n;
LFR.I=PTC_scf.I;                                            %Solar radiation same as LFR also
P3_in=LFR.Press_in;                                         %45 bar water pressure in to LFR
% P3_in=Drum.press;
enthalpy_in=XSteam('h_pT',P3_in,Drum.Temp_wat);             %Enthalpy of water in to LFR
h1_in=enthalpy_in*1000;
rho1_in=XSteam('rho_ph',P3_in,enthalpy_in);                 %Density of water in to LFR
vis_L1_in=XSteam('my_ph',P3_in,h1_in*10^-3);                %Viscosity of water in to LFR
volumetric=LFR.mw_indi/rho1_in;                             %Volumetrix flow  of water in to LFR
velocity=(1.2734*volumetric)/(LFR.dia_ab^2);                %Velocity of of water in to LFR
u1_in=velocity;                                             %Velocity of of water in to LFR
%x1_in=rho1_in;
LFR.Tfluid=Drum.Temp_wat;                                   %Initial water temp water in to LFR
%TAbo1_in=Drum.Temp_wat;
REY=(rho1_in*u1_in*LFR.dia_ab)/vis_L1_in ;                  %Reynolds Number
phase=0;                                                    %For horizontal phase =0
f=ffrough(REY, LFR.dia_ab, 0);
Ck1_in=f/(2*LFR.dia_ab);                                    %Friction factor

for time_runs=time_run+1:1:time_run+1
    for grid_poi=1:1:LFR.points                             %Grid points=4800
        %Initialization for first instant
        LFRsim.rho(time_runs,grid_poi)= rho1_in;            %Water Density
        LFRsim.P(time_runs,grid_poi) = P3_in;               %Water Pressure
        LFRsim.h(time_runs,grid_poi)=h1_in;                 %Enthalpy of water
        LFRsim.u(time_runs,grid_poi)=u1_in;                 %Velocity of water
        LFRsim.x(time_runs,grid_poi)=0;                     %Density of water ??
        LFRsim.Ck(time_runs,grid_poi)=Ck1_in;               %Friction factor
        if grid_poi==1                                              %For 1st grid point
            if  first_LFR_IC==1                                     %For Initial condition
                LFRsim.Tabo(time_runs,grid_poi)=HX.Ambient_Tempr;   %Temp of absorber pipe; HX.Ambient_Tempr=Ambient temp for first case
                LFRsim.T(time_runs,grid_poi)=HX.Ambient_Tempr;      %Temp of water;         HX.Ambient_Tempr=Ambient temp for first case
            else
                LFRsim.Tabo(time_runs,grid_poi)=Drum.Temp_wat;      %Temp of absorber pipe from Drum temp water 30 oC
                LFRsim.T(time_runs,grid_poi)=Drum.Temp_wat;         %Temp of water in to LFR from Drum temp water 30 oC
            end
        else                                                        %For gridpoint 2nd onwards
            LFRsim.Tabo(time_runs,grid_poi)=LFRsim.Tabo(time_runs-1,grid_poi);  %time_runs-1=We need previous time value for current instant
            LFRsim.T(time_runs,grid_poi)=LFRsim.T(time_runs-1,grid_poi);
        end

        LFRsim.Tgla(time_runs,grid_poi)=LFR.Tsky;           %LFR glass pipe temp
        %Pasc(time_runs,grid_poi)= P3_in*10^5;
        tim_iter(time_runs,grid_poi)=1;                     %?
        phase_enth(time_runs,grid_poi)=0;                   %?
    end
end
end