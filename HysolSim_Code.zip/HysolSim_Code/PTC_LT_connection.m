%Function file for Connect LT with PTC
function [LT_out_temp]=PTC_LT_connection(Tspan)

global PTC_SCF PTC_scf LT PTC_LT

LT.moilin=PTC_scf.moil*3;
LT.moilout=LT.moilin;
LT.hin=h_oil(PTC_SCF.Xintial(PTC_scf.grid));

options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
[Ts,Y_LT]=ode15s(@LTtank,Tspan,PTC_LT.Xintial,options);
PTC_LT.Xintial=(Y_LT(length(Ts),:)');

LT.hout=PTC_LT.Xintial(2);
%opts = optimset('TolFun',1e-12,'Display','off') ;
%LT.Toout=fsolve('enthal_Temp_LT',LT.Toout,opts);

%Enthalpy polynomial fit equation:
%Enthalpy=(0.0014*T^2)+(1.49681*T)-18.17454; (TAken from thermino VP1 pdf file)
%Concidering only +ve part
LT.Toout=(-1.49681+sqrt(1.49681^2-4*0.0014*(-18.17454-LT.hout)))/(2*0.0014);
LT_out_temp=LT.Toout;
%LT again connected to PTC
PTC_SCF.Xintial(1)=LT.Toout;
% PTC_scf.moil=LT.moilout;

end