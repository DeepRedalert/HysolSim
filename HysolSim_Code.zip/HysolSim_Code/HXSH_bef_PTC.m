% Function file for Super heater (Connection from LFR side)

function [dHX_SH] =HXSH_bef_PTC(t,Tmp)

global SH Drum SG LFR 
global steamgen_LFR_bef_PTC HT LFRsim 
% global PTC_scf  PTC_SCF  PTC_HT_OD 

SH.Toout=Tmp(1)                     %Temp of oil out from SH
SH.Tsout=Tmp(2)                     %Temp of steam out from SH
disp('HXSH Bef PTC')

%sh_tsout=[sh_tsout SH.Tsout];       %To store the steam outlet temp of SH

if isnan(Tmp)==1                    %Element of Tmp is empty or not
    Tmp
    SH
    SG
    %pause
end

%SH is connected before SG produce 40 bar pressure

if steamgen_LFR_bef_PTC == 1

    SH.msin=LFR.msteam_pipeout8;
    SH.mixh=(XSteam('hV_T',LFR.Tfluid));           %Saturated vapour enthalpy, will go to global

    %Mass flow rate of oil to SH, SG, PH is same i.e. Mass flow rate of oil out from HT
    SH.moil=HT.moilout;
end

if  Drum.press>41                                   %If drum pressure > Set point pressure (bar)                          
    LFR.Tfluid_phase=LFR.Tfluid;                    %LFR output temp ?steam or water or 2phase
    SG.LFR_Tsout=LFR.Tfluid_phase;                  %Temp of steam out ? Why SG
end

%Some time hot SH and cold SH becomes equal, then NAN will come.

hot_sh= SH.Toilin - SH.Tsout;                       %Temp diff of hot side
cold_sh=SH.Toout - SG.LFR_Tsout;                    %Temp diff of cold side ... it should SD_Tsout


if  hot_sh < 5 ||  cold_sh < 5                      %Need to understand
    SH.ODE_bef_PTC=0;
%     hot_sh
%     cold_sh
    disp('At here that why temperature is constant');%Need to understand
    %pause(0.05)

    if  SH.Toilin >260
        disp('HT oil output temp greater than 260');
        %pause(0.05)
    end

end

%%
if (SH.ODE_bef_PTC==0)
    dTdt1=0;
    dTdt2=0;
else
%% Function calling for calculating UAF
    SH.msin=Drum.msout;         %Mass of steam out from SD goes to SH
    
    %Function return [UAF, tube side HTC, Shell sideHTC,Correctionfactor,Overall HTC]=[Mass flowrate of fluid on shell side,Temp of Oil coming out from HT,Temp of Oil from coming out from SH,Mass flow rate of steam in,Temp of steam coming in to SH,Temp of steam coming out from SH, pressure of steam from SG]
    [SH.UAF,SH.htctube,SH.htcshell,SH.htcF,SH.htcU] =UAF_SH_fun(SH.moil, SH.Toilin,SH.Toout,SH.msin,SG.LFR_Tsout,SH.Tsout,SG.press);

%% Scaling down UAF
    SH.UAF=1*SH.UAF;

%% Calculation of LMTD
    hot_sh= SH.Toilin - SH.Tsout;
    cold_sh=SH.Toout - SG.LFR_Tsout;
    %lm_sh= SH.Toout-SH.Tsout;
    oilside=(SH.Toilin+ SH.Toout)/2;
    waterside= (SH.Tsout);          %Why not SD steam concidered for averaging like HXSH   

    if  hot_sh < 10 ||  cold_sh < 10
        % SH.UAF=0.8*SH.UAF;
        SH.check1=SH.check1+1;
    end

    if (hot_sh/cold_sh)==1 || (SG.LFR_Tsout > SH.Toout)
        SH.lmtd=oilside- waterside;                                 %LMTD
        disp('AR SH');
    else
        SH.lmtd=(hot_sh-cold_sh)/( log(hot_sh/cold_sh) );           %LMTD
    end
%% Some parameter calculation

    oil_diff_sh= SH.Toilin - SH.Toout;
    oil_avg_sh=( SH.Toilin +SH.Toout)/2;
    
%% Equation no 20 in IECER paper: Oil temp at outlet of SH
    deno_HX_1=(SH.shell_side_volume*SH.Toout*density_oil(SH.Toout)*(dbyCp_sf (SH.Toout)*10^(-3)))+...
        (SH.shell_side_volume*SH.Toout*dbyden_sf(SH.Toout)*(Cp_oil(SH.Toout) * 10^(-3)))+...
        (SH.shell_side_volume*density_oil(SH.Toout)*(Cp_oil(SH.Toout) * 10^(-3)));

    dTdt1 = ( (SH.moil *(oil_diff_sh) * (Cp_oil(oil_avg_sh) * 10^(-3) ))... 
        - (SH.UAF *SH.lmtd) )/deno_HX_1;   %Why not same as normal HXSH

%% Equation no 21 in IECER paper: Steam temp at outlet of SH
    
    %Specific isobaric heat capacity as a function of pressure and temperature.
    CP_S_SH=( XSteam('Cp_pT',SG.press,SH.Tsout) );
    %Density as a function of pressure and temperature.
    row_S_SH=XSteam('rho_pT',SG.press,SH.Tsout) ;
    %Saturated vapour heat capacity: Central diff method by purturbation
    dCp=((XSteam('CpV_p',(SG.press+0.1)))-(XSteam('CpV_p',(SG.press-0.1))))/(2*0.1);
    %Saturated vapour density: Central diff method by purturbation
    drow_s_T=((XSteam('rhoV_T',(SH.Tsout+0.1)))-(XSteam('rhoV_T',(SH.Tsout-0.1))))/(2*0.1);
    %Saturated vapour heat capacity: Central diff method by purturbation
    dCps_T=((XSteam('CpV_T',(SH.Tsout+0.1)))-(XSteam('CpV_T',(SH.Tsout-0.1))))/(2*0.1);

    %Appendix A29 equation number. Page no 161 from Surrender thesis.
    SH_deno1=((drow_s_T)*SH.Tsout*SH.tube_side_volume*CP_S_SH);
    SH_deno2=((dCps_T)*SH.Tsout*SH.tube_side_volume*row_S_SH);
    SH_deno3=CP_S_SH*SH.tube_side_volume*row_S_SH;

    deno_SH=SH_deno1+SH_deno2+SH_deno3;

    %h_pt=Entalpy as a function of pressure and temperature.
    dt2cha=(SH.mixh)-(XSteam('h_pT',round(LFRsim.Pendpipe,3),round(SH.Tsout,3))); %? Here pressure is concidered from LFR, in normal SG
    
    if isnan(dt2cha)==1
        disp('Tsi contain NAN in fun UAF_SH_fun')
        %pause
    end

    if SH.UAF==0.1
        dTdt2 = ( ((SH.msin) * dt2cha)+ (SH.UAF*SH.lmtd) );
    else
        dTdt2 = ( ((SH.msin) * dt2cha)+ (SH.UAF*SH.lmtd) )/deno_SH ;
    end

end
dHX_SH=[dTdt1 dTdt2]' ;     %Returning both unknown temperature
SH.ODE=1;
end