function X=Hybrid(Mode,Type,Startup)

global PTC_scf PTC_SCF  steamgen_LFR_bef_PTC  PTC_HT_OD  Type LFR_n Mode Startup PTC_HT PTC_LT
global Xa XA  Xax POW POWeT_pos_pow ip3 msgenout test timestart break_time_stop LFR_msteam OP PTC_Fullplant LFRsim  lfr_I_sec
global HT HX SH SG PH LT drum_msgen mwin_dear dt LFR Drum  Dear SD first_LFR_IC iter_scf Eng_gain_arr_PTC1 Eng_gain_arr_LFR1

global stef_const SCF_TF_implic SCF_TA_implic SCF_TE_implic HT_Mass_implic  HT_Entha_implic w_iter_scf shut_cou_sd
global theta  sin_zero steaystate tim_iter phase_enth msgen_drum  single_scaling two_scaling PTC_scf_OD ph_twout sh_tsout
global U he_supp lfr_press_sec  dru_press_sec hwin_dear   msteam_lfr Two  Two_sec   dea_flo phase_pipeend shut_cou_sg
global delta_absor dt_par Tabsor_pre hs_drum hp rho P h u T x TAbo  Tglass Ck  hpp Ckk g dpbydt  scfhp LFR_Temp_WAT
global simulation_complete  shut_HT shut_LT shut_PH shut_SH shut_SG shut_SD SG_night SD_night break_time
global latent_s row_l_s row_v_s sur_s  cpW_s  Te dyn_vis_s Ther_s hb2_sg hb1_sg mosat

%To load the all initial values for respective type
if Type==0                                  %(Constant Solar radiation)
    load lfr_I_sec_700_all_Lgp.mat
    simu_time_end=9*3600;
elseif Type==1                              %(Constant Solar radiation with step change)
    load lfr_I_sec_step_Lgp.mat
elseif Type==2                              %(Real time Solar radiation)
    %load lfr_I_sec_real_Lgp.mat
    load lfr_I_sec_HX_Case_study_Low1.mat      %Scenario-1
    %load lfr_I_sec_HX_Case_study_high_Low1.mat %Scenario-2
elseif Type==3                              %(Quadratic Solar radiation)
    load lfr_I_sec_quad_Lgp.mat
end

%initialisation
test=1;
TW_in_HX=[];
steam_phase=0;
Twin_SD_axis=[];
phase=0;
Twin_SD=[];
Xax.SD_steam=[0];
Xax.SD=[0];
IP_mwin_flag=0;
Eng_gain_arr_PTC1=[];
Eng_gain_arr_LFR1=[];
Drum.press=1;
Xaxis_water=[];
Xa.X_SH_U=[];


if Startup==1                                                                       %Cold strtup
    tic                                                                             %To see the total time for the simulation
    for i=1:1:leng_I                                                                %leng_I=2880*60  for 2 days
        while SG.boiling==0                                                         %When there is no boiling happan

            for iter_scf=timestart:dt.scf:simu_time_end                             %0 to simu_time_endtime=hour*3600
                iter_scf_oil_loop=iter_scf                                          %To display the iteration no
                if iter_scf_oil_loop ==4740
                    disp('stop')
                end
                % 1. LT-PTC-LT Connection
                PTC_scf.Toilin=LT.Toout;                                            %Output of LT goes into PTC, So LT-PTC connected

                if  mod(iter_scf,60)==0                                             %After every 60 sec
                    PTC_scf.I= lfr_I_sec(ip1);                                      %ip1 takes 1 solar radiation value at a time and will reamins for 60 sec
                    Ambient_Temp=Ambient_Temp_ind(ip1);                             %Ambient Temperature                oC
                    if ip1<length(lfr_I_sec)                                        %Loop for ip1 does not exceed lfr_I_sec size
                        ip1=ip1+1;
                    else
                        count=1
                    end
                end
                HX.Ambient_Tempr=Ambient_Temp;                                      %HX stands for Heat exchanger

                %For storing purpose
                OP.I_solar=[OP.I_solar PTC_scf.I];                                  %To save the solar radiation
                OP.Ambient_T=[OP.Ambient_T Ambient_Temp];                           %To save the ambient temperature

                %Condition for Bypass HX
                % if  PTC_SCF.Xintial(PTC_scf.grid) < 150                             %Output of PTC oil temp < 150
                if  HT.Toout < 150                                                  %Output of PTC oil temp < 150
                    PTC_HT_LTalone=1;                                               %PTC, HT, LT form route and bypass rest(HX)
                else
                    PTC_HT_LTalone=0;                                               %PTC,HT,LT not alone, HX added
                end

                if PTC_HT_LTalone==1                                                %PTC, HT, LT form route and bypass rest,PTC op temp<150
                    %% Oil loop

                    %Connect PTC
                    Tspan=[0  dt.scf];                                              %o to 1 second
                    options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                    [Ts,Y_SCF]=ode15s(@solarfield,Tspan,PTC_SCF.Xintial,options);   %Integrate PTC tank ODEs
                    PTC_SCF.Xintial=(Y_SCF(length(Ts),:)');
                    PTC_out_temp=PTC_SCF.Xintial(15)                                %PTC outlet temp

                    if (HT.Toout<= PTC_SCF.Xintial(PTC_scf.grid))                   %If 40 oC (HT initial temp) <= Oil output temp of PTC
                        %Connect PTC-HT-LT
                        PTC_HT_OD=1;                                                %Then connect HT with PTC together and LT
                        PTC_LT_OD=0;
                        [HT_out_temp,LT_out_temp]=PTC_HT_LT_connection(Tspan);      %Calling function file with connection of PTC-HT-LT
                    else
                        %Connect PTC-LT
                        PTC_LT_OD=1;                                                %Connect PTC with LT only when HT temp >PTC outlet
                        PTC_HT_OD=0;
                        [LT_out_temp]=PTC_LT_connection(Tspan);                     %%Calling function file with connection of PTC-LT

                    end

                    % %TO compute energy from PTC
                    % [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);              %Function file calling for energy computation from PTC component
                    % E_ptc_num=E_ptc_num+1;                                          %Update step

                    %% Water loop: It should be parallelly run with OIL loop

                    if mod(iter_scf,LFR.dt)==0 && iter_scf~=0                       %mod(iter_scf,60)=0

                        [time_run]=LFR_sub_fun1(LFR_n);                             %LFR Initialization function

                        %For storing purpose
                        LFR.IP_mwin=[LFR.IP_mwin LFR.mw_indi];                      %What is the input mass of water going in to LFR, here indi=Invidual pipe

                        % Calling LFRsimulation file
                        [iter]=LFRsimulation(LFR_n);                                %LFR simulation function file

                        %For storing purpose
                        Xax.LFR=[Xax.LFR iter_scf];                                 %Storing iteration number

                        if  first_LFR_IC==1                                         %Only for 1st time, after that it reach 2 and Drum.Temp_wat will take
                            first_LFR_IC=first_LFR_IC+1;                            %After 2nd iteration comes it is not needed
                        end

                        %phase 1=Pure steam, phase 0=No steam
                        LFR.msteam_out_indi=LFRsim.phase*LFR.mw_indi;               %Mass of steam out from LFR
                        LFR.msteam_pipeout8=LFR.nos_pipe*LFR.msteam_out_indi;       %Total Mass of steam out from LFR
                        LFR.mwater_out=(1-LFRsim.phase)*LFR.mw_indi;                %Mass of water out from LFR=1*0.3
                        LFR.mwater_pipeout8=LFR.nos_pipe*LFR.mwater_out;            %Total Mass of water from all 8 pipe=8*0.3

                        %For storing purpose: LFr mass of water & steam out at every time instant
                        LFR_mwater_out_nos_pipe(time_run+1)=LFR.mwater_pipeout8;    %Mass of water out from LFR
                        LFR_msteam_out_nos_pipe(time_run+1)=LFR.msteam_pipeout8;    %Mass of steam out from LFR

                        h_out_lfr=LFRsim.h(time_run+1,end);                         %Enthalpy of water out from LFR
                        hwin_drum=h_out_lfr;                                        %Enthalpy of water in to SD
                        LFR.press_end=LFRsim.P(time_run+1,end);                     %LFR end point pressure
                        LFR.Temp_wat=XSteam('T_ph',LFR.press_end,h_out_lfr*10^-3);

                        if LFRsim.phase >0                                          %If there is steam
                            mwin_dear=LFR.msteam_pipeout8;                          %The amount of steam produced and going out=Mass of water in from deareator to maintain the water level
                            Dear.mwin=mwin_dear;                                    %Mass of water in to LFR = Dear mass of water in
                            Dear.Twin=HX.Twin;                                      %Temp of water in to the hX is same as temp of water from Dear        30 0C
                            Dear.hwin=XSteam('h_pT',LFR.Press_in,Dear.Twin)*1000;   %Specific enthalpy of water flowing into SD      J/kg
                            steam_phase=1;
                        else                                                        %If there is no steam the values will be zero
                            mwin_dear=0;
                            Dear.mwin=0;
                            Dear.Twin=0;
                            Dear.hwin=0;
                        end
                        %Our aim is to generate steam from the LFR not from SD. So to check SD water saturated or not.
                        sat_h_drum=(XSteam('hL_p',Drum.press))*1000;                %Saturated liquid enthalpy of drum from Drum pressure, Water got saturated or not we need, Here Drum pressure will be initial one i.e. 2bar

                        %For connecting LFR-SD
                        Drum.mwin=LFR.mwater_pipeout8;                              %SD mass of water in from LFR
                        Drum.mwout=LFR.total_mw_in;                                 %Total mass of water out from SD will go to LFR as input         %LFR.total_mw_in=LFR.nos_pipe*LFR.mw_indi;   %2.4 kg/s is coming/8 pipes=1 pipe flow
                        %Drum.hwin=hwin_drum;                                       %Enthalpy of water in to SD
                        Drum.hwin_SD=hwin_drum;                                     %Enthalpy of water in to SD

                        %For storing purpose
                        if Dear.mwin>0
                            SD.IP_mwin=[SD.IP_mwin Dear.mwin];                      %What is the SD mass of water in from LFR
                            IP_mwin_flag=1;
                        end
                        if time_run==1
                            drum_pressure(1)=Drum.press;                            %Drum pressure=1 bar (Initial)
                        end
                        %Connect SD
                        options= odeset('Events',@event_fun_SD);%??
                        [TS_SD,Y_SD,TE,VE]=ode45(@SD_dynamics_updated_ode,T_SPAN_SD,SD_intial,options);         %Integrate SD dynamics
                        SD_intial=(Y_SD(length(TS_SD),:)');                                                     %Updating step
                        SD.ODE=1;                                                                               %For plotting purpose to match the time axis

                        %For storing purpose
                        Yax.press_SD=[Yax.press_SD Drum.press ];                    %Y is for other variable save
                        Xax.SD=[Xax.SD iter_scf];                                   %X is for time axis save
                        OP.SDr=[OP.SDr ;SD_intial'];                                %To save SD initial value for every time instant, it will alwyas update

                        Drum.Mass=SD_intial(1);                                     %Total mass
                        Drum.Mass_wat=SD_intial(2);                                 %Mass of water
                        Drum.Mass_steam=SD_intial(3);                               %MAss of steam
                        Drum.hwat=SD_intial(4);                                     %Enthalpy of water
                        Drum.hst=SD_intial(5);                                      %Enthalpy of steam

                        if test==1
                            Drum.Temp_wat=XSteam('T_ph',LFR.press_end,Drum.hwat*10^-3); %SD water temp
                        else
                            Drum.Temp_wat=XSteam('T_ph',Drum.press,Drum.hwat*10^-3); %SD water temp
                        end

                        if time_run==1
                            drum_Tsteam(1)=100;                                     %100 0C is just a initial drum steam temp guess
                        end
                        if Drum.Mass_steam >0
                            % Drum.temp_steam=XSteam('T_ph',LFR.press_end,Drum.hst*10^-3); %SD steam temp
                            Drum.temp_steam=XSteam('T_ph',Drum.press,Drum.hst*10^-3); %SD steam temp
                            drum_Tsteam(time_run+1)=Drum.temp_steam;
                            Xax.SD_steam=[Xax.SD_steam iter_scf];
                        end

                        %To store the variable wrt time
                        %drum_hsteam(time_run+1)=Drum.hst;                          %Enthalpy of steam
                        drum_hsteam(time_run+1)=Drum.hst*10^-3;                     %Enthalpy of steam
                        drum_row_st(time_run+1)=Drum.rho_st;                        %Density of steam present in SD     kg/m^3
                        drum_Vsteam(time_run+1)=Drum.Vsteam;                        %NOT USED
                        drum_Mass(time_run+1)=Drum.Mass;                            %Total mass
                        drum_Mass_wat(time_run+1)=Drum.Mass_wat;                    %Mass of water
                        drum_Mass_steam(time_run+1)=Drum.Mass_steam;                %MAss of steam
                        drum_pressure(time_run+1)=Drum.press;                       %Drum pressure
                        drum_hwat(time_run+1)=Drum.hwat*10^-3;                      %Enthalpy of water
                        drum_Twat(time_run+1)=Drum.Temp_wat;                        %SD water temp

                        drum_msgen(time_run+1)=Drum.msgen;                          %SD mass of steam generation
                        drum_ms_out40(time_run+1)=Drum.msout;                       %SD mass of steam going out
                        Drum.msout_dear(time_run+1)=Drum.msout_dear(time_run)+(LFR.dt*Drum.msout);
                        waterin_drum(time_run+1)=waterin_drum(time_run)+(LFR.dt*mwin_dear);%Mass of water in to the drum
                        Steam_Q_drum(time_run+1)=LFRsim.phase;                      %Steam quality
                        Drum.mwin_n(time_run+1)=mwin_dear;                          %The amount of steam produced and going out=Mass of water in from deareator to maintain the water level
                        LFR_temp_fluid(time_run+1)=LFR.Tfluid;%%LFR.Temp_wat        %Output temp of LFR Fluid

                        %Energy computation from LFR
                        [Eng_gain_arr_LFR1]=Energy_Compute_LFR(E_lfr_num,time_run); %Function file calling energy computation from LFR
                        E_lfr_num=E_lfr_num+1;                                      %Update setp

                        POWeT_pos_pow.powgen(xx)=0;
                        xx=xx+1;

                        Xax.POW=[Xax.POW iter_scf];                                     %Storing iter_scf at Xax.POW

                        if  IP_mwin_flag==1
                            SD.IP_mwin_time=[SD.IP_mwin_time iter_scf];
                        end
                    end
                end


                if PTC_HT_LTalone==0                                                %PTC temp>150
                    %% Oil loop

                    %Connect PTC
                    Tspan=[0  dt.scf];                                              %o to 1 second
                    options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                    [Ts,Y_SCF]=ode15s(@solarfield,Tspan,PTC_SCF.Xintial,options);  %Integrate PTC tank ODEs
                    PTC_SCF.Xintial=(Y_SCF(length(Ts),:)');
                    PTC_out_temp=PTC_SCF.Xintial(15)                               %PTC outlet temp

                    %Connect HT with PTC
                    HT.moilin=PTC_scf.moil*3;                                       %Mass of oil out from SCF enters to HT
                    HT.moilout=HT.moilin;                                           %Mass of oil out from HT same as mass of oil in to HT
                    HT.hin=h_oil(PTC_SCF.Xintial(PTC_scf.grid));                    %Enthalpy of oil in to HT

                    if  PTC_HT_OD==1                                                %If HT tank temp <= PTC outlet temp
                        %Connect HT
                        options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                        [Ts,Y_HT]=ode15s(@HTtank,Tspan,PTC_HT.Xintial,options);     %ODE integration of HT
                        PTC_HT.Xintial=(Y_HT(length(Ts),:)');

                        HT.hout=PTC_HT.Xintial(2);                                  %Enthalpy of oil coming out from HT
                        %opts = optimset('TolFun',1e-12,'Display','off') ;
                        %HT.Toout=fsolve('enthal_Temp_HT',HT.Toout,opts);
                        HT.Toout=(-1.49681+sqrt(1.49681^2-4*0.0014*(-18.17454-HT.hout)))/(2*0.0014);   %At current enthalpy HT output temperature
                        HT_out_temp=HT.Toout;                                       %For saving HT outlet Temp
                        %SH.Toilin=HT.Toout;
                        %if HT.Toout>=150
                        %Connect HT with SG_Subcooled
                        SG.moil=HT.moilout;                                         %The mass of oil coming from HT goes into SG
                        SG.Toilin=HT.Toout;                                         %Temp of oil to SG=HT temp of oil out
                        %end
                    else
                        %Connect HT with SG_Subcooled
                        SG.moil=PTC_scf.moil*3;                                     %Mass of oil out from SCF enters to SG (When HT not conected)
                        SG.Toilin=PTC_SCF.Xintial(PTC_scf.grid);                    %Outlet of SCF connected to SG
                    end

                    %At 1 bar saturation enthalpy of water is 417.44 kJ/kg (Check unit)
                    SG.Wsat=XSteam('hL_p',SG.press_int);                            %SG.press_int=1bar pressure at SG, which is saturation pressure of water.
                    check_Wsat_SG=(SG.Wsat-HX.SGintial(5));                         %HX.SGintial(5)=Current enthalpy

                    if  (check_Wsat_SG <=0)                                         %So if saturation enthalpy is zero/-ve then saturation will occure.
                        disp('Saturation occured');
                    else %if HT.Toout>=150
                        %Connect SG_Subcooled: Here SG subcooled means no boiling happan till now, saturation has not occured yet
                        options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                        [Ts,Y_HXSG]=ode15s(@HXSG_subcool,Tspan,HX.SGintial,options);%HXSG_subcool will be connected till SG pressure reach setopint pressure
                        HX.SGintial=(Y_HXSG(length(Ts),:)');
                        SG.ODE=1;
                    end

                    if SG.ODE==1
                        %To store the variables
                        OP.SGuaf=[OP.SGuaf SG.UAF];                                     %To store Final UAF
                        OP.SGhtube=[OP.SGhtube  SG.htctube];                            %To store heat transfer coefficient of tube side
                        OP.SGhshell=[OP.SGhshell SG.htcshell];                          %TO store heat transfer coefficient of shell side
                        OP.SGF=[OP.SGF SG.htcF];                                        %To store correction factor
                        OP.SGU=[OP.SGU SG.htcU];                                        %TO store overall heat transfer coefficient
                    end

                    %Connect LT with SG
                    if SG.ODE==1
                        LT.moilin=SG.moil;                                              %LT mass of oil comes from SG
                    else
                        LT.moilin=HT.moilout;                                                        %Mass of oil out from LT same as mass of oil in to LT
                    end

                    LT.moilout=LT.moilin;
                    if iter_scf==1          %Why
                        LT.hin=h_oil(((HT.Tintial+LT.Tintial)/2)-1);                %Why like this??
                    else
                        LT.hin=h_oil(HX.SGintial(1));                               %Enthalpy of oil in to LT is calculated at SG output temperature.
                    end
                    %X.SGintial(1)=HT.Tintial-1 , why not HTtout
                    options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                    [Ts,Y_LT]=ode15s(@LTtank,Tspan,PTC_LT.Xintial,options);         %Integrating LT tank ODEs
                    PTC_LT.Xintial=(Y_LT(length(Ts),:)');

                    LT.hout=PTC_LT.Xintial(2);                                      %Enthalpy of oil out from LT
                    %opts = optimset('TolFun',1e-12,'Display','off') ;
                    %LT.Toout=fsolve('enthal_Temp_LT',LT.Toout,opts);

                    %Enthalpy polynomial fit equation:
                    %Enthalpy=(0.0014*T^2)+(1.49681*T)-18.17454; (TAken from thermino VP1 pdf file)
                    %Concidering only +ve part
                    LT.Toout=(-1.49681+sqrt(1.49681^2-4*0.0014*(-18.17454-LT.hout)))/(2*0.0014);    %LT outlet temperature
                    LT_out_temp= LT.Toout;                                                          %LT temperature output
                    %                 HX.Toout=LT.Toout;
                    %LT again connected to PTC-
                    PTC_SCF.Xintial(1)=LT.Toout;                                    %LT temperature output is going to PTC inlet
                    %PTC_scf.moil=LT.moilout;

                    % %TO compute energy
                    % [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);              %Function file calling for energy compute from PTC
                    % E_ptc_num=E_ptc_num+1;                                          %Update step

                    %% Water loop: It should be parallelly run with OIL loop

                    if mod(iter_scf,LFR.dt)==0 && iter_scf~=0                       %mod(iter_scf,60)=0

                        [time_run]=LFR_sub_fun1(LFR_n);                             %LFR initialization function file
                        %                     LFR_n=LFR_n+1;                                              %Update step

                        %For storing purpose
                        LFR.IP_mwin=[LFR.IP_mwin LFR.mw_indi];                      %What is the input mass of water going in to LFR, here indi=Invidual pipe

                        % Calling LFRsimulation file
                        [iter]=LFRsimulation(LFR_n);                                %LFR main simulation function file

                        %For storing purpose
                        Xax.LFR=[Xax.LFR iter_scf];                                 %Storing iteration number\
                        if  first_LFR_IC==1                                         %Only for 1st time, after that it reach 2 and Drum.Temp_wat will take
                            first_LFR_IC=first_LFR_IC+1;                            %After 2nd iteration comes it is not needed
                        end

                        %phase 1=Pure steam, phase 0=No steam
                        LFR.msteam_out_indi=LFRsim.phase*LFR.mw_indi;               %Mass of steam out from LFR
                        LFR.msteam_pipeout8=LFR.nos_pipe*LFR.msteam_out_indi;       %Total Mass of steam out from LFR
                        LFR.mwater_out=(1-LFRsim.phase)*LFR.mw_indi;                %Mass of water out from LFR=1*0.3
                        LFR.mwater_pipeout8=LFR.nos_pipe*LFR.mwater_out;            %Total Mass of water from all 8 pipe=8*0.3

                        %For storing purpose: LFr mass of water & steam out at every time instant
                        LFR_mwater_out_nos_pipe(time_run+1)=LFR.mwater_pipeout8;    %Mass of water out from LFR
                        LFR_msteam_out_nos_pipe(time_run+1)=LFR.msteam_pipeout8;    %Mass of steam out from LFR

                        h_out_lfr=LFRsim.h(time_run+1,end);                         %Enthalpy of water out from LFR
                        hwin_drum=h_out_lfr;                                        %Enthalpy of water in to SD
                        LFR.press_end=LFRsim.P(time_run+1,end);                     %LFR end point pressure
                        LFR.Temp_wat=XSteam('T_ph',LFR.press_end,h_out_lfr*10^-3);

                        if LFRsim.phase >0                                          %If there is steam
                            mwin_dear=LFR.msteam_pipeout8;                          %The amount of steam produced and going out=Mass of water in from deareator to maintain the water level
                            Dear.mwin=mwin_dear;                                    %Mass of water in to LFR = Dear mass of water in
                            Dear.Twin=HX.Twin;                                      %Temp of water in to the hX is same as temp of water from Dear        30 0C
                            Dear.hwin=XSteam('h_pT',LFR.Press_in,Dear.Twin)*1000;   %Specific enthalpy of water flowing into SD      J/kg
                            steam_phase=1;
                        else                                                        %If there is no steam
                            mwin_dear=0;
                            Dear.mwin=0;
                            Dear.Twin=0;
                            Dear.hwin=0;
                        end

                        %Our aim is to generate steam from the LFR not from SD. So to check SD water saturated or not.
                        sat_h_drum=(XSteam('hL_p',Drum.press))*1000;                %Saturated liquid enthalpy of drum from Drum pressure, Water got saturated or not we need

                        %For connecting LFR-SD
                        Drum.mwin=LFR.mwater_pipeout8;                              %SD mass of water in from LFR
                        Drum.mwout=LFR.total_mw_in;                                 %Total mass of water out from SD will go to LFR as input
                        %Drum.hwin=hwin_drum;                                       %Enthalpy of water in to SD
                        Drum.hwin_SD=hwin_drum;                                     %Enthalpy of water in to SD      ?Why this and above line

                        %For storing purpose
                        if Dear.mwin>0
                            SD.IP_mwin=[SD.IP_mwin Dear.mwin];                          %What is the SD mass of water in from LFR
                            IP_mwin_flag=1;
                        end

                        % Connect SD
                        options= odeset('Events',@event_fun_SD);
                        [TS_SD,Y_SD,TE,VE]=ode45(@SD_dynamics_updated_ode,T_SPAN_SD,SD_intial,options);         %Integrate SD dynamics
                        SD_intial=(Y_SD(length(TS_SD),:)');
                        SD.ODE=1;
                        %For storing purpose
                        Yax.press_SD=[Yax.press_SD Drum.press ];                    % Y is for other variable save
                        Xax.SD=[Xax.SD iter_scf];                                   % X is for time axis save
                        OP.SDr=[OP.SDr ;SD_intial'];                                %To save SD initial value for every time instant, it will alwyas update

                        Drum.Mass=SD_intial(1);                                     %Total mass
                        Drum.Mass_wat=SD_intial(2);                                 %Mass of water
                        Drum.Mass_steam=SD_intial(3);                               %MAss of steam
                        Drum.hwat=SD_intial(4);                                     %Enthalpy of water
                        Drum.hst=SD_intial(5);                                      %Enthalpy of steam

                        if test==1
                            Drum.Temp_wat=XSteam('T_ph',LFR.press_end,Drum.hwat*10^-3); %SD water temp
                        else
                            Drum.Temp_wat=XSteam('T_ph',Drum.press,Drum.hwat*10^-3); %SD water temp
                        end

                        if time_run==1
                            drum_Tsteam(1)=100;                                     %100 0C is just a initial drum steam temp guess
                        end
                        if Drum.Mass_steam >0
                            % Drum.temp_steam=XSteam('T_ph',LFR.press_end,Drum.hst*10^-3); %SD steam temp
                            Drum.temp_steam=XSteam('T_ph',Drum.press,Drum.hst*10^-3); %SD steam temp
                            drum_Tsteam(time_run+1)=Drum.temp_steam;
                            Xax.SD_steam=[Xax.SD_steam iter_scf];
                        end

                        %To store the variable wrt time
                        %drum_hsteam(time_run+1)=Drum.hst;                           %Enthalpy of steam
                        drum_hsteam(time_run+1)=Drum.hst*10^-3;                           %Enthalpy of steam
                        drum_row_st(time_run+1)=Drum.rho_st;                        %Density of steam present in SD     kg/m^3
                        drum_Vsteam(time_run+1)=Drum.Vsteam;                        %NOT USED
                        drum_Mass(time_run+1)=Drum.Mass;                            %Total mass
                        drum_Mass_wat(time_run+1)=Drum.Mass_wat;                    %Mass of water
                        drum_Mass_steam(time_run+1)=Drum.Mass_steam;                %MAss of steam
                        drum_pressure(time_run+1)=Drum.press;                       %Drum pressure=2bar
                        drum_hwat(time_run+1)=Drum.hwat*10^-3;                            %Enthalpy of water
                        drum_Twat(time_run+1)=Drum.Temp_wat;                        %SD water temp
                        %drum_Tsteam(time_run+1)=Drum.temp_steam;
                        drum_msgen(time_run+1)=Drum.msgen;                          %SD mass of steam generation
                        drum_ms_out40(time_run+1)=Drum.msout;                       %SD mass of steam going out
                        Drum.msout_dear(time_run+1)=Drum.msout_dear(time_run)+(LFR.dt*Drum.msout);
                        waterin_drum(time_run+1)=waterin_drum(time_run)+(LFR.dt*mwin_dear);
                        Steam_Q_drum(time_run+1)=LFRsim.phase;                      %Steam quality
                        Drum.mwin_n(time_run+1)=mwin_dear;                          %The amount of steam produced and going out=Mass of water in from deareator to maintain the water level
                        LFR_temp_fluid(time_run+1)=LFR.Tfluid;                      %LFR output temp of fluid


                        %Energy computation of LFR
                        [Eng_gain_arr_LFR1]=Energy_Compute_LFR(E_lfr_num,time_run); %Function file calling for Energy computation from LFR
                        E_lfr_num=E_lfr_num+1;                                      %Update step

                        %POWeT_pos_pow.powgen(xx)=0;    %?Why
                        %xx=xx+1;
                        if  IP_mwin_flag==1
                            SD.IP_mwin_time=[SD.IP_mwin_time iter_scf];
                        end
                    end

                    %For Storing purpose
                    POW.ms_SG(iter_scf+1)=SG.msgen;                                 %To store the value of SG mass of steam generated
                    POW.LFR(iter_scf+1)=Drum.msout;                                 %To store the value of SG mass of steam generated
                    POW.ms_turb(iter_scf+1)=Drum.msout+0;                           %To store the value of SG mass of steam generated
                    POW.Ts_turb(iter_scf+1)=HX.SHintial(2);                         %To store the value of SG mass of steam generated

                    %With LFR loop need to check SD pressure, if is it=40 bar then
                    %steam generated by SD injected to SH, So SH brough into the picture.

                    if  Drum.press>SD.press_st                                      %If Drum pressure is > 40bar
                        disp('Drum pressure is greater than setpoint pressure')
                        if HT.Toout >300 || PTC_SCF.Xintial(PTC_scf.grid) >300      %If this condition will not satify then steam will be vented out
                            steamgen_LFR_bef_PTC=1;    %Steam generation will start from LFR before PTC loop i.e SG
                            SH.ODE_bef_PTC=1;
                        end
                    end

                    if steamgen_LFR_bef_PTC == 1                                    %IF steam produce from LFR before SG
                        if PTC_HT_OD==1
                            SHLFR.Toilin=HT.Toout;           %HT_OD is connected  else SCF
                        else
                            SHLFR.Toilin=PTC_SCF.Xintial(PTC_scf.grid);                 %SG is connected to Solar field
                        end
                        %HX.SHintial=[SH.Toilin-2 LFR.Tfluid+1];                        %Initial Guess Temp of oil out and steam out from SH.
                        %HX.SHintial=[SH.Toilin-2 XSteam('Tsat_p',Drum.press,Drum.hst*10^-3)];
                        HX.SHintial=[SHLFR.Toilin-2 XSteam('T_ph',Drum.press,Drum.hst*10^-3)];

                        if PTC_HT_OD==1                                             %If HT is connected with PTC
                            SH.Toilin=HT.Toout;                                     %Ht oil outlet temp goes into SH oil inlet
                        else
                            SH.Toilin=PTC_SCF.Xintial(PTC_scf.grid);                %Otherwise PTC oil outlet temp goes into SH oil inlet
                        end

                        %Connect SH
                        SH.ODE=1;                                                   %Used under SH function file
                        options(1) = odeset('RelTol',1e-5,'AbsTol',1e-5);
                        [Ts,Y_HXSH]=ode15s(@HXSH_bef_PTC,Tspan,HX.SHintial);        %Integrate SH which receive steam only from SD
                        HX.SHintial=(Y_HXSH(length(Ts),:)');                        %Update step

                        %Power generation From LFR loop

                        %The power generated from the turbine is computed using Willan's line equation.
                        % here, a,b,c,d,e,f,g,h,i are the turbine parameters. Here, HX.SHintial(2)=Steam out temp from SH

                        POWei.lfr_ms=-0.263+(0.668*Drum.msout);                     %P(MWe), Power generated from the turbine with a=-0.263, b=0.668, c=0        MWe
                        POWei.lfr_CP=0.4+0.15*4;                                    %Xpc, Correction factor for Pressure (Xpc) with d=0.4, e=0.15, c=0, P=4Mpa
                        POWei.lfr_temp=0.125+0.0025*HX.SHintial(2);                 %XTc, Correction factor for Temperature (Xtc) with g=0.125, h=0.0025, i=0
                        POWei.lfr_powgen(iter_scf+1)=POWei.lfr_ms*POWei.lfr_CP*POWei.lfr_temp;      %Actual power(Pact)=P(MWe)*Xpc*XTc

                        pow_LFR=POWei.lfr_powgen(iter_scf+1);
                        POWeT.Tot_ms=POWei.lfr_ms;
                        POWeT.CP=POWei.lfr_CP;
                        POWeT.temp=POWei.lfr_temp;
                        POWeT.powgen(iter_scf+1)=POWei.lfr_powgen(iter_scf+1);
                    else
                        POWeT.powgen(iter_scf+1)=0;
                    end

                    if  POWeT.powgen(iter_scf+1) >0
                        POWeT_pos_pow.powgen(xx)=POWeT.powgen(iter_scf+1);
                        xx=xx+1;
                    else
                        POWeT_pos_pow.powgen(xx)=0;
                        xx=xx+1;
                    end
                    Xax.POW=[Xax.POW iter_scf];                                     %Storing iter_scf at Xax.POW

                    OP_TTsteam=XSteam('Tsat_p',SG.press_int);
                    OP.Tsteam=[OP.Tsteam OP_TTsteam ];                              %Storing OP_TTsteam

                    if  msgenout>0
                        HX.mwin= msgenout;
                        SG.mwin=HX.mwin;                                        %Mass of water going in to Sg
                        PH.mwin=HX.mwin;                                        %Mass of water going in to PH
                    else
                        HX.mwin=0.5;
                        SG.mwin=HX.mwin;                                        %Mass of water going in to Sg
                        PH.mwin=HX.mwin;                                        %Mass of water going in to PH
                    end

                    %For stroign purpose
                    PH.sav_mwin(iter_scf+1)=PH.mwin;                                %Mass of water in to PH
                    SG.sav_mwin(iter_scf+1)=SG.mwin;                                %Mass of water in to SG
                    HX.sav_mwin(iter_scf+1)=HX.mwin;                                %Mass of water in to HX
                    mwin_SD(iter_scf+1)=Dear.mwin;                                  %Mass of water in to SD from Deaerator
                    %Twin_SD(iter_scf+1)=Dear.Twin;                                  %Temp of water in to SD from Deaerator      oC
                    mwin_LFR_indi(iter_scf+1)=LFR.mw_indi;                          %Mass of water in to individual LFR pipe
                    mwin_LFR_total(iter_scf+1)=LFR.total_mw_in;                     %Total Mass of water in to LFR
                end

                %TO compute energy
                [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);
                E_ptc_num=E_ptc_num+1;

                if length(OP.SHU)~=length(Xa.X_SH_U)
                    disp('Length problem SH UAF')
                end
                %FOr storing purpose
                Xaxis=[Xaxis  iter_scf];
                OP.SCF=[OP.SCF  PTC_SCF.Xintial];                                   %Store PTC temp
                OP.HT_Temp=[OP.HT_Temp HT_out_temp];                                %Store HT temp
                %OP.LT_Temp=[OP.LT_Temp LT.Toout];                                  %Store LT temp
                OP.LT_Temp=[OP.LT_Temp LT_out_temp];

                if SH.ODE==1
                    OP.SH=[OP.SH  HX.SHintial];
                    Xa.X_SH=[Xa.X_SH iter_scf];
                    OP.sh_tsout=[OP.sh_tsout  HX.SHintial(2)];        %HX.SHintial(2): Steam out temp
                    Tur.msin=[Tur.msin SH.msin];
                    if SH.ODE_bef_PTC==1
                        OP.SHuaf=[OP.SHuaf SH.UAF];
                        OP.SHhtube=[OP.SHhtube  SH.htctube];
                        OP.SHhshell=[OP.SHhshell SH.htcshell];
                        OP.SHF=[OP.SHF SH.htcF];
                        OP.SHU=[OP.SHU SH.htcU];
                        Xa.X_SH_U=[Xa.X_SH_U iter_scf];
                    end
                end

                if SG.ODE==1
                    OP.SG_temp=[OP.SG_temp HX.SGintial(1)];
                    OP.SGTw=[OP.SGTw SG.Twater];
                    XA.X_SG=[XA.X_SG iter_scf];
                    OP.SGmsgen=[OP.SGmsgen SG.msgen];
                    OP.SG_pressure=[OP.SG_pressure HX.SGintial(6)];
                    TW_in_HX=[TW_in_HX HX.Twin];                                   %To store the value of Temp of water in to Heat exchanger
                end


                if SD.ODE==1
                    OP.Drum_Temp_wat=[OP.Drum_Temp_wat Drum.Temp_wat];
                    OP.LFR_Temp=[OP.LFR_Temp LFR.Tfluid];
                    XA.X_SD=[XA.X_SD iter_scf];
                end
                if steam_phase>0
                    Twin_SD=[Twin_SD Dear.Twin];
                    Twin_SD_axis=[Twin_SD_axis iter_scf];
                end


                pow_LFR_arr=[pow_LFR_arr pow_LFR];              %power generation from LFR
                pow_PTC_arr=[pow_PTC_arr pow_PTC];              %power generation from PTC

                %SG saturtaed enthalpy of water at 1 bar pressure
                SG.Wsat=XSteam('hL_p',SG.press_int);                                %To check saturated liquid enthalpy
                check_Wsat_SG=(SG.Wsat-HX.SGintial(5));
                if  (check_Wsat_SG <=0 )
                    disp('Saturation Occured');
                    HX.SGintial(5)=SG.Wsat; %----correction to have equal value of satu enthalphy  ??
                    SG.boiling=1;
                    break
                end
            end
        end

        timestart=Xaxis(end);
        SG.msgen=0;% intial value
        while (SG.boiling==1  && PTC_Fullplant==0)

            for iter_scf=(timestart+1):dt.scf:simu_time_end
                boil_loop=iter_scf

                %% Oil loop
                % 1. LT-PTC-LT Connection
                PTC_scf.Toilin=LT.Toout;                                            %Output of LT goes into PTC=40 oC, So LT-PTC connected

                if  mod(iter_scf,60)==0                                             %After every 60 sec
                    PTC_scf.I= lfr_I_sec(ip1);
                    Ambient_Temp=Ambient_Temp_ind(ip1);
                    if ip1<length(lfr_I_sec)
                        ip1=ip1+1;
                    else
                        break
                    end
                end
                HX.Ambient_Tempr=Ambient_Temp;

                %For storing purpose
                OP.I_solar=[OP.I_solar PTC_scf.I];
                OP.Ambient_T=[OP.Ambient_T Ambient_Temp];

                %Connect PTC
                Tspan=[0  dt.scf];                      %o to 1 second
                options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                [Ts,Y_SCF]=ode15s(@solarfield,Tspan,PTC_SCF.Xintial,options);       %Integrate PTC tank ODEs
                PTC_SCF.Xintial=(Y_SCF(length(Ts),:)');
                PTC_out_temp=PTC_SCF.Xintial(15)                                    %PTC outlet temp

                %Connect HT with PTC
                HT.moilin=PTC_scf.moil*3;                                           %WHy not given in sir code
                HT.moilout=HT.moilin;
                HT.hin=h_oil(PTC_SCF.Xintial(PTC_scf.grid));

                if PTC_HT_OD==1
                    options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                    [Ts,Y_HT]=ode15s(@HTtank,Tspan,PTC_HT.Xintial,options);
                    PTC_HT.Xintial=(Y_HT(length(Ts),:)');

                    HT.hout=PTC_HT.Xintial(2);
                    opts = optimset('TolFun',1e-12,'Display','off') ;
                    %               HT.Toout=fsolve('enthal_Temp_HT',HT.Toout,opts);
                    HT.Toout=(-1.49681+sqrt(1.49681^2-4*0.0014*(-18.17454-HT.hout)))/(2*0.0014);
                    HT_out_temp=HT.Toout;

                    %Connect HT with SG_Subcooled
                    SG.moil=HT.moilout;
                    SG.Toilin=HT.Toout;                                             %Temp of oil to SG=HT temp of oil out
                else
                    SG.moil=HT.moilout;
                    SG.Toilin=PTC_SCF.Xintial(PTC_scf.grid);
                end
                SG.Wsat=XSteam('hL_p',SG.press_int);
                check_Wsat_SG=(SG.Wsat-HX.SGintial(5));

                if  (check_Wsat_SG <=0)                                         %So if saturation enthalpy is zero/-ve then saturation will occure.
                    disp('Saturation occured');
                end

                SG.hs= XSteam('hV_p',HX.SGintial(6));
                SG.hw=XSteam('hL_p',HX.SGintial(6));

                %Connect SG_Saturated
                options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                [Ts,Y_HXSG]=ode15s(@HXSG_sat,Tspan,HX.SGintial,options);
                HX.SGintial=(Y_HXSG(length(Ts),:)');
                SG_pressure=HX.SGintial(6)
                SG.ODE=1;

                %To check is there any imaginary part
                nedstop=isreal(HX.SGintial );
                if (nedstop)==0   %has img part
                    disp('Imaginary number in HX.SGintial')
                end

                %To store the variables
                OP.SGuaf=[OP.SGuaf SG.UAF];
                OP.SGhtube=[OP.SGhtube  SG.htctube];
                OP.SGhshell=[OP.SGhshell SG.htcshell];
                OP.SGF=[OP.SGF SG.htcF];
                OP.SGU=[OP.SGU SG.htcU];

                %Connect LT with SG
                LT.moilin=SG.moil;  %Not in sir code why
                LT.moilout=LT.moilin;
                %                 if iter_scf==1          %Why
                %                     LT.hin=h_oil(((HT.Tintial+LT.Tintial)/2)-1);
                %                 else
                LT.hin=h_oil(HX.SGintial(1));
                %end

                options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                [Ts,Y_LT]=ode15s(@LTtank,Tspan,PTC_LT.Xintial,options);
                PTC_LT.Xintial=(Y_LT(length(Ts),:)');

                LT.hout=PTC_LT.Xintial(2);
                %opts = optimset('TolFun',1e-12,'Display','off') ;
                %LT.Toout=fsolve('enthal_Temp_LT',LT.Toout,opts);

                %Enthalpy polynomial fit equation:
                %Enthalpy=(0.0014*T^2)+(1.49681*T)-18.17454; (TAken from thermino VP1 pdf file)
                %Concidering only +ve part
                LT.Toout=(-1.49681+sqrt(1.49681^2-4*0.0014*(-18.17454-LT.hout)))/(2*0.0014);
                LT_out_temp=LT.Toout;

                %LT again connected to PTC
                PTC_SCF.Xintial(1)=LT.Toout;
                %PTC_scf.moil=LT.moilout;

                %TO compute energy
                % [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);
                % E_ptc_num=E_ptc_num+1;

                %% Water loop: It should be parallelly run with OIL loop

                if mod(iter_scf,LFR.dt)==0                            %mod(iter_scf,60)=0

                    [time_run]=LFR_sub_fun1(LFR_n);
                    %                 LFR_n=LFR_n+1;

                    %For storing purpose
                    LFR.IP_mwin=[LFR.IP_mwin LFR.mw_indi];                          %What is the input mass of water going in to LFR, here indi=Invidual pipe

                    % Calling LFRsimulation file
                    [iter]=LFRsimulation(LFR_n);

                    %For storing purpose
                    Xax.LFR=[Xax.LFR iter_scf];                                     %Storing iteration number

                    if  first_LFR_IC==1                                             %Only for 1st time, after that it reach 2 and Drum.Temp_wat will take
                        first_LFR_IC=first_LFR_IC+1;                                %After 2nd iteration comes it is not needed
                    end

                    %phase 1=Pure steam, phase 0=No steam
                    LFR.msteam_out_indi=LFRsim.phase*LFR.mw_indi;                   %Mass of steam out from LFR
                    LFR.msteam_pipeout8=LFR.nos_pipe*LFR.msteam_out_indi;           %Total Mass of steam out from LFR
                    LFR.mwater_out=(1-LFRsim.phase)*LFR.mw_indi;                    %Mass of water out from LFR=1*0.3
                    LFR.mwater_pipeout8=LFR.nos_pipe*LFR.mwater_out;                %Total Mass of water from all 8 pipe=8*0.3

                    %For storing purpose: LFr mass of water & steam out at every time instant
                    LFR_mwater_out_nos_pipe(time_run+1)=LFR.mwater_pipeout8;        %Mass of water out from LFR
                    LFR_msteam_out_nos_pipe(time_run+1)=LFR.msteam_pipeout8;        %Mass of steam out from LFR

                    h_out_lfr=LFRsim.h(time_run+1,end);                             %Enthalpy of water out from LFR
                    hwin_drum=h_out_lfr;                                            %Enthalpy of water in to SD
                    LFR.press_end=LFRsim.P(time_run+1,end);                         %LFR end point pressure
                    LFR.Temp_wat=XSteam('T_ph',LFR.press_end,h_out_lfr*10^-3);

                    if LFRsim.phase >0                                              %If there is steam
                        mwin_dear=LFR.msteam_pipeout8;                              %The amount of steam produced and going out=Mass of water in from deareator to maintain the water level
                        Dear.mwin=mwin_dear;                                        %Mass of water in to LFR = Dear mass of water in
                        Dear.Twin=HX.Twin;                                          %Temp of water in to the hX is same as temp of water from Dear        30 0C
                        Dear.hwin=XSteam('h_pT',LFR.Press_in,Dear.Twin)*1000;       %Specific enthalpy of water flowing into SD      J/kg
                        steam_phase=1;
                    else                                                            %If there is no steam
                        mwin_dear=0;
                        Dear.mwin=0;
                        Dear.Twin=0;
                        Dear.hwin=0;
                    end

                    %Our aim is to generate steam from the LFR not from SD. So to check SD water saturated or not.
                    sat_h_drum=(XSteam('hL_p',Drum.press))*1000;                    %Saturated liquid enthalpy of drum from Drum pressure, Water got saturated or not we need

                    if  isnan(Drum.hwat)==1                                         %IF NAN element is there
                        disp('Null elements captured in Drum.hwat')
                    end

                    %For connecting LFR-SD
                    Drum.mwin=LFR.mwater_pipeout8;                                  %SD mass of water in from LFR
                    Drum.mwout=LFR.total_mw_in;                                     %Total mass of water out from SD will go to LFR as input
                    %Drum.hwin=hwin_drum;                                            %Enthalpy of water in to SD
                    Drum.hwin_SD=hwin_drum;                                         %Enthalpy of water in to SD      ?Why this and above line

                    %For storing purpose
                    IP_mwin_flag=0;
                    if Dear.mwin>0
                        SD.IP_mwin=[SD.IP_mwin Dear.mwin];                          %What is the SD mass of water in from LFR
                        IP_mwin_flag=1;
                    end
                    % Connect SD
                    options= odeset('Events',@event_fun_SD);
                    [TS_SD,Y_SD,TE,VE]=ode45(@SD_dynamics_updated_ode,T_SPAN_SD,SD_intial,options);         %Integrate SD dynamics
                    SD_intial=(Y_SD(length(TS_SD),:)');
                    SD.ODE=1;

                    if isnan(Drum.press)==1                                         %To check any NAN for Drum pressure
                        disp('Null elements captured in Drum Pressure')
                    end

                    %For storing purpose
                    Yax.press_SD=[Yax.press_SD Drum.press];                         %To save Drum pressure ... Y is for other variable save
                    Xax.SD=[Xax.SD iter_scf];                                       %X is for time axis save
                    OP.SDr=[OP.SDr ;SD_intial'];                                    %To save SD initial value for every time instant, it will alwyas update

                    Drum.Mass=SD_intial(1);                                         %Total mass
                    Drum.Mass_wat=SD_intial(2);                                     %Mass of water
                    Drum.Mass_steam=SD_intial(3);                                   %MAss of steam
                    Drum.hwat=SD_intial(4);                                         %Enthalpy of water
                    Drum.hst=SD_intial(5);                                          %Enthalpy of steam
                    if test==1
                        Drum.Temp_wat=XSteam('T_ph',LFR.press_end,Drum.hwat*10^-3); %SD water temp
                    else
                        Drum.Temp_wat=XSteam('T_ph',Drum.press,Drum.hwat*10^-3); %SD water temp
                    end

                    if Drum.Mass_steam>0
                        % Drum.temp_steam=XSteam('T_ph',LFR.press_end,Drum.hst*10^-3); %SD steam temp
                        Drum.temp_steam=XSteam('T_ph',Drum.press,Drum.hst*10^-3); %SD steam temp
                        drum_Tsteam(time_run+1)=Drum.temp_steam;
                        Xax.SD_steam=[Xax.SD_steam iter_scf];
                    end

                    if isnan(Drum.press)==1
                        disp('Null element captured in Drum Pressure')
                    end

                    if isnan(Drum.Temp_wat)==1
                        disp('Null elements captured in Drum Water Temperature')     %To check any NAN for Drum water Temperature
                    end

                    %To store the variable wrt time i.e after every 60 sec
                    %drum_hsteam(time_run+1)=Drum.hst;                           %Enthalpy of steam
                    drum_hsteam(time_run+1)=Drum.hst*10^-3;                           %Enthalpy of steam
                    drum_row_st(time_run+1)=Drum.rho_st;                            %Density of steam present in SD     kg/m^3
                    drum_Vsteam(time_run+1)=Drum.Vsteam;                            %NOT USED
                    drum_Mass(time_run+1)=Drum.Mass;                                %Total mass
                    drum_Mass_wat(time_run+1)=Drum.Mass_wat;                        %Mass of water
                    drum_Mass_steam(time_run+1)=Drum.Mass_steam;                    %MAss of steam
                    drum_pressure(time_run+1)=Drum.press;                           %Drum pressure
                    drum_hwat(time_run+1)=Drum.hwat*10^-3;                                %Enthalpy of water
                    drum_Twat(time_run+1)=Drum.Temp_wat;                            %SD water temp
                    %               drum_Tsteam(time_run+1)=Drum.temp_steam;
                    drum_msgen(time_run+1)=Drum.msgen;                              %SD mass of steam generation
                    drum_ms_out40(time_run+1)=Drum.msout;                           %SD mass of steam going out
                    Drum.msout_dear(time_run+1)=Drum.msout_dear(time_run)+(LFR.dt*Drum.msout);
                    waterin_drum(time_run+1)=waterin_drum(time_run)+(LFR.dt*mwin_dear);
                    Steam_Q_drum(time_run+1)=LFRsim.phase;                          %Steam quality
                    Drum.mwin_n(time_run+1)=mwin_dear;                              %The amount of steam produced and going out=Mass of water in from deareator to maintain the water level
                    LFR_temp_fluid(time_run+1)=LFR.Tfluid;                          %LFR.Temp_wat


                    %Energy computation of LFR
                    [Eng_gain_arr_LFR1]=Energy_Compute_LFR(E_lfr_num,time_run);
                    E_lfr_num=E_lfr_num+1;

                    if  IP_mwin_flag==1
                        SD.IP_mwin_time=[SD.IP_mwin_time iter_scf];
                    end
                end

                %
                POW.ms_SG(iter_scf+1)=msgenout;
                POW.LFR(iter_scf+1)=Drum.msout;
                POW.ms_turb(iter_scf+1)=Drum.msout+0;
                POW.Ts_turb(iter_scf+1)=HX.SHintial(2);

                if  Drum.press>SD.press_st                                      %If Drum pressure is > 40bar
                    disp('Drum pressure is greater than setpoint pressure')
                    if HT.Toout >300 || PTC_SCF.Xintial(PTC_scf.grid) >300      %If this condition will not satify then steam will be vented out
                        steamgen_LFR_bef_PTC=1;    %Steam generation will start from LFR before PTC loop i.e SG
                        SH.ODE_bef_PTC=1;
                    end
                end

                %Some time SD pressure(e.g:65 bar) will be way more than SG pressure(e.g: 12
                %bar), and Temp of oil in to SH is very less (e.g: 260 oC), But
                %we need abobe 300 oC. Then Heat the oil loop again to reach
                %the certain temperature, and vent out the SD pressure till
                %temp reach.


                if steamgen_LFR_bef_PTC == 1                                        %IF steam produce from LFR before SG
                    if PTC_HT_OD==1
                        SHLFR.Toilin=HT.Toout;           %HT_OD is connected  else SCF
                    else
                        SHLFR.Toilin=PTC_SCF.Xintial(PTC_scf.grid);                 %SG is connected to Solar field
                    end

                    %                 LFR.Tfluid;
                    %                 SH.Toilin;

                    SH.mixh=(XSteam('hV_T',LFR.Tfluid));
                    SH.moil=HT.moilout;
                    SG.moil=HT.moilout;
                    PH.moil=HT.moilout;

                    %As the oil out temp slightly lower than oil in temp as
                    %well as Temp of steam out from SH slightly should be
                    %greater than Steam in temp due to heat exchange from Oil
                    %to steam.
                    %HX.SHintial=[SH.Toilin-2 LFR.Tfluid+1];                        %Initial Guess Temp of oil out and steam out from SH.
                    %HX.SHintial=[SH.Toilin-2 XSteam('Tsat_p',Drum.press,Drum.hst*10^-3)];
                    HX.SHintial=[SHLFR.Toilin-2 XSteam('T_ph',Drum.press,Drum.hst*10^-3)];

                    if PTC_HT_OD==1                                             %If HT is connected with PTC
                        SH.Toilin=HT.Toout;                                     %Ht oil outlet temp goes into SH oil inlet
                    else
                        SH.Toilin=PTC_SCF.Xintial(PTC_scf.grid);                %Otherwise PTC oil outlet temp goes into SH oil inlet
                    end

                    %Connect SH
                    SH.ODE=1;
                    %[~,sh_tsout]=HXSH(Tspan,HX.SHintial);
                    options(1) = odeset('RelTol',1e-5,'AbsTol',1e-5);
                    [Ts,Y_HXSH]=ode15s(@HXSH_bef_PTC,Tspan,HX.SHintial,options);
                    HX.SHintial=(Y_HXSH(length(Ts),:)');

                    %Power generation
                    POWei.lfr_ms=-0.263+ (0.668*Drum.msout );
                    POWei.lfr_CP=0.4+0.15*4;
                    POWei.lfr_temp=0.125+0.0025*HX.SHintial(2);
                    POWei.lfr_powgen(iter_scf+1)=POWei.lfr_ms*POWei.lfr_CP*POWei.lfr_temp;
                    pow_LFR=POWei.lfr_powgen(iter_scf+1);
                    POWeT.Tot_ms=POWei.lfr_ms;
                    POWeT.CP=POWei.lfr_CP;
                    POWeT.temp=POWei.lfr_temp;
                    POWeT.powgen(iter_scf+1)=POWei.lfr_powgen(iter_scf+1);
                else
                    POWeT.powgen(iter_scf+1)=0;
                end

                if  POWeT.powgen(iter_scf+1) >0
                    POWeT_pos_pow.powgen(xx)=POWeT.powgen(iter_scf+1);
                    xx=xx+1;
                else
                    POWeT_pos_pow.powgen(xx)=0;
                    xx=xx+1;
                end
                Xax.POW=[Xax.POW iter_scf];                                         %Storing iter_scf at Xax.POW

                if length(Xax.POW)~=length(POWeT_pos_pow.powgen)
                    disp('Take pause here')
                end

                %             OP_TTsteam=XSteam('Tsat_p',SG.press_int);
                OP.Tsteam=[OP.Tsteam SG.Twater]; %WHY                                 %Storing OP_TTsteam

                if  msgenout>0
                    HX.mwin= msgenout;
                    SG.mwin=HX.mwin;                                                %Mass of water going in to Sg
                    PH.mwin=HX.mwin;                                                %Mass of water going in to PH
                else
                    HX.mwin=0.5;
                    SG.mwin=HX.mwin;                                                %Mass of water going in to Sg
                    PH.mwin=HX.mwin;                                                %Mass of water going in to PH
                end

                %For storing purpose
                PH.sav_mwin(iter_scf+1)=PH.mwin;                                    %Mass of water in to PH
                SG.sav_mwin(iter_scf+1)=SG.mwin;                                    %Mass of water in to SG
                HX.sav_mwin(iter_scf+1)=HX.mwin;                                    %Mass of water in to HX
                mwin_SD(iter_scf+1)=Dear.mwin;                                      %Mass of water in to SD from Deaerator
                %Twin_SD(iter_scf+1)=Dear.Twin;                                      %Temp of water in to SD from Deaerator      oC
                mwin_LFR_indi(iter_scf+1)=LFR.mw_indi;                              %Mass of water in to individual LFR pipe
                mwin_LFR_total(iter_scf+1)=LFR.total_mw_in;                         %Total Mass of water in to LFR

                %TO compute energy
                [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);
                E_ptc_num=E_ptc_num+1;

                if length(OP.SHU)~=length(Xa.X_SH_U)
                    disp('Length problem SH UAF')
                end

                %For storing purpose
                OP.SCF=[OP.SCF  PTC_SCF.Xintial];                                   %Store PTC temp
                OP.HT_Temp=[OP.HT_Temp HT_out_temp];                                %Store HT temp
                %OP.LT_Temp=[OP.LT_Temp LT.Toout];                                  %Store LT temp
                OP.LT_Temp=[OP.LT_Temp LT_out_temp];

                if SH.ODE==1
                    OP.SH=[OP.SH  HX.SHintial];
                    %                 OP.sh_tsout=[OP.sh_tsout SH.Tsout];             %TO store steam outlet temp of SH
                    OP.sh_tsout=[OP.sh_tsout  HX.SHintial(2)];
                    Xa.X_SH=[Xa.X_SH iter_scf];
                    Tur.msin=[Tur.msin SH.msin];                                    %Mass flow rate of steam out from SH and going in to Turbine
                    if SH.ODE_bef_PTC==1
                        OP.SHuaf=[OP.SHuaf SH.UAF];
                        OP.SHhtube=[OP.SHhtube  SH.htctube];
                        OP.SHhshell=[OP.SHhshell SH.htcshell];
                        OP.SHF=[OP.SHF SH.htcF];
                        OP.SHU=[OP.SHU SH.htcU];
                        Xa.X_SH_U=[Xa.X_SH_U iter_scf];
                    end
                end

                if SG.ODE==1
                    OP.SG_temp=[OP.SG_temp HX.SGintial(1)];
                    OP.SGTw=[ OP.SGTw SG.Twater];
                    XA.X_SG=[XA.X_SG iter_scf];
                    OP.SGmsgen=[OP.SGmsgen SG.msgen];
                    OP.SG_pressure=[OP.SG_pressure HX.SGintial(6)];
                    TW_in_HX=[TW_in_HX HX.Twin];                                       %To store the value of Temp of water in to Heat exchanger
                end

                if SD.ODE==1
                    OP.Drum_Temp_wat=[OP.Drum_Temp_wat Drum.Temp_wat];
                    OP.LFR_Temp=[OP.LFR_Temp LFR.Tfluid];
                    XA.X_SD=[XA.X_SD iter_scf];
                end

                if steam_phase>0
                    Twin_SD=[Twin_SD Dear.Twin];
                    Twin_SD_axis=[Twin_SD_axis iter_scf];
                end


                Xaxis=[Xaxis  iter_scf];
                pow_LFR_arr=[pow_LFR_arr pow_LFR];              %power generation from LFR
                pow_PTC_arr=[pow_PTC_arr pow_PTC];             %power generation from PTC

                if  HX.SGintial(6)>=SG.press_st
                    disp('SG pressure reached 40 bar');
                    pressure_now=HX.SGintial(6)
                    PTC_Fullplant=1;
                    break
                end
                %Height
            end
        end

        timestart=Xaxis(end);
        disp('SG Pressure reached 40bar, Now Full plant will work')

        steamgen_LFR_bef_PTC=0;

        %Saturated vapour enthalpy w.r.t pressure at SG
        SG.hs_steam= XSteam('hV_p',HX.SGintial(6));

        if Drum.press>SD.press_st
            LFR.Tfluid_ph=LFR.Tfluid;
            Drum.Temp_wat1=XSteam('T_ph',Drum.press,Drum.hst*10^-3);
            SG.LFR_Tsout=(SG.Twater+Drum.Temp_wat1)/2;                              %Concider both oil and water side temperature
        else  %Only concider oil side temperature
            LFR.Tfluid_ph=0;
            SG.LFR_Tsout=SG.Twater;
        end

        mix_sh_intial=[0 0];

        LFR_msteam=0;

        HX.Twin=(SG.Twater/250)*75;
        HX.PHintial=[HX.Twin+1 HX.SGintial(1)-1];
        SG.Twin=HX.Twin;

        if SH.ODE==1
            HX.SHintial=[HX.SHintial(1)-2 XSteam('T_ph',Drum.press,Drum.hst*10^-3)];
        else
            HX.SHintial=[SH.Toilin-2 XSteam('T_ph',Drum.press,Drum.hst*10^-3)];
        end
        SH.msin=abs(SG.msgen);%WHY HERE
        %     SH.ODE=1;

        count=0;
        %% Full HSTPP component connected
        while  PTC_Fullplant==1

            for iter_scf=(timestart+1):dt.scf:simu_time_end
                iter_PTC_full=iter_scf;
                iter_PTC_full;
                if iter_scf==32338
                    disp('see')
                end
                %%Oil loop
                PTC_scf.Toilin=LT.Toout;                                            %Output of LT goes into PTC=40 oC, So LT-PTC connected

                if  mod(iter_scf,60)==0                                             %After every 60 sec
                    PTC_scf.I= lfr_I_sec(ip1);
                    Ambient_Temp=Ambient_Temp_ind(ip1);
                    if ip1<length(lfr_I_sec)
                        ip1=ip1+1;
                    else
                        count=1;
                        disp('Taking last ip1 value of "lfr_I_sec" which will go to "PTC_scf.I"')
                    end
                end
                HX.Ambient_Tempr=Ambient_Temp;

                %For storing purpose
                OP.I_solar=[OP.I_solar PTC_scf.I];
                OP.Ambient_T=[OP.Ambient_T Ambient_Temp];
                %% Oil Loop

                %Connect PTC
                Tspan=[0  dt.scf];                      %o to 1 second
                options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                [Ts,Y_SCF]=ode15s(@solarfield,Tspan,PTC_SCF.Xintial,options);       %Integrate PTC tank ODEs
                PTC_SCF.Xintial=(Y_SCF(length(Ts),:)');
                PTC_out_temp=PTC_SCF.Xintial(15)                                    %PTC outlet temp
                if iter_scf==332.08
                    disp('see')
                end
                %need to understand
                if  PTC_SCF.Xintial(PTC_scf.grid) < Temp_set_HT_SH  &&  PTC_HT.Xintial(1) > HT_mass_HTSH  && PTC_LT.Xintial(1) < LT_mass_HTSH_MAX
                    %SP_HT_LT_SH=2;
                    HT.moilout=9;
                else
                    %SP_HT_LT_SH=1;
                    HT.moilout=PTC_scf.moil*3;
                end

                % %TO compute energy for PTC
                % [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);
                % E_ptc_num=E_ptc_num+1;

                %Connect full plant
                [HT_out_temp,LT_out_temp]=PTC_HT_SH_SG_PH_LT_connection(Tspan);


                %% Water Loop

                if mod(iter_scf,LFR.dt)==0 && LFR_n <= runLFR                  %mod(iter_scf,60)=0

                    [time_run]=LFR_sub_fun1(LFR_n);

                    %For storing purpose
                    LFR.IP_mwin=[LFR.IP_mwin LFR.mw_indi];                      %What is the input mass of water going in to LFR, here indi=Invidual pipe

                    % Calling LFRsimulation file
                    [iter]=LFRsimulation(LFR_n);

                    %For storing purpose
                    Xax.LFR=[Xax.LFR iter_scf];


                    if  first_LFR_IC==1                                         %Only for 1st time, after that it reach 2 and Drum.Temp_wat will take
                        first_LFR_IC=first_LFR_IC+1;                            %After 2nd iteration comes it is not needed
                    end

                    %phase 1=Pure steam, phase 0=No steam
                    LFR.msteam_out_indi=LFRsim.phase*LFR.mw_indi;               %Mass of steam out from LFR
                    LFR.msteam_pipeout8=LFR.nos_pipe*LFR.msteam_out_indi;       %Total Mass of steam out from LFR
                    LFR.mwater_out=(1-LFRsim.phase)*LFR.mw_indi;                %Mass of water out from LFR=1*0.3
                    LFR.mwater_pipeout8=LFR.nos_pipe*LFR.mwater_out;            %Total Mass of water from all 8 pipe=8*0.3

                    %For storing purpose: LFr mass of water & steam out at every time instant
                    LFR_mwater_out_nos_pipe(time_run+1)=LFR.mwater_pipeout8;    %Mass of water out from LFR
                    LFR_msteam_out_nos_pipe(time_run+1)=LFR.msteam_pipeout8;    %Mass of steam out from LFR

                    h_out_lfr=LFRsim.h(time_run+1,end);                         %Enthalpy of water out from LFR
                    hwin_drum=h_out_lfr;                                        %Enthalpy of water in to SD
                    LFR.press_end=LFRsim.P(time_run+1,end);                     %LFR end point pressure
                    LFR.Temp_wat=XSteam('T_ph',LFR.press_end,h_out_lfr*10^-3);

                    if LFRsim.phase >0                                          %If there is steam
                        mwin_dear=LFR.msteam_pipeout8;                          %The amount of steam produced and going out=Mass of water in from deareator to maintain the water level
                        Dear.mwin=mwin_dear;                                    %Mass of water in to LFR = Dear mass of water in
                        %Dear.Twin=HX.Twin;                                      %Temp of water in to the hX is same as temp of water from Dear        30 0C
                        %Dear.hwin=XSteam('h_pT',LFR.Press_in,Dear.Twin)*1000;   %Specific enthalpy of water flowing into SD      J/kg
                        steam_phase=1;
                    else                                                        %If there is no steam
                        mwin_dear=0;
                        Dear.mwin=0;
                        %Dear.Twin=0;
                        %Dear.hwin=0;
                    end
                    %Our aim is to generate steam from the LFR not from SD. So to check SD water saturated or not.
                    sat_h_drum=(XSteam('hL_p',Drum.press))*1000;                %Saturated liquid enthalpy of drum from Drum pressure, Water got saturated or not we need


                    %For connecting LFR-SD
                    Drum.mwin=LFR.mwater_pipeout8;                              %SD mass of water in from LFR
                    Drum.mwout=LFR.total_mw_in;                                 %Total mass of water out from SD will go to LFR as input
                    %Drum.hwin=hwin_drum;                                       %Enthalpy of water in to SD
                    Drum.hwin_SD=hwin_drum;                                     %Enthalpy of water in to SD      ?Why this and above line
                    IP_mwin_flag=0;
                    %For storing purpose
                    if Dear.mwin>0
                        SD.IP_mwin=[SD.IP_mwin Dear.mwin];                          %What is the SD mass of water in from LFR
                        IP_mwin_flag=1;
                    end
                    % Connect SD
                    options= odeset('Events',@event_fun_SD);
                    [TS_SD,Y_SD,TE,VE]=ode45(@SD_dynamics_updated_ode,T_SPAN_SD,SD_intial,options);         %Integrate SD dynamics
                    SD_intial=(Y_SD(length(TS_SD),:)');
                    SD.ODE=1;
                    %For storing purpose
                    Yax.press_SD=[Yax.press_SD Drum.press ];                    % Y is for other variable save
                    Xax.SD=[Xax.SD iter_scf];                                   % X is for time axis save
                    OP.SDr=[OP.SDr ;SD_intial'];                                %To save SD initial value for every time instant, it will alwyas update

                    Drum.Mass=SD_intial(1);                                     %Total mass
                    Drum.Mass_wat=SD_intial(2);                                 %Mass of water
                    Drum.Mass_steam=SD_intial(3);                               %MAss of steam
                    Drum.hwat=SD_intial(4);                                     %Enthalpy of water
                    Drum.hst=SD_intial(5);                                      %Enthalpy of steam
                    if test==1
                        Drum.Temp_wat=XSteam('T_ph',LFR.press_end,Drum.hwat*10^-3); %SD water temp
                    else
                        Drum.Temp_wat=XSteam('T_ph',Drum.press,Drum.hwat*10^-3); %SD water temp
                    end
                    if time_run==1
                        drum_Tsteam(1)=100;                                     %100 0C is just a initial drum steam temp guess
                    end
                    if Drum.Mass_steam >0
                        % Drum.temp_steam=XSteam('T_ph',LFR.press_end,Drum.hst*10^-3); %SD steam temp
                        Drum.temp_steam=XSteam('T_ph',Drum.press,Drum.hst*10^-3); %SD steam temp
                        drum_Tsteam(time_run+1)=Drum.temp_steam;
                        Xax.SD_steam=[Xax.SD_steam iter_scf];
                    end

                    %To store the variable wrt time
                    %drum_hsteam(time_run+1)=Drum.hst;                           %Enthalpy of steam
                    drum_hsteam(time_run+1)=Drum.hst*10^-3;                           %Enthalpy of steam
                    drum_row_st(time_run+1)=Drum.rho_st;                        %Density of steam present in SD     kg/m^3
                    drum_Vsteam(time_run+1)=Drum.Vsteam;                        %NOT USED
                    drum_Mass(time_run+1)=Drum.Mass;                            %Total mass
                    drum_Mass_wat(time_run+1)=Drum.Mass_wat;                    %Mass of water
                    drum_Mass_steam(time_run+1)=Drum.Mass_steam;                %Mass of steam out from SD
                    drum_pressure(time_run+1)=Drum.press;                       %Drum pressure=2bar
                    drum_hwat(time_run+1)=Drum.hwat*10^-3;                            %Enthalpy of water
                    drum_Twat(time_run+1)=Drum.Temp_wat;                        %SD water temp
                    %drum_Tsteam(time_run+1)=Drum.temp_steam;
                    drum_msgen(time_run+1)=Drum.msgen;                          %SD mass of steam generation
                    drum_ms_out40(time_run+1)=Drum.msout;                       %SD mass of steam going out
                    Drum.msout_dear(time_run+1)=Drum.msout_dear(time_run)+(LFR.dt*Drum.msout);
                    waterin_drum(time_run+1)=waterin_drum(time_run)+(LFR.dt*mwin_dear);
                    Steam_Q_drum(time_run+1)=LFRsim.phase;                      %Steam quality
                    Drum.mwin_n(time_run+1)=mwin_dear;                          %The amount of steam produced and going out=Mass of water in from deareator to maintain the water level
                    LFR_temp_fluid(time_run+1)=LFR.Tfluid;                      %LFR.Temp_wat

                    %Energy computation of LFR
                    [Eng_gain_arr_LFR1]=Energy_Compute_LFR(E_lfr_num,time_run);
                    E_lfr_num=E_lfr_num+1;

                    if  IP_mwin_flag==1
                        SD.IP_mwin_time=[SD.IP_mwin_time iter_scf];
                    end
                end

                %For storing purpose
                POW.ms_SG(iter_scf+1)=SG.msgen;
                POW.LFR(iter_scf+1)=Drum.msout;
                POW.ms_turb(iter_scf+1)=Drum.msout+SG.msgen;                        %Total Mass flow rate of steam
                POW.Ts_turb(iter_scf+1)=HX.SHintial(2);

                %Power generation   %Taken reference from Desai paper
                POWeT.Tot_ms=-0.263+(0.668*POW.ms_turb(iter_scf+1));
                POWei.oil_ms=-0.263+(0.668*SG.msgen );
                pow_PTC= POWei.oil_ms;                                              %Not used anywhere
                POWeT.CP=0.4+0.15*4;                                                %4 MPa pressure.. 40 bar converted to Mpa
                POWeT.temp=0.125+0.0025*POW.Ts_turb(iter_scf+1);
                POWeT.powgen(iter_scf+1)=POWeT.Tot_ms*POWeT.CP*POWeT.temp;

                if  POWeT.powgen(iter_scf+1) >0
                    POWeT_pos_pow.powgen(xx)=POWeT.powgen(iter_scf+1);
                    xx=xx+1;
                else
                    POWeT_pos_pow.powgen(xx)=0;
                    xx=xx+1;
                end
                Xax.POW=[Xax.POW iter_scf];                                         %Storing iter_scf at Xax.POW

                if length(Xax.POW)~=length(POWeT_pos_pow.powgen)
                    disp('Take pause here')
                end

                if LFRsim.phase >0                                              %If there is steam
                    mwin_dear=LFR.msteam_pipeout8;                              %The amount of steam produced and going out=Mass of water in from deareator to maintain the water level
                    Dear.mwin=mwin_dear;                                        %Mass of water in to LFR = Dear mass of water in
                    Dear.Twin=HX.Twin;                                          %Temp of water in to the hX is same as temp of water from Dear        30 0C
                    Dear.hwin=XSteam('h_pT',LFR.Press_in,Dear.Twin)*1000;       %Specific enthalpy of water flowing into SD      J/kg
                    steam_phase=1;
                else                                                            %If there is no steam
                    mwin_dear=0;
                    Dear.mwin=0;
                    Dear.Twin=HX.Twin;
                    Dear.hwin=0;
                end


                if  msgenout>0
                    HX.mwin= msgenout;
                    SG.mwin=HX.mwin;                                                %Mass of water going in to Sg
                    PH.mwin=HX.mwin;                                                %Mass of water going in to PH
                else
                    HX.mwin=0.5;
                    SG.mwin=HX.mwin;                                                %Mass of water going in to Sg
                    PH.mwin=HX.mwin;                                                %Mass of water going in to PH
                end

                %For stroign purpose
                PH.sav_mwin(iter_scf+1)=PH.mwin;                                %Mass of water in to PH
                SG.sav_mwin(iter_scf+1)=SG.mwin;                                %Mass of water in to SG
                HX.sav_mwin(iter_scf+1)=HX.mwin;                                %Mass of water in to HX
                mwin_SD(iter_scf+1)=Dear.mwin;                                  %Mass of water in to SD from Deaerator
                %Twin_SD(iter_scf+1)=Dear.Twin;                                  %Temp of water in to SD from Deaerator      oC
                mwin_LFR_indi(iter_scf+1)=LFR.mw_indi;                          %Mass of water in to individual LFR pipe
                mwin_LFR_total(iter_scf+1)=LFR.total_mw_in;                     %Total Mass of water in to LFR

                %TO compute energy
                [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);
                E_ptc_num=E_ptc_num+1;



                Xaxis=[Xaxis  iter_scf];
                OP.SCF=[OP.SCF  PTC_SCF.Xintial];                                   %Store PTC temp
                OP.HT_Temp=[OP.HT_Temp HT_out_temp];
                OP.LT_Temp=[OP.LT_Temp LT_out_temp];

                %OP.SCF1=[OP.SCF1  PTC_SCF.Xintial];
                OP.HT=[OP.HT PTC_HT.Xintial];
                OP.LT=[OP.LT PTC_LT.Xintial];
                if SH.ODE==1
                    OP.SH=[OP.SH  HX.SHintial];
                    %                 OP.sh_tsout=[OP.sh_tsout SH.Tsout];             %TO store steam outlet temp of SH
                    OP.sh_tsout=[OP.sh_tsout  HX.SHintial(2)];
                    Xa.X_SH=[Xa.X_SH iter_scf];
                    Tur.msin=[Tur.msin SH.msin];                                    %Mass flow rate of steam out from SH and going in to Turbine
                    %if SH.ODE_bef_PTC==1
                    OP.SHuaf=[OP.SHuaf SH.UAF];
                    OP.SHhtube=[OP.SHhtube  SH.htctube];
                    OP.SHhshell=[OP.SHhshell SH.htcshell];
                    OP.SHF=[OP.SHF SH.htcF];
                    OP.SHU=[OP.SHU SH.htcU];
                    Xa.X_SH_U=[Xa.X_SH_U iter_scf];
                    %end
                end

                if PH.ODE==1
                    OP.PH=[OP.PH  HX.PHintial];
                    OP.ph_twout=[OP.ph_twout PH.Twout];             %TO store water outlet temp of PH
                    Xa.X_PH=[Xa.X_PH iter_scf];
                    %                 ph_twout=[ph_twout PH.Twout];   %To store water outlet temp of PH

                end

                if SG.ODE==1
                    OP.SG_temp=[OP.SG_temp HX.SGintial(1)];
                    OP.SGTw=[OP.SGTw SG.Twater];         %steam or water temp of SG
                    OP.Tsteam=[OP.Tsteam SG.Twater];
                    XA.X_SG=[XA.X_SG iter_scf];
                    OP.SGmsgen=[OP.SGmsgen SG.msgen];
                    OP.SG_pressure=[OP.SG_pressure HX.SGintial(6)];
                    TW_in_HX=[TW_in_HX HX.Twin];                                      %To store the value of Temp of water in to Heat exchanger
                end

                if SD.ODE==1
                    OP.Drum_Temp_wat=[OP.Drum_Temp_wat Drum.Temp_wat];
                    OP.LFR_Temp=[OP.LFR_Temp LFR.Tfluid];
                    XA.X_SD=[XA.X_SD iter_scf];
                end
                if steam_phase>0
                    Twin_SD=[Twin_SD Dear.Twin];
                    Twin_SD_axis=[Twin_SD_axis iter_scf];
                end

                pow_LFR_arr=[pow_LFR_arr pow_LFR];              %power generation from LFR
                pow_PTC_arr=[pow_PTC_arr pow_PTC];             %power generation from PTC

                if length(SD.IP_mwin_time)~=length(SD.IP_mwin)
                    disp('See length')
                end
                %%

                %Condition for Stop the plant for type 0 i.e. for constant solar radiation
                if Type==0
                    if iter_scf>=(simu_time_end-1)%32339 instead of 32399
                        break_time_stop=1;
                        day_count=day_count+1;
                        note_time_day_end=[note_time_day_end iter_scf];
                        note_time_LFR=[note_time_LFR time_run+1];
                        iter_scf_1=iter_scf +4*3600;                            %iter_scf is the just before stop the plant. iter_scf_1 is 4 hrs after the plant stops. (Both in seconds)
                        %                     iter_scf21=ip1+(4*60);                                  %iter_scf21 is basically updated ip1 after 4 hrs. (ip1 updated after every 60 sec)
                        ip2=ip1+(2*60);                                         %ip2 is basically updated ip1 after 4 hrs. (ip1 updated after every 60 sec)
                        simulation_night=1;                                     %Nighttime cooling will start
                        %simulation_next=1;
                        break_time_stop=1;
                        break  %it will jump into 1313
                    end
                else
                    disp('Type')%make no
                end

                %Condition for Stop the plant for other than type 0
                if (PTC_SCF.Xintial(PTC_scf.grid)) < 300 &&  HT.Toout < 300
                    bypass_plant=bypass_plant+1; %Need to understand

                    if  bypass_plant==2
                    end
                    if  bypass_plant >300  %5 min repeated
                        day_count=day_count+1;
                        note_time_day_end=[note_time_day_end iter_scf];
                        note_time_LFR=[note_time_LFR time_run+1];
                        iter_scf_1=(iter_scf+1)+2*3600;                            %iter_scf is the just before stop the plant. iter_scf_1 is 2 hrs after the plant stops. (Both in seconds)
                        ip2=ip1+(2*60);                                         %ip2 is basically updated ip1 after 2 hrs. (ip1 updated after every 60 sec)
                        simulation_night=1;                                     %Nighttime cooling will start
                        break_time_stop=1;
                        break
                    end
                end

            end
            %%
            %Before night time cooling temperature
            Before_Night_time_SG=[Before_Night_time_SG SG.press  SG.Mw  SG.Msteam  SG.Twater];
            Before_Night_time_SD=[Before_Night_time_SD Drum.press Drum.Mass_wat Drum.Mass_steam Drum.Temp_wat  Drum.temp_steam];
            Before_Night_time_Tank=[Before_Night_time_Tank  HT.Toout  LT.Toout];
            Before_Night_time_HX=[Before_Night_time_HX HX.PHintial(2)  HX.SHintial(1)];

            disp('Night time cooling is going to start after Day 1')
            %Night time coolong function call
            [ip3]=Nighttime_cooling(iter_scf_1, ip2, simulation_night, note_time_day_end,note_time_next_start);


            %After night time cooling temperature
            After_Night_time_SG=[After_Night_time_SG SG.press  SG.Mw  SG.Msteam  SG.Twater];
            After_Night_time_SD=[After_Night_time_SD Drum.press Drum.Mass_wat Drum.Mass_steam Drum.Temp_wat  Drum.temp_steam];
            After_Night_time_Tank=[After_Night_time_Tank  HT.Toout  LT.Toout];
            After_Night_time_HX=[After_Night_time_HX HX.PHintial(2)  HX.SHintial(1)];


            %%
            if  break_time_stop==1
                disp('breaktime_stop=1')
                PTC_Fullplant=0;
                break
            end
        end
        %Use to stop the main for loop
        if  break_time_stop==1
            disp('o')
            break
        end
    end
    Simu_time=toc
    
    enthal_LFR=LFRsim.h*10^-3;
    %Time axis converted to Seconds to Hours.
    Xaxis=Xaxis/3600;  %3600 (sec) instant converted to 1 (hr)
    Xa.X_SH=Xa.X_SH/3600;
    Xa.X_SH_U=Xa.X_SH_U/3600;
    XA.X_SG=XA.X_SG/3600;
    Xa.X_PH=Xa.X_PH/3600;


    LFR_time_run=0:1:runLFR;
    time_lfr=(LFR_time_run*LFR.dt)/3600;%in Hr , time_lfr=runLFR
    Xaxis_water=[Xaxis_water Xax.SD/60];
    %Time axis converted to min to Hours.
    Xaxis_water=Xaxis_water/60;
    LFRsim.h=LFRsim.h*10^-3;

    save('Type.mat','Type')

    if Type==0
        save('Day1_over_Const')
    elseif Type==1
        save('Day1_over_Step')
    elseif Type==2
        save('Day1_over_Real')
    elseif Type==3
        save('Day1_over_Quad')
    end


    %% Call function to plot all figures for Day1: COLD START-UP
    Add_path=pwd
    D1=Plot_coldSU(Mode,Add_path);

    disp('Cold startup for hybrid plant i.e. Day 1 over')
    if Type==0
        disp('Cold Startup for Type 0 of the Hybrid plant is over')
    elseif Type==1
        disp('Cold Startup for Type 1 of the Hybrid plant is over')
    elseif Type==2
        disp('Cold Startup for Type 2 of the Hybrid plant is over')
    elseif Type==3
        disp('Cold Startup for Type 3 of the  Hybrid plant is over')
    end

    %*******************************************************************************************************************************************************%
    %*******************************************************************************************************************************************************%
    X=1;
    %%











    %****************************************************************************************************************************************************************%












elseif Startup==2           %For hot startup with predefined coldstartup values

    %% Call function for Day2: HOT START-UP
    Hot_startup=day2(Type);
    %%
    Add_path=pwd
    %Call function to plot all figures for Day2: HOT START-UP
    D2=Plot_hotSU(Mode,Add_path);


    if Type==0
        disp('Hot Startup for Type 0 of the Hybrid plant is over')
    elseif Type==1
        disp('Hot Startup for Type 1 of the Hybrid plant is over')
    elseif Type==2
        disp('Hot Startup for Type 2 of the Hybrid plant is over')
    elseif Type==3
        disp('Hot Startup for Type 3 of the  Hybrid plant is over')
    end

    %cd(Add_path)
    %cd '/home/deep/Dropbox/Mywork/HSTPP/Connection_exp'

    X=1;
    %%












    %****************************************************************************************************************************************************************%















elseif Startup==3                       %Will perform for both Hot and cold strtup

    tic                                 %To see the total time for the simulation
    for i=1:1:leng_I                        %leng_I=2880*60  for 2 days
        while SG.boiling==0                                                         %When there is no boiling happan

            for iter_scf=timestart:dt.scf:simu_time_end                             %0 to simu_time_endtime=hour*3600
                iter_scf_oil_loop=iter_scf                                          %To display the iteration no
                if iter_scf_oil_loop ==4740
                    disp('stop')
                end
                % 1. LT-PTC-LT Connection
                PTC_scf.Toilin=LT.Toout;                                            %Output of LT goes into PTC, So LT-PTC connected

                if  mod(iter_scf,60)==0                                             %After every 60 sec
                    PTC_scf.I= lfr_I_sec(ip1);                                      %ip1 takes 1 solar radiation value at a time and will reamins for 60 sec
                    Ambient_Temp=Ambient_Temp_ind(ip1);                             %Ambient Temperature                oC
                    if ip1<length(lfr_I_sec)                                        %Loop for ip1 does not exceed lfr_I_sec size
                        ip1=ip1+1;
                    else
                        count=1
                    end
                end
                HX.Ambient_Tempr=Ambient_Temp;                                      %HX stands for Heat exchanger

                %For storing purpose
                OP.I_solar=[OP.I_solar PTC_scf.I];                                  %To save the solar radiation
                OP.Ambient_T=[OP.Ambient_T Ambient_Temp];                           %To save the ambient temperature

                %Condition for Bypass HX
                % if  PTC_SCF.Xintial(PTC_scf.grid) < 150                             %Output of PTC oil temp < 150
                if  HT.Toout < 150                                                  %Output of PTC oil temp < 150
                    PTC_HT_LTalone=1;                                               %PTC, HT, LT form route and bypass rest(HX)
                else
                    PTC_HT_LTalone=0;                                               %PTC,HT,LT not alone, HX added
                end

                if PTC_HT_LTalone==1                                                %PTC, HT, LT form route and bypass rest,PTC op temp<150
                    %% Oil loop

                    %Connect PTC
                    Tspan=[0  dt.scf];                                              %o to 1 second
                    options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                    [Ts,Y_SCF]=ode15s(@solarfield,Tspan,PTC_SCF.Xintial,options);   %Integrate PTC tank ODEs
                    PTC_SCF.Xintial=(Y_SCF(length(Ts),:)');
                    PTC_out_temp=PTC_SCF.Xintial(15)                                %PTC outlet temp

                    if (HT.Toout<= PTC_SCF.Xintial(PTC_scf.grid))                   %If 40 oC (HT initial temp) <= Oil output temp of PTC
                        %Connect PTC-HT-LT
                        PTC_HT_OD=1;                                                %Then connect HT with PTC together and LT
                        PTC_LT_OD=0;
                        [HT_out_temp,LT_out_temp]=PTC_HT_LT_connection(Tspan);      %Calling function file with connection of PTC-HT-LT
                    else
                        %Connect PTC-LT
                        PTC_LT_OD=1;                                                %Connect PTC with LT only when HT temp >PTC outlet
                        PTC_HT_OD=0;
                        [LT_out_temp]=PTC_LT_connection(Tspan);                     %%Calling function file with connection of PTC-LT

                    end

                    % %TO compute energy from PTC
                    % [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);              %Function file calling for energy computation from PTC component
                    % E_ptc_num=E_ptc_num+1;                                          %Update step

                    %% Water loop: It should be parallelly run with OIL loop

                    if mod(iter_scf,LFR.dt)==0 && iter_scf~=0                       %mod(iter_scf,60)=0

                        [time_run]=LFR_sub_fun1(LFR_n);                             %LFR Initialization function

                        %For storing purpose
                        LFR.IP_mwin=[LFR.IP_mwin LFR.mw_indi];                      %What is the input mass of water going in to LFR, here indi=Invidual pipe

                        % Calling LFRsimulation file
                        [iter]=LFRsimulation(LFR_n);                                %LFR simulation function file

                        %For storing purpose
                        Xax.LFR=[Xax.LFR iter_scf];                                 %Storing iteration number

                        if  first_LFR_IC==1                                         %Only for 1st time, after that it reach 2 and Drum.Temp_wat will take
                            first_LFR_IC=first_LFR_IC+1;                            %After 2nd iteration comes it is not needed
                        end

                        %phase 1=Pure steam, phase 0=No steam
                        LFR.msteam_out_indi=LFRsim.phase*LFR.mw_indi;               %Mass of steam out from LFR
                        LFR.msteam_pipeout8=LFR.nos_pipe*LFR.msteam_out_indi;       %Total Mass of steam out from LFR
                        LFR.mwater_out=(1-LFRsim.phase)*LFR.mw_indi;                %Mass of water out from LFR=1*0.3
                        LFR.mwater_pipeout8=LFR.nos_pipe*LFR.mwater_out;            %Total Mass of water from all 8 pipe=8*0.3

                        %For storing purpose: LFr mass of water & steam out at every time instant
                        LFR_mwater_out_nos_pipe(time_run+1)=LFR.mwater_pipeout8;    %Mass of water out from LFR
                        LFR_msteam_out_nos_pipe(time_run+1)=LFR.msteam_pipeout8;    %Mass of steam out from LFR

                        h_out_lfr=LFRsim.h(time_run+1,end);                         %Enthalpy of water out from LFR
                        hwin_drum=h_out_lfr;                                        %Enthalpy of water in to SD
                        LFR.press_end=LFRsim.P(time_run+1,end);                     %LFR end point pressure
                        LFR.Temp_wat=XSteam('T_ph',LFR.press_end,h_out_lfr*10^-3);

                        if LFRsim.phase >0                                          %If there is steam
                            mwin_dear=LFR.msteam_pipeout8;                          %The amount of steam produced and going out=Mass of water in from deareator to maintain the water level
                            Dear.mwin=mwin_dear;                                    %Mass of water in to LFR = Dear mass of water in
                            Dear.Twin=HX.Twin;                                      %Temp of water in to the hX is same as temp of water from Dear        30 0C
                            Dear.hwin=XSteam('h_pT',LFR.Press_in,Dear.Twin)*1000;   %Specific enthalpy of water flowing into SD      J/kg
                            steam_phase=1;
                        else                                                        %If there is no steam the values will be zero
                            mwin_dear=0;
                            Dear.mwin=0;
                            Dear.Twin=0;
                            Dear.hwin=0;
                        end
                        %Our aim is to generate steam from the LFR not from SD. So to check SD water saturated or not.
                        sat_h_drum=(XSteam('hL_p',Drum.press))*1000;                %Saturated liquid enthalpy of drum from Drum pressure, Water got saturated or not we need, Here Drum pressure will be initial one i.e. 2bar

                        %For connecting LFR-SD
                        Drum.mwin=LFR.mwater_pipeout8;                              %SD mass of water in from LFR
                        Drum.mwout=LFR.total_mw_in;                                 %Total mass of water out from SD will go to LFR as input         %LFR.total_mw_in=LFR.nos_pipe*LFR.mw_indi;   %2.4 kg/s is coming/8 pipes=1 pipe flow
                        %Drum.hwin=hwin_drum;                                       %Enthalpy of water in to SD
                        Drum.hwin_SD=hwin_drum;                                     %Enthalpy of water in to SD

                        %For storing purpose
                        if Dear.mwin>0
                            SD.IP_mwin=[SD.IP_mwin Dear.mwin];                      %What is the SD mass of water in from LFR
                            IP_mwin_flag=1;
                        end
                        if time_run==1
                            drum_pressure(1)=Drum.press;                            %Drum pressure=1 bar (Initial)
                        end
                        %Connect SD
                        options= odeset('Events',@event_fun_SD);
                        [TS_SD,Y_SD,TE,VE]=ode45(@SD_dynamics_updated_ode,T_SPAN_SD,SD_intial,options);         %Integrate SD dynamics
                        SD_intial=(Y_SD(length(TS_SD),:)');                                                     %Updating step
                        SD.ODE=1;                                                                               %For plotting purpose to match the time axis

                        %For storing purpose
                        Yax.press_SD=[Yax.press_SD Drum.press ];                    %Y is for other variable save
                        Xax.SD=[Xax.SD iter_scf];                                   %X is for time axis save
                        OP.SDr=[OP.SDr ;SD_intial'];                                %To save SD initial value for every time instant, it will alwyas update

                        Drum.Mass=SD_intial(1);                                     %Total mass
                        Drum.Mass_wat=SD_intial(2);                                 %Mass of water
                        Drum.Mass_steam=SD_intial(3);                               %MAss of steam
                        Drum.hwat=SD_intial(4);                                     %Enthalpy of water
                        Drum.hst=SD_intial(5);                                      %Enthalpy of steam

                        if test==1
                            Drum.Temp_wat=XSteam('T_ph',LFR.press_end,Drum.hwat*10^-3); %SD water temp
                        else
                            Drum.Temp_wat=XSteam('T_ph',Drum.press,Drum.hwat*10^-3); %SD water temp
                        end

                        if time_run==1
                            drum_Tsteam(1)=100;                                     %100 0C is just a initial drum steam temp guess
                        end
                        if Drum.Mass_steam >0
                            % Drum.temp_steam=XSteam('T_ph',LFR.press_end,Drum.hst*10^-3); %SD steam temp
                            Drum.temp_steam=XSteam('T_ph',Drum.press,Drum.hst*10^-3); %SD steam temp
                            drum_Tsteam(time_run+1)=Drum.temp_steam;
                            Xax.SD_steam=[Xax.SD_steam iter_scf];
                        end

                        %To store the variable wrt time
                        %drum_hsteam(time_run+1)=Drum.hst;                          %Enthalpy of steam
                        drum_hsteam(time_run+1)=Drum.hst*10^-3;                     %Enthalpy of steam
                        drum_row_st(time_run+1)=Drum.rho_st;                        %Density of steam present in SD     kg/m^3
                        drum_Vsteam(time_run+1)=Drum.Vsteam;                        %NOT USED
                        drum_Mass(time_run+1)=Drum.Mass;                            %Total mass
                        drum_Mass_wat(time_run+1)=Drum.Mass_wat;                    %Mass of water
                        drum_Mass_steam(time_run+1)=Drum.Mass_steam;                %MAss of steam
                        drum_pressure(time_run+1)=Drum.press;                       %Drum pressure
                        drum_hwat(time_run+1)=Drum.hwat*10^-3;                      %Enthalpy of water
                        drum_Twat(time_run+1)=Drum.Temp_wat;                        %SD water temp

                        drum_msgen(time_run+1)=Drum.msgen;                          %SD mass of steam generation
                        drum_ms_out40(time_run+1)=Drum.msout;                       %SD mass of steam going out
                        Drum.msout_dear(time_run+1)=Drum.msout_dear(time_run)+(LFR.dt*Drum.msout);
                        waterin_drum(time_run+1)=waterin_drum(time_run)+(LFR.dt*mwin_dear);%Mass of water in to the drum
                        Steam_Q_drum(time_run+1)=LFRsim.phase;                      %Steam quality
                        Drum.mwin_n(time_run+1)=mwin_dear;                          %The amount of steam produced and going out=Mass of water in from deareator to maintain the water level
                        LFR_temp_fluid(time_run+1)=LFR.Tfluid;%%LFR.Temp_wat        %Output temp of LFR Fluid

                        %Energy computation from LFR
                        [Eng_gain_arr_LFR1]=Energy_Compute_LFR(E_lfr_num,time_run); %Function file calling energy computation from LFR
                        E_lfr_num=E_lfr_num+1;                                      %Update setp

                        POWeT_pos_pow.powgen(xx)=0;
                        xx=xx+1;

                        Xax.POW=[Xax.POW iter_scf];                                     %Storing iter_scf at Xax.POW

                        if  IP_mwin_flag==1
                            SD.IP_mwin_time=[SD.IP_mwin_time iter_scf];
                        end
                    end
                end


                if PTC_HT_LTalone==0                                                %PTC temp>150
                    %% Oil loop

                    %Connect PTC
                    Tspan=[0  dt.scf];                                              %o to 1 second
                    options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                    [Ts,Y_SCF]=ode15s(@solarfield,Tspan,PTC_SCF.Xintial,options);  %Integrate PTC tank ODEs
                    PTC_SCF.Xintial=(Y_SCF(length(Ts),:)');
                    PTC_out_temp=PTC_SCF.Xintial(15)                               %PTC outlet temp

                    %Connect HT with PTC
                    HT.moilin=PTC_scf.moil*3;                                       %Mass of oil out from SCF enters to HT
                    HT.moilout=HT.moilin;                                           %Mass of oil out from HT same as mass of oil in to HT
                    HT.hin=h_oil(PTC_SCF.Xintial(PTC_scf.grid));                    %Enthalpy of oil in to HT

                    if  PTC_HT_OD==1                                                %If HT tank temp <= PTC outlet temp
                        %Connect HT
                        options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                        [Ts,Y_HT]=ode15s(@HTtank,Tspan,PTC_HT.Xintial,options);     %ODE integration of HT
                        PTC_HT.Xintial=(Y_HT(length(Ts),:)');

                        HT.hout=PTC_HT.Xintial(2);                                  %Enthalpy of oil coming out from HT
                        %opts = optimset('TolFun',1e-12,'Display','off') ;
                        %HT.Toout=fsolve('enthal_Temp_HT',HT.Toout,opts);
                        HT.Toout=(-1.49681+sqrt(1.49681^2-4*0.0014*(-18.17454-HT.hout)))/(2*0.0014);   %At current enthalpy HT output temperature
                        HT_out_temp=HT.Toout;                                       %For saving HT outlet Temp
                        %SH.Toilin=HT.Toout;
                        %if HT.Toout>=150
                        %Connect HT with SG_Subcooled
                        SG.moil=HT.moilout;                                         %The mass of oil coming from HT goes into SG
                        SG.Toilin=HT.Toout;                                         %Temp of oil to SG=HT temp of oil out
                        %end
                    else
                        %Connect HT with SG_Subcooled
                        SG.moil=PTC_scf.moil*3;                                     %Mass of oil out from SCF enters to SG (When HT not conected)
                        SG.Toilin=PTC_SCF.Xintial(PTC_scf.grid);                    %Outlet of SCF connected to SG
                    end

                    %At 1 bar saturation enthalpy of water is 417.44 kJ/kg (Check unit)
                    SG.Wsat=XSteam('hL_p',SG.press_int);                            %SG.press_int=1bar pressure at SG, which is saturation pressure of water.
                    check_Wsat_SG=(SG.Wsat-HX.SGintial(5));                         %HX.SGintial(5)=Current enthalpy

                    if  (check_Wsat_SG <=0)                                         %So if saturation enthalpy is zero/-ve then saturation will occure.
                        disp('Saturation occured');
                    else %if HT.Toout>=150
                        %Connect SG_Subcooled: Here SG subcooled means no boiling happan till now, saturation has not occured yet
                        options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                        [Ts,Y_HXSG]=ode15s(@HXSG_subcool,Tspan,HX.SGintial,options);%HXSG_subcool will be connected till SG pressure reach setopint pressure
                        HX.SGintial=(Y_HXSG(length(Ts),:)');
                        SG.ODE=1;
                    end

                    if SG.ODE==1
                        %To store the variables
                        OP.SGuaf=[OP.SGuaf SG.UAF];                                     %To store Final UAF
                        OP.SGhtube=[OP.SGhtube  SG.htctube];                            %To store heat transfer coefficient of tube side
                        OP.SGhshell=[OP.SGhshell SG.htcshell];                          %TO store heat transfer coefficient of shell side
                        OP.SGF=[OP.SGF SG.htcF];                                        %To store correction factor
                        OP.SGU=[OP.SGU SG.htcU];                                        %TO store overall heat transfer coefficient
                    end

                    %Connect LT with SG
                    if SG.ODE==1
                        LT.moilin=SG.moil;                                              %LT mass of oil comes from SG
                    else
                        LT.moilin=HT.moilout;                                                        %Mass of oil out from LT same as mass of oil in to LT
                    end

                    LT.moilout=LT.moilin;
                    if iter_scf==1          %Why
                        LT.hin=h_oil(((HT.Tintial+LT.Tintial)/2)-1);                %Why like this??
                    else
                        LT.hin=h_oil(HX.SGintial(1));                               %Enthalpy of oil in to LT is calculated at SG output temperature.
                    end
                    %X.SGintial(1)=HT.Tintial-1 , why not HTtout
                    options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                    [Ts,Y_LT]=ode15s(@LTtank,Tspan,PTC_LT.Xintial,options);         %Integrating LT tank ODEs
                    PTC_LT.Xintial=(Y_LT(length(Ts),:)');

                    LT.hout=PTC_LT.Xintial(2);                                      %Enthalpy of oil out from LT
                    %opts = optimset('TolFun',1e-12,'Display','off') ;
                    %LT.Toout=fsolve('enthal_Temp_LT',LT.Toout,opts);

                    %Enthalpy polynomial fit equation:
                    %Enthalpy=(0.0014*T^2)+(1.49681*T)-18.17454; (TAken from thermino VP1 pdf file)
                    %Concidering only +ve part
                    LT.Toout=(-1.49681+sqrt(1.49681^2-4*0.0014*(-18.17454-LT.hout)))/(2*0.0014);    %LT outlet temperature
                    LT_out_temp= LT.Toout;                                                          %LT temperature output
                    %                 HX.Toout=LT.Toout;
                    %LT again connected to PTC-
                    PTC_SCF.Xintial(1)=LT.Toout;                                    %LT temperature output is going to PTC inlet
                    %PTC_scf.moil=LT.moilout;

                    % %TO compute energy
                    % [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);              %Function file calling for energy compute from PTC
                    % E_ptc_num=E_ptc_num+1;                                          %Update step

                    %% Water loop: It should be parallelly run with OIL loop

                    if mod(iter_scf,LFR.dt)==0 && iter_scf~=0                       %mod(iter_scf,60)=0

                        [time_run]=LFR_sub_fun1(LFR_n);                             %LFR initialization function file
                        %                     LFR_n=LFR_n+1;                                              %Update step

                        %For storing purpose
                        LFR.IP_mwin=[LFR.IP_mwin LFR.mw_indi];                      %What is the input mass of water going in to LFR, here indi=Invidual pipe

                        % Calling LFRsimulation file
                        [iter]=LFRsimulation(LFR_n);                                %LFR main simulation function file

                        %For storing purpose
                        Xax.LFR=[Xax.LFR iter_scf];                                 %Storing iteration number\
                        if  first_LFR_IC==1                                         %Only for 1st time, after that it reach 2 and Drum.Temp_wat will take
                            first_LFR_IC=first_LFR_IC+1;                            %After 2nd iteration comes it is not needed
                        end

                        %phase 1=Pure steam, phase 0=No steam
                        LFR.msteam_out_indi=LFRsim.phase*LFR.mw_indi;               %Mass of steam out from LFR
                        LFR.msteam_pipeout8=LFR.nos_pipe*LFR.msteam_out_indi;       %Total Mass of steam out from LFR
                        LFR.mwater_out=(1-LFRsim.phase)*LFR.mw_indi;                %Mass of water out from LFR=1*0.3
                        LFR.mwater_pipeout8=LFR.nos_pipe*LFR.mwater_out;            %Total Mass of water from all 8 pipe=8*0.3

                        %For storing purpose: LFr mass of water & steam out at every time instant
                        LFR_mwater_out_nos_pipe(time_run+1)=LFR.mwater_pipeout8;    %Mass of water out from LFR
                        LFR_msteam_out_nos_pipe(time_run+1)=LFR.msteam_pipeout8;    %Mass of steam out from LFR

                        h_out_lfr=LFRsim.h(time_run+1,end);                         %Enthalpy of water out from LFR
                        hwin_drum=h_out_lfr;                                        %Enthalpy of water in to SD
                        LFR.press_end=LFRsim.P(time_run+1,end);                     %LFR end point pressure
                        LFR.Temp_wat=XSteam('T_ph',LFR.press_end,h_out_lfr*10^-3);

                        if LFRsim.phase >0                                          %If there is steam
                            mwin_dear=LFR.msteam_pipeout8;                          %The amount of steam produced and going out=Mass of water in from deareator to maintain the water level
                            Dear.mwin=mwin_dear;                                    %Mass of water in to LFR = Dear mass of water in
                            Dear.Twin=HX.Twin;                                      %Temp of water in to the hX is same as temp of water from Dear        30 0C
                            Dear.hwin=XSteam('h_pT',LFR.Press_in,Dear.Twin)*1000;   %Specific enthalpy of water flowing into SD      J/kg
                            steam_phase=1;
                        else                                                        %If there is no steam
                            mwin_dear=0;
                            Dear.mwin=0;
                            Dear.Twin=0;
                            Dear.hwin=0;
                        end

                        %Our aim is to generate steam from the LFR not from SD. So to check SD water saturated or not.
                        sat_h_drum=(XSteam('hL_p',Drum.press))*1000;                %Saturated liquid enthalpy of drum from Drum pressure, Water got saturated or not we need

                        %For connecting LFR-SD
                        Drum.mwin=LFR.mwater_pipeout8;                              %SD mass of water in from LFR
                        Drum.mwout=LFR.total_mw_in;                                 %Total mass of water out from SD will go to LFR as input
                        %Drum.hwin=hwin_drum;                                       %Enthalpy of water in to SD
                        Drum.hwin_SD=hwin_drum;                                     %Enthalpy of water in to SD      ?Why this and above line

                        %For storing purpose
                        if Dear.mwin>0
                            SD.IP_mwin=[SD.IP_mwin Dear.mwin];                          %What is the SD mass of water in from LFR
                            IP_mwin_flag=1;
                        end

                        % Connect SD
                        options= odeset('Events',@event_fun_SD);
                        [TS_SD,Y_SD,TE,VE]=ode45(@SD_dynamics_updated_ode,T_SPAN_SD,SD_intial,options);         %Integrate SD dynamics
                        SD_intial=(Y_SD(length(TS_SD),:)');
                        SD.ODE=1;
                        %For storing purpose
                        Yax.press_SD=[Yax.press_SD Drum.press ];                    % Y is for other variable save
                        Xax.SD=[Xax.SD iter_scf];                                   % X is for time axis save
                        OP.SDr=[OP.SDr ;SD_intial'];                                %To save SD initial value for every time instant, it will alwyas update

                        Drum.Mass=SD_intial(1);                                     %Total mass
                        Drum.Mass_wat=SD_intial(2);                                 %Mass of water
                        Drum.Mass_steam=SD_intial(3);                               %MAss of steam
                        Drum.hwat=SD_intial(4);                                     %Enthalpy of water
                        Drum.hst=SD_intial(5);                                      %Enthalpy of steam

                        if test==1
                            Drum.Temp_wat=XSteam('T_ph',LFR.press_end,Drum.hwat*10^-3); %SD water temp
                        else
                            Drum.Temp_wat=XSteam('T_ph',Drum.press,Drum.hwat*10^-3); %SD water temp
                        end

                        if time_run==1
                            drum_Tsteam(1)=100;                                     %100 0C is just a initial drum steam temp guess
                        end
                        if Drum.Mass_steam >0
                            % Drum.temp_steam=XSteam('T_ph',LFR.press_end,Drum.hst*10^-3); %SD steam temp
                            Drum.temp_steam=XSteam('T_ph',Drum.press,Drum.hst*10^-3); %SD steam temp
                            drum_Tsteam(time_run+1)=Drum.temp_steam;
                            Xax.SD_steam=[Xax.SD_steam iter_scf];
                        end

                        %To store the variable wrt time
                        %drum_hsteam(time_run+1)=Drum.hst;                           %Enthalpy of steam
                        drum_hsteam(time_run+1)=Drum.hst*10^-3;                           %Enthalpy of steam
                        drum_row_st(time_run+1)=Drum.rho_st;                        %Density of steam present in SD     kg/m^3
                        drum_Vsteam(time_run+1)=Drum.Vsteam;                        %NOT USED
                        drum_Mass(time_run+1)=Drum.Mass;                            %Total mass
                        drum_Mass_wat(time_run+1)=Drum.Mass_wat;                    %Mass of water
                        drum_Mass_steam(time_run+1)=Drum.Mass_steam;                %MAss of steam
                        drum_pressure(time_run+1)=Drum.press;                       %Drum pressure=2bar
                        drum_hwat(time_run+1)=Drum.hwat*10^-3;                            %Enthalpy of water
                        drum_Twat(time_run+1)=Drum.Temp_wat;                        %SD water temp
                        %drum_Tsteam(time_run+1)=Drum.temp_steam;
                        drum_msgen(time_run+1)=Drum.msgen;                          %SD mass of steam generation
                        drum_ms_out40(time_run+1)=Drum.msout;                       %SD mass of steam going out
                        Drum.msout_dear(time_run+1)=Drum.msout_dear(time_run)+(LFR.dt*Drum.msout);
                        waterin_drum(time_run+1)=waterin_drum(time_run)+(LFR.dt*mwin_dear);
                        Steam_Q_drum(time_run+1)=LFRsim.phase;                      %Steam quality
                        Drum.mwin_n(time_run+1)=mwin_dear;                          %The amount of steam produced and going out=Mass of water in from deareator to maintain the water level
                        LFR_temp_fluid(time_run+1)=LFR.Tfluid;                      %LFR output temp of fluid


                        %Energy computation of LFR
                        [Eng_gain_arr_LFR1]=Energy_Compute_LFR(E_lfr_num,time_run); %Function file calling for Energy computation from LFR
                        E_lfr_num=E_lfr_num+1;                                      %Update step

                        %POWeT_pos_pow.powgen(xx)=0;    %?Why
                        %xx=xx+1;
                        if  IP_mwin_flag==1
                            SD.IP_mwin_time=[SD.IP_mwin_time iter_scf];
                        end
                    end

                    %For Storing purpose
                    POW.ms_SG(iter_scf+1)=SG.msgen;                                 %To store the value of SG mass of steam generated
                    POW.LFR(iter_scf+1)=Drum.msout;                                 %To store the value of SG mass of steam generated
                    POW.ms_turb(iter_scf+1)=Drum.msout+0;                           %To store the value of SG mass of steam generated
                    POW.Ts_turb(iter_scf+1)=HX.SHintial(2);                         %To store the value of SG mass of steam generated

                    %With LFR loop need to check SD pressure, if is it=40 bar then
                    %steam generated by SD injected to SH, So SH brough into the picture.

                    if  Drum.press>SD.press_st                                      %If Drum pressure is > 40bar
                        disp('Drum pressure is greater than setpoint pressure')
                        if HT.Toout >300 || PTC_SCF.Xintial(PTC_scf.grid) >300      %If this condition will not satify then steam will be vented out
                            steamgen_LFR_bef_PTC=1;    %Steam generation will start from LFR before PTC loop i.e SG
                            SH.ODE_bef_PTC=1;
                        end
                    end

                    if steamgen_LFR_bef_PTC == 1                                    %IF steam produce from LFR before SG
                        if PTC_HT_OD==1
                            SHLFR.Toilin=HT.Toout;           %HT_OD is connected  else SCF
                        else
                            SHLFR.Toilin=PTC_SCF.Xintial(PTC_scf.grid);                 %SG is connected to Solar field
                        end
                        %HX.SHintial=[SH.Toilin-2 LFR.Tfluid+1];                        %Initial Guess Temp of oil out and steam out from SH.
                        %HX.SHintial=[SH.Toilin-2 XSteam('Tsat_p',Drum.press,Drum.hst*10^-3)];
                        HX.SHintial=[SHLFR.Toilin-2 XSteam('T_ph',Drum.press,Drum.hst*10^-3)];

                        if PTC_HT_OD==1                                             %If HT is connected with PTC
                            SH.Toilin=HT.Toout;                                     %Ht oil outlet temp goes into SH oil inlet
                        else
                            SH.Toilin=PTC_SCF.Xintial(PTC_scf.grid);                %Otherwise PTC oil outlet temp goes into SH oil inlet
                        end

                        %Connect SH
                        SH.ODE=1;                                                   %Used under SH function file
                        options(1) = odeset('RelTol',1e-5,'AbsTol',1e-5);
                        [Ts,Y_HXSH]=ode15s(@HXSH_bef_PTC,Tspan,HX.SHintial);        %Integrate SH which receive steam only from SD
                        HX.SHintial=(Y_HXSH(length(Ts),:)');                        %Update step

                        %Power generation From LFR loop

                        %The power generated from the turbine is computed using Willan's line equation.
                        % here, a,b,c,d,e,f,g,h,i are the turbine parameters. Here, HX.SHintial(2)=Steam out temp from SH

                        POWei.lfr_ms=-0.263+(0.668*Drum.msout);                     %P(MWe), Power generated from the turbine with a=-0.263, b=0.668, c=0        MWe
                        POWei.lfr_CP=0.4+0.15*4;                                    %Xpc, Correction factor for Pressure (Xpc) with d=0.4, e=0.15, c=0, P=4Mpa
                        POWei.lfr_temp=0.125+0.0025*HX.SHintial(2);                 %XTc, Correction factor for Temperature (Xtc) with g=0.125, h=0.0025, i=0
                        POWei.lfr_powgen(iter_scf+1)=POWei.lfr_ms*POWei.lfr_CP*POWei.lfr_temp;      %Actual power(Pact)=P(MWe)*Xpc*XTc

                        pow_LFR=POWei.lfr_powgen(iter_scf+1);
                        POWeT.Tot_ms=POWei.lfr_ms;
                        POWeT.CP=POWei.lfr_CP;
                        POWeT.temp=POWei.lfr_temp;
                        POWeT.powgen(iter_scf+1)=POWei.lfr_powgen(iter_scf+1);
                    else
                        POWeT.powgen(iter_scf+1)=0;
                    end

                    if  POWeT.powgen(iter_scf+1) >0
                        POWeT_pos_pow.powgen(xx)=POWeT.powgen(iter_scf+1);
                        xx=xx+1;
                    else
                        POWeT_pos_pow.powgen(xx)=0;
                        xx=xx+1;
                    end
                    Xax.POW=[Xax.POW iter_scf];                                     %Storing iter_scf at Xax.POW

                    OP_TTsteam=XSteam('Tsat_p',SG.press_int);
                    OP.Tsteam=[OP.Tsteam OP_TTsteam ];                              %Storing OP_TTsteam

                    if  msgenout>0
                        HX.mwin= msgenout;
                        SG.mwin=HX.mwin;                                        %Mass of water going in to Sg
                        PH.mwin=HX.mwin;                                        %Mass of water going in to PH
                    else
                        HX.mwin=0.5;
                        SG.mwin=HX.mwin;                                        %Mass of water going in to Sg
                        PH.mwin=HX.mwin;                                        %Mass of water going in to PH
                    end

                    %For stroign purpose
                    PH.sav_mwin(iter_scf+1)=PH.mwin;                                %Mass of water in to PH
                    SG.sav_mwin(iter_scf+1)=SG.mwin;                                %Mass of water in to SG
                    HX.sav_mwin(iter_scf+1)=HX.mwin;                                %Mass of water in to HX
                    mwin_SD(iter_scf+1)=Dear.mwin;                                  %Mass of water in to SD from Deaerator
                    %Twin_SD(iter_scf+1)=Dear.Twin;                                  %Temp of water in to SD from Deaerator      oC
                    mwin_LFR_indi(iter_scf+1)=LFR.mw_indi;                          %Mass of water in to individual LFR pipe
                    mwin_LFR_total(iter_scf+1)=LFR.total_mw_in;                     %Total Mass of water in to LFR

                end

                %TO compute energy
                [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);
                E_ptc_num=E_ptc_num+1;


                if length(OP.SHU)~=length(Xa.X_SH_U)
                    disp('Length problem SH UAF')
                end
                %FOr storing purpose
                Xaxis=[Xaxis  iter_scf];
                OP.SCF=[OP.SCF  PTC_SCF.Xintial];                                   %Store PTC temp
                OP.HT_Temp=[OP.HT_Temp HT_out_temp];                                %Store HT temp
                %OP.LT_Temp=[OP.LT_Temp LT.Toout];                                  %Store LT temp
                OP.LT_Temp=[OP.LT_Temp LT_out_temp];

                if SH.ODE==1
                    OP.SH=[OP.SH  HX.SHintial];
                    Xa.X_SH=[Xa.X_SH iter_scf];
                    OP.sh_tsout=[OP.sh_tsout  HX.SHintial(2)];        %HX.SHintial(2): Steam out temp
                    Tur.msin=[Tur.msin SH.msin];
                    if SH.ODE_bef_PTC==1
                        OP.SHuaf=[OP.SHuaf SH.UAF];
                        OP.SHhtube=[OP.SHhtube  SH.htctube];
                        OP.SHhshell=[OP.SHhshell SH.htcshell];
                        OP.SHF=[OP.SHF SH.htcF];
                        OP.SHU=[OP.SHU SH.htcU];
                        Xa.X_SH_U=[Xa.X_SH_U iter_scf];
                    end
                end

                if SG.ODE==1
                    OP.SG_temp=[OP.SG_temp HX.SGintial(1)];
                    OP.SGTw=[OP.SGTw SG.Twater];
                    XA.X_SG=[XA.X_SG iter_scf];
                    OP.SGmsgen=[OP.SGmsgen SG.msgen];
                    OP.SG_pressure=[OP.SG_pressure HX.SGintial(6)];
                    TW_in_HX=[TW_in_HX HX.Twin];                                   %To store the value of Temp of water in to Heat exchanger
                end


                if SD.ODE==1
                    OP.Drum_Temp_wat=[OP.Drum_Temp_wat Drum.Temp_wat];
                    OP.LFR_Temp=[OP.LFR_Temp LFR.Tfluid];
                    XA.X_SD=[XA.X_SD iter_scf];
                end
                if steam_phase>0
                    Twin_SD=[Twin_SD Dear.Twin];
                    Twin_SD_axis=[Twin_SD_axis iter_scf];
                end


                pow_LFR_arr=[pow_LFR_arr pow_LFR];              %power generation from LFR
                pow_PTC_arr=[pow_PTC_arr pow_PTC];              %power generation from PTC

                %SG saturtaed enthalpy of water at 1 bar pressure
                SG.Wsat=XSteam('hL_p',SG.press_int);                                %To check saturated liquid enthalpy
                check_Wsat_SG=(SG.Wsat-HX.SGintial(5));
                if  (check_Wsat_SG <=0 )
                    disp('Saturation Occured');
                    HX.SGintial(5)=SG.Wsat; %----correction to have equal value of satu enthalphy  ??
                    SG.boiling=1;
                    break
                end
            end
        end

        timestart=Xaxis(end);
        SG.msgen=0;% intial value
        while (SG.boiling==1  && PTC_Fullplant==0)

            for iter_scf=(timestart+1):dt.scf:simu_time_end
                boil_loop=iter_scf

                %% Oil loop
                % 1. LT-PTC-LT Connection
                PTC_scf.Toilin=LT.Toout;                                            %Output of LT goes into PTC=40 oC, So LT-PTC connected

                if  mod(iter_scf,60)==0                                             %After every 60 sec
                    PTC_scf.I= lfr_I_sec(ip1);
                    Ambient_Temp=Ambient_Temp_ind(ip1);
                    if ip1<length(lfr_I_sec)
                        ip1=ip1+1;
                    else
                        break
                    end
                end
                HX.Ambient_Tempr=Ambient_Temp;

                %For storing purpose
                OP.I_solar=[OP.I_solar PTC_scf.I];
                OP.Ambient_T=[OP.Ambient_T Ambient_Temp];

                %Connect PTC
                Tspan=[0  dt.scf];                      %o to 1 second
                options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                [Ts,Y_SCF]=ode15s(@solarfield,Tspan,PTC_SCF.Xintial,options);       %Integrate PTC tank ODEs
                PTC_SCF.Xintial=(Y_SCF(length(Ts),:)');
                PTC_out_temp=PTC_SCF.Xintial(15)                                    %PTC outlet temp

                %Connect HT with PTC
                HT.moilin=PTC_scf.moil*3;                                           %WHy not given in sir code
                HT.moilout=HT.moilin;
                HT.hin=h_oil(PTC_SCF.Xintial(PTC_scf.grid));

                if PTC_HT_OD==1
                    options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                    [Ts,Y_HT]=ode15s(@HTtank,Tspan,PTC_HT.Xintial,options);
                    PTC_HT.Xintial=(Y_HT(length(Ts),:)');

                    HT.hout=PTC_HT.Xintial(2);
                    opts = optimset('TolFun',1e-12,'Display','off') ;
                    %               HT.Toout=fsolve('enthal_Temp_HT',HT.Toout,opts);
                    HT.Toout=(-1.49681+sqrt(1.49681^2-4*0.0014*(-18.17454-HT.hout)))/(2*0.0014);
                    HT_out_temp=HT.Toout;

                    %Connect HT with SG_Subcooled
                    SG.moil=HT.moilout;
                    SG.Toilin=HT.Toout;                                             %Temp of oil to SG=HT temp of oil out
                else
                    SG.moil=HT.moilout;
                    SG.Toilin=PTC_SCF.Xintial(PTC_scf.grid);
                end
                SG.Wsat=XSteam('hL_p',SG.press_int);
                check_Wsat_SG=(SG.Wsat-HX.SGintial(5));

                if  (check_Wsat_SG <=0)                                         %So if saturation enthalpy is zero/-ve then saturation will occure.
                    disp('Saturation occured');
                end

                SG.hs= XSteam('hV_p',HX.SGintial(6));
                SG.hw=XSteam('hL_p',HX.SGintial(6));

                %Connect SG_Saturated
                options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                [Ts,Y_HXSG]=ode15s(@HXSG_sat,Tspan,HX.SGintial,options);
                HX.SGintial=(Y_HXSG(length(Ts),:)');
                SG_pressure=HX.SGintial(6)
                SG.ODE=1;

                %To check is there any imaginary part
                nedstop=isreal(HX.SGintial );
                if (nedstop)==0   %has img part
                    disp('Imaginary number in HX.SGintial')
                end

                %To store the variables
                OP.SGuaf=[OP.SGuaf SG.UAF];
                OP.SGhtube=[OP.SGhtube  SG.htctube];
                OP.SGhshell=[OP.SGhshell SG.htcshell];
                OP.SGF=[OP.SGF SG.htcF];
                OP.SGU=[OP.SGU SG.htcU];

                %Connect LT with SG
                LT.moilin=SG.moil;  %Not in sir code why
                LT.moilout=LT.moilin;
                %                 if iter_scf==1          %Why
                %                     LT.hin=h_oil(((HT.Tintial+LT.Tintial)/2)-1);
                %                 else
                LT.hin=h_oil(HX.SGintial(1));
                %end

                options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                [Ts,Y_LT]=ode15s(@LTtank,Tspan,PTC_LT.Xintial,options);
                PTC_LT.Xintial=(Y_LT(length(Ts),:)');

                LT.hout=PTC_LT.Xintial(2);
                %opts = optimset('TolFun',1e-12,'Display','off') ;
                %LT.Toout=fsolve('enthal_Temp_LT',LT.Toout,opts);

                %Enthalpy polynomial fit equation:
                %Enthalpy=(0.0014*T^2)+(1.49681*T)-18.17454; (TAken from thermino VP1 pdf file)
                %Concidering only +ve part
                LT.Toout=(-1.49681+sqrt(1.49681^2-4*0.0014*(-18.17454-LT.hout)))/(2*0.0014);
                LT_out_temp=LT.Toout;

                %LT again connected to PTC
                PTC_SCF.Xintial(1)=LT.Toout;
                %PTC_scf.moil=LT.moilout;

                %TO compute energy
                % [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);
                % E_ptc_num=E_ptc_num+1;

                %% Water loop: It should be parallelly run with OIL loop

                if mod(iter_scf,LFR.dt)==0                            %mod(iter_scf,60)=0

                    [time_run]=LFR_sub_fun1(LFR_n);
                    %                 LFR_n=LFR_n+1;

                    %For storing purpose
                    LFR.IP_mwin=[LFR.IP_mwin LFR.mw_indi];                          %What is the input mass of water going in to LFR, here indi=Invidual pipe

                    % Calling LFRsimulation file
                    [iter]=LFRsimulation(LFR_n);

                    %For storing purpose
                    Xax.LFR=[Xax.LFR iter_scf];                                     %Storing iteration number

                    if  first_LFR_IC==1                                             %Only for 1st time, after that it reach 2 and Drum.Temp_wat will take
                        first_LFR_IC=first_LFR_IC+1;                                %After 2nd iteration comes it is not needed
                    end

                    %phase 1=Pure steam, phase 0=No steam
                    LFR.msteam_out_indi=LFRsim.phase*LFR.mw_indi;                   %Mass of steam out from LFR
                    LFR.msteam_pipeout8=LFR.nos_pipe*LFR.msteam_out_indi;           %Total Mass of steam out from LFR
                    LFR.mwater_out=(1-LFRsim.phase)*LFR.mw_indi;                    %Mass of water out from LFR=1*0.3
                    LFR.mwater_pipeout8=LFR.nos_pipe*LFR.mwater_out;                %Total Mass of water from all 8 pipe=8*0.3

                    %For storing purpose: LFr mass of water & steam out at every time instant
                    LFR_mwater_out_nos_pipe(time_run+1)=LFR.mwater_pipeout8;        %Mass of water out from LFR
                    LFR_msteam_out_nos_pipe(time_run+1)=LFR.msteam_pipeout8;        %Mass of steam out from LFR

                    h_out_lfr=LFRsim.h(time_run+1,end);                             %Enthalpy of water out from LFR
                    hwin_drum=h_out_lfr;                                            %Enthalpy of water in to SD
                    LFR.press_end=LFRsim.P(time_run+1,end);                         %LFR end point pressure
                    LFR.Temp_wat=XSteam('T_ph',LFR.press_end,h_out_lfr*10^-3);

                    if LFRsim.phase >0                                              %If there is steam
                        mwin_dear=LFR.msteam_pipeout8;                              %The amount of steam produced and going out=Mass of water in from deareator to maintain the water level
                        Dear.mwin=mwin_dear;                                        %Mass of water in to LFR = Dear mass of water in
                        Dear.Twin=HX.Twin;                                          %Temp of water in to the hX is same as temp of water from Dear        30 0C
                        Dear.hwin=XSteam('h_pT',LFR.Press_in,Dear.Twin)*1000;       %Specific enthalpy of water flowing into SD      J/kg
                        steam_phase=1;
                    else                                                            %If there is no steam
                        mwin_dear=0;
                        Dear.mwin=0;
                        Dear.Twin=0;
                        Dear.hwin=0;
                    end

                    %Our aim is to generate steam from the LFR not from SD. So to check SD water saturated or not.
                    sat_h_drum=(XSteam('hL_p',Drum.press))*1000;                    %Saturated liquid enthalpy of drum from Drum pressure, Water got saturated or not we need

                    if  isnan(Drum.hwat)==1                                         %IF NAN element is there
                        disp('Null elements captured in Drum.hwat')
                    end

                    %For connecting LFR-SD
                    Drum.mwin=LFR.mwater_pipeout8;                                  %SD mass of water in from LFR
                    Drum.mwout=LFR.total_mw_in;                                     %Total mass of water out from SD will go to LFR as input
                    %Drum.hwin=hwin_drum;                                            %Enthalpy of water in to SD
                    Drum.hwin_SD=hwin_drum;                                         %Enthalpy of water in to SD      ?Why this and above line

                    %For storing purpose
                    IP_mwin_flag=0;
                    if Dear.mwin>0
                        SD.IP_mwin=[SD.IP_mwin Dear.mwin];                          %What is the SD mass of water in from LFR
                        IP_mwin_flag=1;
                    end
                    % Connect SD
                    options= odeset('Events',@event_fun_SD);
                    [TS_SD,Y_SD,TE,VE]=ode45(@SD_dynamics_updated_ode,T_SPAN_SD,SD_intial,options);         %Integrate SD dynamics
                    SD_intial=(Y_SD(length(TS_SD),:)');
                    SD.ODE=1;

                    if isnan(Drum.press)==1                                         %To check any NAN for Drum pressure
                        disp('Null elements captured in Drum Pressure')
                    end

                    %For storing purpose
                    Yax.press_SD=[Yax.press_SD Drum.press];                         %To save Drum pressure ... Y is for other variable save
                    Xax.SD=[Xax.SD iter_scf];                                       %X is for time axis save
                    OP.SDr=[OP.SDr ;SD_intial'];                                    %To save SD initial value for every time instant, it will alwyas update

                    Drum.Mass=SD_intial(1);                                         %Total mass
                    Drum.Mass_wat=SD_intial(2);                                     %Mass of water
                    Drum.Mass_steam=SD_intial(3);                                   %MAss of steam
                    Drum.hwat=SD_intial(4);                                         %Enthalpy of water
                    Drum.hst=SD_intial(5);                                          %Enthalpy of steam
                    if test==1
                        Drum.Temp_wat=XSteam('T_ph',LFR.press_end,Drum.hwat*10^-3); %SD water temp
                    else
                        Drum.Temp_wat=XSteam('T_ph',Drum.press,Drum.hwat*10^-3); %SD water temp
                    end

                    if Drum.Mass_steam>0
                        % Drum.temp_steam=XSteam('T_ph',LFR.press_end,Drum.hst*10^-3); %SD steam temp
                        Drum.temp_steam=XSteam('T_ph',Drum.press,Drum.hst*10^-3); %SD steam temp
                        drum_Tsteam(time_run+1)=Drum.temp_steam;
                        Xax.SD_steam=[Xax.SD_steam iter_scf];
                    end

                    if isnan(Drum.press)==1
                        disp('Null element captured in Drum Pressure')
                    end

                    if isnan(Drum.Temp_wat)==1
                        disp('Null elements captured in Drum Water Temperature')     %To check any NAN for Drum water Temperature
                    end

                    %To store the variable wrt time i.e after every 60 sec
                    %drum_hsteam(time_run+1)=Drum.hst;                           %Enthalpy of steam
                    drum_hsteam(time_run+1)=Drum.hst*10^-3;                           %Enthalpy of steam
                    drum_row_st(time_run+1)=Drum.rho_st;                            %Density of steam present in SD     kg/m^3
                    drum_Vsteam(time_run+1)=Drum.Vsteam;                            %NOT USED
                    drum_Mass(time_run+1)=Drum.Mass;                                %Total mass
                    drum_Mass_wat(time_run+1)=Drum.Mass_wat;                        %Mass of water
                    drum_Mass_steam(time_run+1)=Drum.Mass_steam;                    %MAss of steam
                    drum_pressure(time_run+1)=Drum.press;                           %Drum pressure
                    drum_hwat(time_run+1)=Drum.hwat*10^-3;                                %Enthalpy of water
                    drum_Twat(time_run+1)=Drum.Temp_wat;                            %SD water temp
                    %               drum_Tsteam(time_run+1)=Drum.temp_steam;
                    drum_msgen(time_run+1)=Drum.msgen;                              %SD mass of steam generation
                    drum_ms_out40(time_run+1)=Drum.msout;                           %SD mass of steam going out
                    Drum.msout_dear(time_run+1)=Drum.msout_dear(time_run)+(LFR.dt*Drum.msout);
                    waterin_drum(time_run+1)=waterin_drum(time_run)+(LFR.dt*mwin_dear);
                    Steam_Q_drum(time_run+1)=LFRsim.phase;                          %Steam quality
                    Drum.mwin_n(time_run+1)=mwin_dear;                              %The amount of steam produced and going out=Mass of water in from deareator to maintain the water level
                    LFR_temp_fluid(time_run+1)=LFR.Tfluid;                          %LFR.Temp_wat


                    %Energy computation of LFR
                    [Eng_gain_arr_LFR1]=Energy_Compute_LFR(E_lfr_num,time_run);
                    E_lfr_num=E_lfr_num+1;

                    if  IP_mwin_flag==1
                        SD.IP_mwin_time=[SD.IP_mwin_time iter_scf];
                    end
                end

                %
                POW.ms_SG(iter_scf+1)=msgenout;
                POW.LFR(iter_scf+1)=Drum.msout;
                POW.ms_turb(iter_scf+1)=Drum.msout+0;
                POW.Ts_turb(iter_scf+1)=HX.SHintial(2);

                if  Drum.press>SD.press_st                                      %If Drum pressure is > 40bar
                    disp('Drum pressure is greater than setpoint pressure')
                    if HT.Toout >300 || PTC_SCF.Xintial(PTC_scf.grid) >300      %If this condition will not satify then steam will be vented out
                        steamgen_LFR_bef_PTC=1;    %Steam generation will start from LFR before PTC loop i.e SG
                        SH.ODE_bef_PTC=1;
                    end
                end

                %Some time SD pressure(e.g:65 bar) will be way more than SG pressure(e.g: 12
                %bar), and Temp of oil in to SH is very less (e.g: 260 oC), But
                %we need abobe 300 oC. Then Heat the oil loop again to reach
                %the certain temperature, and vent out the SD pressure till
                %temp reach.


                if steamgen_LFR_bef_PTC == 1                                        %IF steam produce from LFR before SG
                    if PTC_HT_OD==1
                        SHLFR.Toilin=HT.Toout;           %HT_OD is connected  else SCF
                    else
                        SHLFR.Toilin=PTC_SCF.Xintial(PTC_scf.grid);                 %SG is connected to Solar field
                    end

                    %                 LFR.Tfluid;
                    %                 SH.Toilin;

                    SH.mixh=(XSteam('hV_T',LFR.Tfluid));
                    SH.moil=HT.moilout;
                    SG.moil=HT.moilout;
                    PH.moil=HT.moilout;

                    %As the oil out temp slightly lower than oil in temp as
                    %well as Temp of steam out from SH slightly should be
                    %greater than Steam in temp due to heat exchange from Oil
                    %to steam.
                    %HX.SHintial=[SH.Toilin-2 LFR.Tfluid+1];                        %Initial Guess Temp of oil out and steam out from SH.
                    %HX.SHintial=[SH.Toilin-2 XSteam('Tsat_p',Drum.press,Drum.hst*10^-3)];
                    HX.SHintial=[SHLFR.Toilin-2 XSteam('T_ph',Drum.press,Drum.hst*10^-3)];

                    if PTC_HT_OD==1                                             %If HT is connected with PTC
                        SH.Toilin=HT.Toout;                                     %Ht oil outlet temp goes into SH oil inlet
                    else
                        SH.Toilin=PTC_SCF.Xintial(PTC_scf.grid);                %Otherwise PTC oil outlet temp goes into SH oil inlet
                    end

                    %Connect SH
                    SH.ODE=1;
                    %[~,sh_tsout]=HXSH(Tspan,HX.SHintial);
                    options(1) = odeset('RelTol',1e-5,'AbsTol',1e-5);
                    [Ts,Y_HXSH]=ode15s(@HXSH_bef_PTC,Tspan,HX.SHintial,options);
                    HX.SHintial=(Y_HXSH(length(Ts),:)');

                    %Power generation
                    POWei.lfr_ms=-0.263+ (0.668*Drum.msout );
                    POWei.lfr_CP=0.4+0.15*4;
                    POWei.lfr_temp=0.125+0.0025*HX.SHintial(2);
                    POWei.lfr_powgen(iter_scf+1)=POWei.lfr_ms*POWei.lfr_CP*POWei.lfr_temp;
                    pow_LFR=POWei.lfr_powgen(iter_scf+1);
                    POWeT.Tot_ms=POWei.lfr_ms;
                    POWeT.CP=POWei.lfr_CP;
                    POWeT.temp=POWei.lfr_temp;
                    POWeT.powgen(iter_scf+1)=POWei.lfr_powgen(iter_scf+1);
                else
                    POWeT.powgen(iter_scf+1)=0;
                end

                if  POWeT.powgen(iter_scf+1) >0
                    POWeT_pos_pow.powgen(xx)=POWeT.powgen(iter_scf+1);
                    xx=xx+1;
                else
                    POWeT_pos_pow.powgen(xx)=0;
                    xx=xx+1;
                end
                Xax.POW=[Xax.POW iter_scf];                                         %Storing iter_scf at Xax.POW

                if length(Xax.POW)~=length(POWeT_pos_pow.powgen)
                    disp('Take pause here')
                end

                %             OP_TTsteam=XSteam('Tsat_p',SG.press_int);
                OP.Tsteam=[OP.Tsteam SG.Twater]; %WHY                                 %Storing OP_TTsteam

                if  msgenout>0
                    HX.mwin= msgenout;
                    SG.mwin=HX.mwin;                                                %Mass of water going in to Sg
                    PH.mwin=HX.mwin;                                                %Mass of water going in to PH
                else
                    HX.mwin=0.5;
                    SG.mwin=HX.mwin;                                                %Mass of water going in to Sg
                    PH.mwin=HX.mwin;                                                %Mass of water going in to PH
                end

                %For storing purpose
                PH.sav_mwin(iter_scf+1)=PH.mwin;                                    %Mass of water in to PH
                SG.sav_mwin(iter_scf+1)=SG.mwin;                                    %Mass of water in to SG
                HX.sav_mwin(iter_scf+1)=HX.mwin;                                    %Mass of water in to HX
                mwin_SD(iter_scf+1)=Dear.mwin;                                      %Mass of water in to SD from Deaerator
                %Twin_SD(iter_scf+1)=Dear.Twin;                                      %Temp of water in to SD from Deaerator      oC
                mwin_LFR_indi(iter_scf+1)=LFR.mw_indi;                              %Mass of water in to individual LFR pipe
                mwin_LFR_total(iter_scf+1)=LFR.total_mw_in;                         %Total Mass of water in to LFR

                %TO compute energy
                [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);
                E_ptc_num=E_ptc_num+1;

                if length(OP.SHU)~=length(Xa.X_SH_U)
                    disp('Length problem SH UAF')
                end

                %For storing purpose
                OP.SCF=[OP.SCF  PTC_SCF.Xintial];                                   %Store PTC temp
                OP.HT_Temp=[OP.HT_Temp HT_out_temp];                                %Store HT temp
                %OP.LT_Temp=[OP.LT_Temp LT.Toout];                                  %Store LT temp
                OP.LT_Temp=[OP.LT_Temp LT_out_temp];

                if SH.ODE==1
                    OP.SH=[OP.SH  HX.SHintial];
                    %                 OP.sh_tsout=[OP.sh_tsout SH.Tsout];             %TO store steam outlet temp of SH
                    OP.sh_tsout=[OP.sh_tsout  HX.SHintial(2)];
                    Xa.X_SH=[Xa.X_SH iter_scf];
                    Tur.msin=[Tur.msin SH.msin];                                    %Mass flow rate of steam out from SH and going in to Turbine
                    if SH.ODE_bef_PTC==1
                        OP.SHuaf=[OP.SHuaf SH.UAF];
                        OP.SHhtube=[OP.SHhtube  SH.htctube];
                        OP.SHhshell=[OP.SHhshell SH.htcshell];
                        OP.SHF=[OP.SHF SH.htcF];
                        OP.SHU=[OP.SHU SH.htcU];
                        Xa.X_SH_U=[Xa.X_SH_U iter_scf];
                    end
                end

                if SG.ODE==1
                    OP.SG_temp=[OP.SG_temp HX.SGintial(1)];
                    OP.SGTw=[ OP.SGTw SG.Twater];
                    XA.X_SG=[XA.X_SG iter_scf];
                    OP.SGmsgen=[OP.SGmsgen SG.msgen];
                    OP.SG_pressure=[OP.SG_pressure HX.SGintial(6)];
                    TW_in_HX=[TW_in_HX HX.Twin];                                       %To store the value of Temp of water in to Heat exchanger
                end

                if SD.ODE==1
                    OP.Drum_Temp_wat=[OP.Drum_Temp_wat Drum.Temp_wat];
                    OP.LFR_Temp=[OP.LFR_Temp LFR.Tfluid];
                    XA.X_SD=[XA.X_SD iter_scf];
                end

                if steam_phase>0
                    Twin_SD=[Twin_SD Dear.Twin];
                    Twin_SD_axis=[Twin_SD_axis iter_scf];
                end


                Xaxis=[Xaxis  iter_scf];
                pow_LFR_arr=[pow_LFR_arr pow_LFR];              %power generation from LFR
                pow_PTC_arr=[pow_PTC_arr pow_PTC];             %power generation from PTC

                if  HX.SGintial(6)>=SG.press_st
                    disp('SG pressure reached 40 bar');
                    pressure_now=HX.SGintial(6)
                    PTC_Fullplant=1;
                    break
                end
                %Height
            end
        end

        timestart=Xaxis(end);
        disp('SG Pressure reached 40bar, Now Full plant will work')

        steamgen_LFR_bef_PTC=0;

        %Saturated vapour enthalpy w.r.t pressure at SG
        SG.hs_steam= XSteam('hV_p',HX.SGintial(6));

        if Drum.press>SD.press_st
            LFR.Tfluid_ph=LFR.Tfluid;
            Drum.Temp_wat1=XSteam('T_ph',Drum.press,Drum.hst*10^-3);
            SG.LFR_Tsout=(SG.Twater+Drum.Temp_wat1)/2;                              %Concider both oil and water side temperature
        else  %Only concider oil side temperature
            LFR.Tfluid_ph=0;
            SG.LFR_Tsout=SG.Twater;
        end

        mix_sh_intial=[0 0];

        LFR_msteam=0;

        HX.Twin=(SG.Twater/250)*75;
        HX.PHintial=[HX.Twin+1 HX.SGintial(1)-1];
        SG.Twin=HX.Twin;

        if SH.ODE==1
            HX.SHintial=[HX.SHintial(1)-2 XSteam('T_ph',Drum.press,Drum.hst*10^-3)];
        else
            HX.SHintial=[SH.Toilin-2 XSteam('T_ph',Drum.press,Drum.hst*10^-3)];
        end
        SH.msin=abs(SG.msgen);%WHY HERE
        %     SH.ODE=1;

        count=0;
        %% Full HSTPP component connected
        while  PTC_Fullplant==1

            for iter_scf=(timestart+1):dt.scf:simu_time_end
                iter_PTC_full=iter_scf;
                iter_PTC_full;
                if iter_scf==32338
                    disp('see')
                end
                %%Oil loop
                PTC_scf.Toilin=LT.Toout;                                            %Output of LT goes into PTC=40 oC, So LT-PTC connected

                if  mod(iter_scf,60)==0                                             %After every 60 sec
                    PTC_scf.I= lfr_I_sec(ip1);
                    Ambient_Temp=Ambient_Temp_ind(ip1);
                    if ip1<length(lfr_I_sec)
                        ip1=ip1+1;
                    else
                        count=1;
                        disp('Taking last ip1 value of "lfr_I_sec" which will go to "PTC_scf.I"')
                    end
                end
                HX.Ambient_Tempr=Ambient_Temp;

                %For storing purpose
                OP.I_solar=[OP.I_solar PTC_scf.I];
                OP.Ambient_T=[OP.Ambient_T Ambient_Temp];
                %% Oil Loop

                %Connect PTC
                Tspan=[0  dt.scf];                      %o to 1 second
                options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                [Ts,Y_SCF]=ode15s(@solarfield,Tspan,PTC_SCF.Xintial,options);       %Integrate PTC tank ODEs
                PTC_SCF.Xintial=(Y_SCF(length(Ts),:)');
                PTC_out_temp=PTC_SCF.Xintial(15)                                    %PTC outlet temp
                if iter_scf==332.08
                    disp('see')
                end
                %need to understand
                if  PTC_SCF.Xintial(PTC_scf.grid) < Temp_set_HT_SH  &&  PTC_HT.Xintial(1) > HT_mass_HTSH  && PTC_LT.Xintial(1) < LT_mass_HTSH_MAX
                    %SP_HT_LT_SH=2;
                    HT.moilout=9;
                else
                    %SP_HT_LT_SH=1;
                    HT.moilout=PTC_scf.moil*3;
                end

                % %TO compute energy for PTC
                % [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);
                % E_ptc_num=E_ptc_num+1;

                %Connect full plant
                [HT_out_temp,LT_out_temp]=PTC_HT_SH_SG_PH_LT_connection(Tspan);


                %% Water Loop

                if mod(iter_scf,LFR.dt)==0 && LFR_n <= runLFR                  %mod(iter_scf,60)=0

                    [time_run]=LFR_sub_fun1(LFR_n);

                    %For storing purpose
                    LFR.IP_mwin=[LFR.IP_mwin LFR.mw_indi];                      %What is the input mass of water going in to LFR, here indi=Invidual pipe

                    % Calling LFRsimulation file
                    [iter]=LFRsimulation(LFR_n);

                    %For storing purpose
                    Xax.LFR=[Xax.LFR iter_scf];


                    if  first_LFR_IC==1                                         %Only for 1st time, after that it reach 2 and Drum.Temp_wat will take
                        first_LFR_IC=first_LFR_IC+1;                            %After 2nd iteration comes it is not needed
                    end

                    %phase 1=Pure steam, phase 0=No steam
                    LFR.msteam_out_indi=LFRsim.phase*LFR.mw_indi;               %Mass of steam out from LFR
                    LFR.msteam_pipeout8=LFR.nos_pipe*LFR.msteam_out_indi;       %Total Mass of steam out from LFR
                    LFR.mwater_out=(1-LFRsim.phase)*LFR.mw_indi;                %Mass of water out from LFR=1*0.3
                    LFR.mwater_pipeout8=LFR.nos_pipe*LFR.mwater_out;            %Total Mass of water from all 8 pipe=8*0.3

                    %For storing purpose: LFr mass of water & steam out at every time instant
                    LFR_mwater_out_nos_pipe(time_run+1)=LFR.mwater_pipeout8;    %Mass of water out from LFR
                    LFR_msteam_out_nos_pipe(time_run+1)=LFR.msteam_pipeout8;    %Mass of steam out from LFR

                    h_out_lfr=LFRsim.h(time_run+1,end);                         %Enthalpy of water out from LFR
                    hwin_drum=h_out_lfr;                                        %Enthalpy of water in to SD
                    LFR.press_end=LFRsim.P(time_run+1,end);                     %LFR end point pressure
                    LFR.Temp_wat=XSteam('T_ph',LFR.press_end,h_out_lfr*10^-3);

                    if LFRsim.phase >0                                          %If there is steam
                        mwin_dear=LFR.msteam_pipeout8;                          %The amount of steam produced and going out=Mass of water in from deareator to maintain the water level
                        Dear.mwin=mwin_dear;                                    %Mass of water in to LFR = Dear mass of water in
                        %Dear.Twin=HX.Twin;                                      %Temp of water in to the hX is same as temp of water from Dear        30 0C
                        %Dear.hwin=XSteam('h_pT',LFR.Press_in,Dear.Twin)*1000;   %Specific enthalpy of water flowing into SD      J/kg
                        steam_phase=1;
                    else                                                        %If there is no steam
                        mwin_dear=0;
                        Dear.mwin=0;
                        %Dear.Twin=0;
                        %Dear.hwin=0;
                    end
                    %Our aim is to generate steam from the LFR not from SD. So to check SD water saturated or not.
                    sat_h_drum=(XSteam('hL_p',Drum.press))*1000;                %Saturated liquid enthalpy of drum from Drum pressure, Water got saturated or not we need


                    %For connecting LFR-SD
                    Drum.mwin=LFR.mwater_pipeout8;                              %SD mass of water in from LFR
                    Drum.mwout=LFR.total_mw_in;                                 %Total mass of water out from SD will go to LFR as input
                    %Drum.hwin=hwin_drum;                                       %Enthalpy of water in to SD
                    Drum.hwin_SD=hwin_drum;                                     %Enthalpy of water in to SD      ?Why this and above line
                    IP_mwin_flag=0;
                    %For storing purpose
                    if Dear.mwin>0
                        SD.IP_mwin=[SD.IP_mwin Dear.mwin];                          %What is the SD mass of water in from LFR
                        IP_mwin_flag=1;
                    end
                    % Connect SD
                    options= odeset('Events',@event_fun_SD);
                    [TS_SD,Y_SD,TE,VE]=ode45(@SD_dynamics_updated_ode,T_SPAN_SD,SD_intial,options);         %Integrate SD dynamics
                    SD_intial=(Y_SD(length(TS_SD),:)');
                    SD.ODE=1;
                    %For storing purpose
                    Yax.press_SD=[Yax.press_SD Drum.press ];                    % Y is for other variable save
                    Xax.SD=[Xax.SD iter_scf];                                   % X is for time axis save
                    OP.SDr=[OP.SDr ;SD_intial'];                                %To save SD initial value for every time instant, it will alwyas update

                    Drum.Mass=SD_intial(1);                                     %Total mass
                    Drum.Mass_wat=SD_intial(2);                                 %Mass of water
                    Drum.Mass_steam=SD_intial(3);                               %MAss of steam
                    Drum.hwat=SD_intial(4);                                     %Enthalpy of water
                    Drum.hst=SD_intial(5);                                      %Enthalpy of steam
                    if test==1
                        Drum.Temp_wat=XSteam('T_ph',LFR.press_end,Drum.hwat*10^-3); %SD water temp
                    else
                        Drum.Temp_wat=XSteam('T_ph',Drum.press,Drum.hwat*10^-3); %SD water temp
                    end
                    if time_run==1
                        drum_Tsteam(1)=100;                                     %100 0C is just a initial drum steam temp guess
                    end
                    if Drum.Mass_steam >0
                        % Drum.temp_steam=XSteam('T_ph',LFR.press_end,Drum.hst*10^-3); %SD steam temp
                        Drum.temp_steam=XSteam('T_ph',Drum.press,Drum.hst*10^-3); %SD steam temp
                        drum_Tsteam(time_run+1)=Drum.temp_steam;
                        Xax.SD_steam=[Xax.SD_steam iter_scf];
                    end

                    %To store the variable wrt time
                    %drum_hsteam(time_run+1)=Drum.hst;                           %Enthalpy of steam
                    drum_hsteam(time_run+1)=Drum.hst*10^-3;                           %Enthalpy of steam
                    drum_row_st(time_run+1)=Drum.rho_st;                        %Density of steam present in SD     kg/m^3
                    drum_Vsteam(time_run+1)=Drum.Vsteam;                        %NOT USED
                    drum_Mass(time_run+1)=Drum.Mass;                            %Total mass
                    drum_Mass_wat(time_run+1)=Drum.Mass_wat;                    %Mass of water
                    drum_Mass_steam(time_run+1)=Drum.Mass_steam;                %Mass of steam out from SD
                    drum_pressure(time_run+1)=Drum.press;                       %Drum pressure=2bar
                    drum_hwat(time_run+1)=Drum.hwat*10^-3;                            %Enthalpy of water
                    drum_Twat(time_run+1)=Drum.Temp_wat;                        %SD water temp
                    %drum_Tsteam(time_run+1)=Drum.temp_steam;
                    drum_msgen(time_run+1)=Drum.msgen;                          %SD mass of steam generation
                    drum_ms_out40(time_run+1)=Drum.msout;                       %SD mass of steam going out
                    Drum.msout_dear(time_run+1)=Drum.msout_dear(time_run)+(LFR.dt*Drum.msout);
                    waterin_drum(time_run+1)=waterin_drum(time_run)+(LFR.dt*mwin_dear);
                    Steam_Q_drum(time_run+1)=LFRsim.phase;                      %Steam quality
                    Drum.mwin_n(time_run+1)=mwin_dear;                          %The amount of steam produced and going out=Mass of water in from deareator to maintain the water level
                    LFR_temp_fluid(time_run+1)=LFR.Tfluid;                      %LFR.Temp_wat

                    %Energy computation of LFR
                    [Eng_gain_arr_LFR1]=Energy_Compute_LFR(E_lfr_num,time_run);
                    E_lfr_num=E_lfr_num+1;

                    if  IP_mwin_flag==1
                        SD.IP_mwin_time=[SD.IP_mwin_time iter_scf];
                    end
                end

                %For storing purpose
                POW.ms_SG(iter_scf+1)=SG.msgen;
                POW.LFR(iter_scf+1)=Drum.msout;
                POW.ms_turb(iter_scf+1)=Drum.msout+SG.msgen;                        %Total Mass flow rate of steam
                POW.Ts_turb(iter_scf+1)=HX.SHintial(2);

                %Power generation   %Taken reference from Desai paper
                POWeT.Tot_ms=-0.263+(0.668*POW.ms_turb(iter_scf+1));
                POWei.oil_ms=-0.263+(0.668*SG.msgen );
                pow_PTC= POWei.oil_ms;                                              %Not used anywhere
                POWeT.CP=0.4+0.15*4;                                                %4 MPa pressure.. 40 bar converted to Mpa
                POWeT.temp=0.125+0.0025*POW.Ts_turb(iter_scf+1);
                POWeT.powgen(iter_scf+1)=POWeT.Tot_ms*POWeT.CP*POWeT.temp;

                if  POWeT.powgen(iter_scf+1) >0
                    POWeT_pos_pow.powgen(xx)=POWeT.powgen(iter_scf+1);
                    xx=xx+1;
                else
                    POWeT_pos_pow.powgen(xx)=0;
                    xx=xx+1;
                end
                Xax.POW=[Xax.POW iter_scf];                                         %Storing iter_scf at Xax.POW

                if length(Xax.POW)~=length(POWeT_pos_pow.powgen)
                    disp('Take pause here')
                end

                if LFRsim.phase >0                                              %If there is steam
                    mwin_dear=LFR.msteam_pipeout8;                              %The amount of steam produced and going out=Mass of water in from deareator to maintain the water level
                    Dear.mwin=mwin_dear;                                        %Mass of water in to LFR = Dear mass of water in
                    Dear.Twin=HX.Twin;                                          %Temp of water in to the hX is same as temp of water from Dear        30 0C
                    Dear.hwin=XSteam('h_pT',LFR.Press_in,Dear.Twin)*1000;       %Specific enthalpy of water flowing into SD      J/kg
                    steam_phase=1;
                else                                                            %If there is no steam
                    mwin_dear=0;
                    Dear.mwin=0;
                    Dear.Twin=HX.Twin;
                    Dear.hwin=0;
                end


                if  msgenout>0
                    HX.mwin= msgenout;
                    SG.mwin=HX.mwin;                                                %Mass of water going in to Sg
                    PH.mwin=HX.mwin;                                                %Mass of water going in to PH
                else
                    HX.mwin=0.5;
                    SG.mwin=HX.mwin;                                                %Mass of water going in to Sg
                    PH.mwin=HX.mwin;                                                %Mass of water going in to PH
                end

                %For stroign purpose
                PH.sav_mwin(iter_scf+1)=PH.mwin;                                %Mass of water in to PH
                SG.sav_mwin(iter_scf+1)=SG.mwin;                                %Mass of water in to SG
                HX.sav_mwin(iter_scf+1)=HX.mwin;                                %Mass of water in to HX
                mwin_SD(iter_scf+1)=Dear.mwin;                                  %Mass of water in to SD from Deaerator
                %Twin_SD(iter_scf+1)=Dear.Twin;                                  %Temp of water in to SD from Deaerator      oC
                mwin_LFR_indi(iter_scf+1)=LFR.mw_indi;                          %Mass of water in to individual LFR pipe
                mwin_LFR_total(iter_scf+1)=LFR.total_mw_in;                     %Total Mass of water in to LFR

                %TO compute energy
                [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);
                E_ptc_num=E_ptc_num+1;

                Xaxis=[Xaxis  iter_scf];
                OP.SCF=[OP.SCF  PTC_SCF.Xintial];                                   %Store PTC temp
                OP.HT_Temp=[OP.HT_Temp HT_out_temp];
                OP.LT_Temp=[OP.LT_Temp LT_out_temp];

                %OP.SCF1=[OP.SCF1  PTC_SCF.Xintial];
                OP.HT=[OP.HT PTC_HT.Xintial];
                OP.LT=[OP.LT PTC_LT.Xintial];
                if SH.ODE==1
                    OP.SH=[OP.SH  HX.SHintial];
                    %                 OP.sh_tsout=[OP.sh_tsout SH.Tsout];             %TO store steam outlet temp of SH
                    OP.sh_tsout=[OP.sh_tsout  HX.SHintial(2)];
                    Xa.X_SH=[Xa.X_SH iter_scf];
                    Tur.msin=[Tur.msin SH.msin];                                    %Mass flow rate of steam out from SH and going in to Turbine
                    %if SH.ODE_bef_PTC==1
                    OP.SHuaf=[OP.SHuaf SH.UAF];
                    OP.SHhtube=[OP.SHhtube  SH.htctube];
                    OP.SHhshell=[OP.SHhshell SH.htcshell];
                    OP.SHF=[OP.SHF SH.htcF];
                    OP.SHU=[OP.SHU SH.htcU];
                    Xa.X_SH_U=[Xa.X_SH_U iter_scf];
                    %end
                end

                if PH.ODE==1
                    OP.PH=[OP.PH  HX.PHintial];
                    OP.ph_twout=[OP.ph_twout PH.Twout];             %TO store water outlet temp of PH
                    Xa.X_PH=[Xa.X_PH iter_scf];
                    %                 ph_twout=[ph_twout PH.Twout];   %To store water outlet temp of PH

                end

                if SG.ODE==1
                    OP.SG_temp=[OP.SG_temp HX.SGintial(1)];
                    OP.SGTw=[OP.SGTw SG.Twater];         %steam or water temp of SG
                    OP.Tsteam=[OP.Tsteam SG.Twater];
                    XA.X_SG=[XA.X_SG iter_scf];
                    OP.SGmsgen=[OP.SGmsgen SG.msgen];
                    OP.SG_pressure=[OP.SG_pressure HX.SGintial(6)];
                    TW_in_HX=[TW_in_HX HX.Twin];                                      %To store the value of Temp of water in to Heat exchanger
                end

                if SD.ODE==1
                    OP.Drum_Temp_wat=[OP.Drum_Temp_wat Drum.Temp_wat];
                    OP.LFR_Temp=[OP.LFR_Temp LFR.Tfluid];
                    XA.X_SD=[XA.X_SD iter_scf];
                end
                if steam_phase>0
                    Twin_SD=[Twin_SD Dear.Twin];
                    Twin_SD_axis=[Twin_SD_axis iter_scf];
                end

                pow_LFR_arr=[pow_LFR_arr pow_LFR];              %power generation from LFR
                pow_PTC_arr=[pow_PTC_arr pow_PTC];             %power generation from PTC

                if length(SD.IP_mwin_time)~=length(SD.IP_mwin)
                    disp('See length')
                end
                %%

                %Condition for Stop the plant for type 0 i.e. for constant solar radiation
                if Type==0
                    if iter_scf>=(simu_time_end-1)%32339 instead of 32399
                        break_time_stop=1;
                        day_count=day_count+1;
                        note_time_day_end=[note_time_day_end iter_scf];
                        note_time_LFR=[note_time_LFR time_run+1];
                        iter_scf_1=iter_scf +4*3600;                            %iter_scf is the just before stop the plant. iter_scf_1 is 4 hrs after the plant stops. (Both in seconds)
                        %                     iter_scf21=ip1+(4*60);                                  %iter_scf21 is basically updated ip1 after 4 hrs. (ip1 updated after every 60 sec)
                        ip2=ip1+(2*60);                                         %ip2 is basically updated ip1 after 4 hrs. (ip1 updated after every 60 sec)
                        simulation_night=1;                                     %Nighttime cooling will start
                        %simulation_next=1;
                        break_time_stop=1;
                        break  %it will jump into 1313
                    end
                else
                    disp('Type')%make no
                end

                %Condition for Stop the plant for other than type 0
                if (PTC_SCF.Xintial(PTC_scf.grid)) < 300 &&  HT.Toout < 300
                    bypass_plant=bypass_plant+1; %Need to understand

                    if  bypass_plant==2
                    end
                    if  bypass_plant >300  %5 min repeated
                        day_count=day_count+1;
                        note_time_day_end=[note_time_day_end iter_scf];
                        note_time_LFR=[note_time_LFR time_run+1];
                        iter_scf_1=(iter_scf+1)+2*3600;                            %iter_scf is the just before stop the plant. iter_scf_1 is 2 hrs after the plant stops. (Both in seconds)
                        ip2=ip1+(2*60);                                         %ip2 is basically updated ip1 after 2 hrs. (ip1 updated after every 60 sec)
                        simulation_night=1;                                     %Nighttime cooling will start
                        break_time_stop=1;
                        break
                    end
                end

            end
            %%
            %Before night time cooling temperature
            Before_Night_time_SG=[Before_Night_time_SG SG.press  SG.Mw  SG.Msteam  SG.Twater];
            Before_Night_time_SD=[Before_Night_time_SD Drum.press Drum.Mass_wat Drum.Mass_steam Drum.Temp_wat  Drum.temp_steam];
            Before_Night_time_Tank=[Before_Night_time_Tank  HT.Toout  LT.Toout];
            Before_Night_time_HX=[Before_Night_time_HX HX.PHintial(2)  HX.SHintial(1)];

            disp('Night time cooling is going to start after Day 1')
            %Night time coolong function call
            [ip3]=Nighttime_cooling(iter_scf_1, ip2, simulation_night, note_time_day_end,note_time_next_start);


            %After night time cooling temperature
            After_Night_time_SG=[After_Night_time_SG SG.press  SG.Mw  SG.Msteam  SG.Twater];
            After_Night_time_SD=[After_Night_time_SD Drum.press Drum.Mass_wat Drum.Mass_steam Drum.Temp_wat  Drum.temp_steam];
            After_Night_time_Tank=[After_Night_time_Tank  HT.Toout  LT.Toout];
            After_Night_time_HX=[After_Night_time_HX HX.PHintial(2)  HX.SHintial(1)];


            %%
            if  break_time_stop==1
                disp('breaktime_stop=1')
                PTC_Fullplant=0;
                break
            end
        end
        %Use to stop the main for loop
        if  break_time_stop==1
            disp('o')
            break
        end
    end
    Simu_time=toc

    enthal_LFR=LFRsim.h*10^-3;
    %Time axis converted to Seconds to Hours.
    Xaxis=Xaxis/3600;  %3600 (sec) instant converted to 1 (hr)
    Xa.X_SH=Xa.X_SH/3600;
    Xa.X_SH_U=Xa.X_SH_U/3600;
    XA.X_SG=XA.X_SG/3600;
    Xa.X_PH=Xa.X_PH/3600;


    LFR_time_run=0:1:runLFR;
    time_lfr=(LFR_time_run*LFR.dt)/3600;%in Hr , time_lfr=runLFR
    Xaxis_water=[Xaxis_water Xax.SD/60];
    %Time axis converted to min to Hours.
    Xaxis_water=Xaxis_water/60;
    LFRsim.h=LFRsim.h*10^-3;

    save('Type.mat','Type')

    if Type==0
        save('Day1_over_Const')
    elseif Type==1
        save('Day1_over_Step')
    elseif Type==2
        save('Day1_over_Real')
    elseif Type==3
        save('Day1_over_Quad')
    end


    %% Call function to plot all figures for Day1: COLD START-UP
    Add_path=pwd
    D1=Plot_coldSU(Mode,Add_path);

    disp('Day 1 for hybrid plant is over')
    %*******************************************************************************************************************************************************%
    %*******************************************************************************************************************************************************%
    %%

    %cd(Add_path)
    % cd '/home/deep/Dropbox/Mywork/HSTPP/Connection_exp'

    % Call function for Day2: HOT START-UP
    Hot_startup=day2(Type);
    %
    %Call function to plot all figures for Day2: HOT START-UP
    Add_path=pwd
    D2=Plot_hotSU(Mode,Add_path);

    if Type==0
        disp('Cold+Hot Startup for Type 0 of the Hybrid plant is over')
    elseif Type==1
        disp('Cold+Hot Startup for Type 1 of the Hybrid plant is over')
    elseif Type==2
        disp('Cold+Hot Startup for Type 2 of the Hybrid plant is over')
    elseif Type==3
        disp('Cold+Hot Startup for Type 3 of the Hybrid plant is over')
    end


    %cd '/home/deep/Dropbox/Mywork/HSTPP/Connection_exp'

    X=1;

end
end