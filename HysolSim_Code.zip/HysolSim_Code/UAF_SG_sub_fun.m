%% Steam generator HTC: Subcooled condition
%For calculation of U we need two HTC,one is shell side another is tube side.
%_she=Shell side
%_t= tuibe side

function[ UAF,hi_t_turb,hb_sg,F,U]=UAF_SG_sub_fun(mo,Toi,Too,mw,Twi,Two,Press)

global SG
global Nu Ther mws dyn_vis Cphx hb_sg
global den_t cp_t Kvis_t Therm_t dyn_vis_t f_t Ren_t moi NUs_t 
SG.press=Press;             %SG pressure
To_av=(Toi+Too)/2;          %Avg oil temperature=(Temp of Oil coming out from SG+Temp of Oil from coming out from SG)/2
T_shell=(Twi+Two)/2;        %Avg water temperature=(Temp of water coming in+Temp of water in SG)/2
g=9.8;                      %Gravity
Nt=SG.No_tubes;             %No of tubes=75
Di_t=SG.tube_Id ;           %Tube input diameter
ri_t=SG.tube_Id/2;          %Tube input radius
Do_t=SG.tube_OD;            %Tube output diameter
ro_t=SG.tube_OD/2;          %Tube outer radius
nopass_t=2;                 %No of passes
L_t=SG.tube_length;         %Tube length
Area=pi*Do_t*L_t*(Nt*2);    %Area of heat transfer    m^2
Therma=49;                  %Thermal conductivity
Ds_s=SG.shell_ID_cyl;       %%Shell side inner diameter=1.2  m


%% Shell side HTC calculation

% den_s=XSteam('rho_pT',SG.press,T_shell);
% sur_s= XSteam('st_p',SG.press);
% row_l_s=XSteam('rhoL_p',SG.press);
% row_v_s=XSteam('rhoV_p',SG.press);
% latent_s=(XSteam('hV_p',SG.press))-(XSteam('hL_p',SG.press));
% latent_s=latent_s*1000;

dyn_vis_s=XSteam('my_pT',SG.press, T_shell);        %my_pT	Viscosity as a function of pressure and temperature.
Ther_s=XSteam('tcL_p',SG.press);                    %tcL_p	Saturated vapour thermal conductivity
Tsat_su=XSteam('Tsat_p',SG.press);                  %Tsat_p	Saturation temperature

if Two <=Tsat_su
    Cphx=XSteam('CpL_p',SG.press)*1000;             %CpL_p	Saturated liquid heat capacity 
else
    Cphx=XSteam('Cp_pT',SG.press,T_shell)*1000;     %Cp_pT	Specific isobaric heat capacity as a function of pressure and temperature.
end

if isnan(Cphx)==1
    Cphx=XSteam('CpL_p',SG.press)*1000;             %CpL_p	Saturated liquid heat capacity 
end

if  isnan(Ther_s)==1
    Ther_s=XSteam('tcL_p',SG.press);                %tcL_p	Saturated vapour thermal conductivity 
end
 Ther=Ther_s;
% if isnan(den_s)==1
%     den_s=XSteam('rhoL_p',SG.press);
% end

if isnan(dyn_vis_s)==1
    vis_L=h2o_muf(SG.press*100);
    %vis_g=h2o_mug(SG.press*100);
    dyn_vis_s=vis_L;
    
end
dyn_vis=dyn_vis_s;
Pt=0.0368;                                               %Pitch/square

%1. Kern method
Cl=Pt-SG.tube_OD;
B=SG.shell_ID_cyl/5;                                     %Baffle spacing: Minimum baffle spacing should be one fifth of the Shell Internal Diameter (ID) OR 2 inch, whichever is greater
As=(Ds_s*Cl*B)/Pt;
Gs=mw/As;  
mws=mw;
De=(4*((Pt^2)-((pi*Do_t^2)/4)))/(pi*Do_t);
Res=(De*Gs)/dyn_vis_s;                                   %Reynold no
Nu=0.36*(Res^0.55)*(((Cphx*dyn_vis_s)/Ther_s)^0.33);     %Nussult no shell side
hb_sg=(Nu*Ther_s)/De;                                    %Shell side HTC

%% Tube side HTC calculation
%TUBE side LAMINAR flow

den_t=density_oil(To_av);       %Density of oil
cp_t=Cp_sf(To_av);              %Sp. Heat capacity
Kvis_t=Kin_vis(To_av);          %Kinematic viscocity
Therm_t=Ther_con(To_av);        %Thermal conductivity
dyn_vis_t= (Kvis_t *den_t);     %Dynamic viscosity

At_t=(pi*(Di_t^2))/4;           %Area of tube side
Atp_t=(Nt*At_t)/nopass_t;
Gt_t=(mo/Atp_t);                %Mass velocity of tube=Mass flow rate of water in/Atp
Ut_t=Gt_t/den_t;                %Velocity
Ren_t=(Ut_t*den_t*Di_t)/dyn_vis_t;      %Reynolds number on tube side
Pr_t=(cp_t*dyn_vis_t)/Therm_t;          %Prandtl number=(Sp. Heat capacity*Dynamic viscosity)/Thermal conductivity
moi=mo;
%TUBE side TURBULENT flow
f_t=(1.58*log(Ren_t)-3.28)^-2;                                                  %f=Friction factor
NUs_t=((f_t/2)*Ren_t*Pr_t)/(1.07+(12.7*((f_t/2)^(1/2)))*((Pr_t^(2/3))-1));      %Nusselt number
hi_t_turb=(NUs_t*Therm_t)/Di_t;                                                 %Tube side HTC

%% Overall HTC calculation by Delaware method
U=( (ro_t/ri_t)*(1/hi_t_turb) )+(1/ hb_sg)+((ro_t*log(ro_t/ri_t))/(Therma));
U=1/U;

if isreal(U)~=1
    hi_t_turb
    hb_sg
    disp('Shell/Tube side HTC is imag for SG');
    pause
end

%% Correction factor of SG
Rr=(Toi-Too)/(Two-Twi);     %Range on shell side temperature/Range on tube side temperature
Ss=(Two-Twi)/(Toi-Twi);     %Range on tube side temerature/Maximum temperature diff on HX

num_F=(sqrt((Rr^2)+1))*log((1-Ss)/(1-(Rr*Ss))); %Numerator of correction factor

F_d1= 2- (Ss*(Rr+1- (sqrt(Rr^2+1))) );
F_d2= 2- (Ss*(Rr+1+ (sqrt(Rr^2+1))) );
Deno_F=(Rr-1) *log(F_d1/F_d2);      %Denominator of correction factor

F=num_F/Deno_F;                     %Correction factor

%% Final UAF
UAF=U*Area*F;
UAF=UAF*10^-3;
end
