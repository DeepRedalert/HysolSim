
% This file sets parameters of graphics 

set(0,'DefaultLineLineWidth', 5)           % Set Line thickness 
set(0,'DefaultaxesLineWidth', 5)          %  Set Axes thickness
set(0,'DefaultLineMarkerSize',10)        %  Set Marker size 

%  Set font size and type 

set(0,'DefaultaxesFontSize', 25)           
set(0,'DefaultTextFontSize', 25) 
set(0,'DefaultaxesFontName', 'arial') 

