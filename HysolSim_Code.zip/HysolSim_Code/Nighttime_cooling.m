%Function for Night time cooling

function [ip3]=Nighttime_cooling(iter_scf_1,ip2,simulation_night,note_time_day_end,note_time_next_start)

global lfr_I_sec SG Drum iter_scf HX SD HT LT U OP
global SG_MW  SG_MS  shut_cou_sg SD_m_cond_arr SD_night_arr SD_MW SD_MS shut_cou_sd
global shut_HT shut_LT shut_PH shut_SH shut_SG shut_SD SG_night SD_night
global PTC_HT PTC_LT PH SH break_time timestart break_time_stop dhst_n Type

while simulation_night==1


    %For connection time
    stop_time1=note_time_next_start(end)-note_time_day_end(end);

    %iter_scf_1 is 4 hrs after the plant stops. (In seconds) : Needed
    %because lfr_I_sec may have the value >250 yet. So first try to settle
    %down the solar radiation.
    %iter_scf21 is basically updated ip1 after 4 hrs. (ip1 updated after every 60 sec)

    %To check again the time, when solar radiation is graeter than 250 oC
    for iter_scf_2=iter_scf_1:1:iter_scf_1+(16*3600)     %4 hrs after the plant stops to next 16 hrs (If plant stops at 4.30 PM then this loop will run till 8.30 AM)
    %for iter_scf_2=iter_scf_1:1:iter_scf_1+(20*3600)     %2 hrs after the plant stops to next 20 hrs (If plant stops at 4.30 PM then this loop will run till 12.30 PM)
        if  mod(iter_scf_2,60)==0                        %After every 60 sec it will activate to take value
            if ip2<length(lfr_I_sec)                    %Loop for ip2 does not exceed lfr_I_sec size
                ip2=ip2+1;                               %So, ip2 updated after every 60 sec like ip1
            end
        end
        ip2
        II=lfr_I_sec(ip2);                              %ip2 takes 1 solar radiation value at a time and will reamins for 60 sec, II is solar radiation
        
        if  II > 250                                    %if Solar radiation > 250
            break_time=iter_scf_2;                       %break_time takes current iter_scf2 value
            timestart= break_time;                      %Start time will be then breaktime value
            note_time_next_start=[note_time_next_start break_time];%Note the time when start
            break_time_stop=1;
            break   %it will go to 46
        end
    %If above cond is not satisfied then below will carry on. And when
    %above will satisfy it will break out from the loop.
    %why??
        if iter_scf_2==iter_scf_1+(16*3600)         %only enter aftre 16hrs to start day2
            break_time=iter_scf_2;
            timestart= break_time;
            note_time_next_start=[note_time_next_start break_time];
            break_time_stop=1;
        end
    end

    break_time_norma=((break_time-iter_scf)/3600);
    break_time_norma_hr=break_time_norma*3600;%15.9 hrs to sec , it is used in nightime simu
    %% %Initialization for SG Night

    %Before night time simulation
    SG_night(:,shut_cou_sg)=[SG.press  SG.Mw  SG.Msteam  SG.Twater];    %[SG_pressure   %Mass_of_water   %Mass_of_steam    Temp_of_steam_coming_out(SG Saturation temperature)]
    shut_cou_sg=shut_cou_sg+1;

    %Initialization for SG Night
    HX.SG_night_press=SG.press;                                                %SG_pressure
    HX.SG_night_press_int=[HX.SG_night_press SG.Mw SG.Msteam];                 %[SG_pressure   %Mass_of_water   %Mass_of_steam}

    %Connect SG Night
    Tspan_SG_night=[0  break_time_norma_hr];
    options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
    [Ts,Y_HXSG]=ode15s(@HXSG_night1,Tspan_SG_night,HX.SG_night_press_int,options);
    HX.SG_night_press_int=(Y_HXSG(length(Ts),:)');

    %After night time simulation
    SG.press=HX.SG_night_press_int(1);                                         %SG Pressure
    SG.Mw=HX.SG_night_press_int(2);                                            %Mass of water inside the SG
    SG.Msteam=HX.SG_night_press_int(3);                                        %Mass of steam inside the SG
    SG.Twater=XSteam('Tsat_p',SG.press);                                       %SG Saturation temperature

    %For storing the SG variables
    HX.SG_night_press_arr=[HX.SG_night_press_arr HX.SG_night_press];           %To store SG pressure
    SG.m_cond_SG_arr=[SG.m_cond_SG_arr SG.m_cond_SG];                          %SG.m_cond_SG:  Mass of water or Mass of steam based on sign (See HXSG_night1)
    SG_MW=[SG_MW  SG.Mw];                                                      %SG mass of water
    SG_MS=[SG_MS SG.Msteam];                                                   %SG mass of steam
    shut_SG=[shut_SG SG.press];                                                %SG pressure

    %After night time simulation
    SG_night(:,shut_cou_sg)=[SG.press SG.Mw SG.Msteam SG.Twater] ;
    shut_cou_sg=shut_cou_sg+1;
    
    
    %% Initialization for SD Night

    %Before night time simulation
    SD_night(:,shut_cou_sd)=[Drum.press Drum.Mass_wat Drum.Mass_steam Drum.Temp_wat];   %[Drum_pressure   Mass_of_water   MAss_of_steam   Water_temp]
    shut_cou_sd=shut_cou_sd+1;

    %Initialization for SD Night
    Drum.press=XSteam('psat_T',Drum.Temp_wat);                                  %Drum Saturation pressure
    SDnight_int=[Drum.press  Drum.Mass_wat  Drum.Mass_steam];                   %[Drum_pressure   Mass_of_water   MAss_of_steam]

    %Connect SD Night
    Tspan_sd_nig=[0  break_time_norma_hr];
    options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
    [Ts,Y_SD]=ode15s(@SD_night1,Tspan_sd_nig,SDnight_int,options);
    SDnight_int=(Y_SD(length(Ts),:)');

    %After night time simulation
    Drum.press=SDnight_int(1);                       %SD Pressure
    Drum.Temp_wat=XSteam('Tsat_p',SDnight_int(1)); %Temperature of water
    Drum.Mass_wat=SDnight_int(2);                  %Mass of water
    Drum.Mass_steam=SDnight_int(3);                %Mass of steam
    %New
    Drum.temp_steam=XSteam('Tsat_p',SDnight_int(1)); %SD steam temp
    
    %For storing the SD variables
    SD_night_arr=[SD_night_arr SDnight_int];
    SD_m_cond_arr=[SD_m_cond_arr Drum.m_cond];
    SD_MW=[SD_MW  Drum.Mass_wat];
    SD_MS=[SD_MS Drum.Mass_steam];
    shut_SD=[shut_SD Drum.press];
    SD.press=Drum.press;
    %After night time simulation
    SD_night(:,shut_cou_sd)=[Drum.press Drum.Mass_wat Drum.Mass_steam Drum.Temp_wat];
    shut_cou_sd=shut_cou_sd+1;

    %% HT
    PTC_HT.Xintial1=OP.HT_Temp(end);                    %What is the use of this?
    V_HT=PTC_HT.Xintial(1)/(density_oil(HT.Toout));     %Volume of Oil
    h_HT=V_HT/(pi*(HT.radi^2));                         %Height of Oil
    U_HT_night=U.HT_night;                              %HTC
    A_HT= pi*(HT.radi*h_HT) ;                           %Area of oil
    M_HT=PTC_HT.Xintial(1);                                      %Mass of oil in HT
    CP_HT=Cp_oil(HT.Toout);                             %Specific heat capacity of oil
    T_OHT=HT.Toout;                                     %Temperature of oil out from HT
    t_i_HT= 0;                                          % Why zero ??
    t_o_HT=break_time_norma_hr;                         % ??
    Tamb_HT=35 ;                                        %Ambiant temperature
    oil_T_HT=T_OHT;                                     %Temperature of oil out
    shut_HT=[shut_HT oil_T_HT];                         % Before nightime cooling temp
    %Equation A.65 in Surrender Thesis
    oil_T_HT= ((oil_T_HT- Tamb_HT)*exp(-1*(U_HT_night*A_HT)/(M_HT*CP_HT) *(t_o_HT-t_i_HT)) + Tamb_HT);   %How temperature is changing in night time
    HT.Toout=oil_T_HT;                                  %Temp of HT oil out
    shut_HT=[shut_HT oil_T_HT];                         % After nightime cooling temp

    %% LT
    PTC_LT.Xintial1=OP.LT_Temp(end);                    %What is the use of this?
    V_LT=PTC_LT.Xintial(1)/(density_oil(LT.Toout));     %Volume of Oil
    h_LT=V_HT/(pi*(LT.radi^2));                         %Height of Oil
    U_LT_night=U.LT_night;                              %HTC
    A_LT= pi*(LT.radi*h_LT) ;                           %Area of oil
    M_LT= PTC_LT.Xintial(1);                            %Mass of oil in LT
    CP_LT= Cp_oil(LT.Toout);                            %Specific heat capacity of oil
    T_OLT=LT.Toout;                                     %Temperature of oil out from LT
    t_i_LT= 0;                                          % Why zero ??
    t_o_LT=break_time_norma_hr;                         % ??
    Tamb_LT=35 ;                                        %Ambiant temperature
    oil_T_LT=T_OLT;                                     %Temperature of oil out
    shut_LT=[shut_LT oil_T_LT];                         %Before nightime cooling temp
    %Equation A.65 in Surrender Thesis
    oil_T_LT= ((oil_T_LT- Tamb_LT)*exp(-1*(U_LT_night*A_LT)/(M_LT*CP_LT) *(t_o_LT-t_i_LT)) + Tamb_LT);
    LT.Toout=oil_T_LT;                                  %Temp of LT oil out
    shut_LT=[shut_LT oil_T_LT];                         % After nightime cooling temp

    %% Cooling for PH & SH

    % PH
    shut_PH=[shut_PH HX.PHintial(2)];
    V_PH=PH.Mass_oil/(density_oil(HX.PHintial(2)));     %Volume of Oil
    h_PH=V_PH/(pi*((PH.shell_ID/2)^2));                 %Height of Oil
    U_PH_night=U.LT_night;                              %HTC
    A_PH= pi*((PH.shell_ID/2)*h_PH);                    %Area of oil
    M_PH= PH.Mass_oil;                                  %Mass of oil in LT
    CP_PH= Cp_oil(HX.PHintial(2));                      %Specific heat capacity of oil
    T_OLT=HX.PHintial(2);                               %Temperature of oil out from LT
    t_i_PH= 0;                                          % Why zero ??
    t_o_PH=break_time_norma_hr;                         % ??
    Tamb_PH=35 ;                                        %Ambiant temperature
    oil_T_PH=HX.PHintial(2);                            %Oil Temperature
    %Equation A.65 in Surrender Thesis
    oil_T_PH=((oil_T_PH- Tamb_PH)*exp(-1*(U_PH_night*A_PH)/(M_PH*CP_PH) *(t_o_PH-t_i_PH)) + Tamb_PH);

    % SH
    shut_SH=[shut_SH HX.SHintial(1)];
    V_SH=SH.Mass_oil/(density_oil(HX.SHintial(1)));     %Volume of Oil
    h_SH=V_SH/(pi*((SH.shell_ID/2)^2));                 %Height of Oil
    U_SH_night=U.LT_night;                              %HTC
    A_SH= pi*((SH.shell_ID/2)*h_SH);                    %Area of oil
    M_SH= SH.Mass_oil;                                  %Mass of oil in LT
    CP_SH= Cp_oil(HX.SHintial(1));                      %Specific heat capacity of oil
    T_OLT=HX.SHintial(2);                               %Temperature of oil out from LT
    t_i_SH= 0;                                          % Why zero ??
    t_o_SH=break_time_norma_hr;                         % ??
    Tamb_SH=35 ;                                        %Ambiant temperature
    oil_T_SH=HX.SHintial(1);                            %Oil Temperature
    %Equation A.65 in Surrender Thesis
    oil_T_SH= ((oil_T_SH- Tamb_SH)*exp(-1*(U_SH_night*A_SH)/(M_SH*CP_SH) *(t_o_SH-t_i_SH)) + Tamb_SH);

    HX.PHintial(2)=oil_T_PH;                            %Oil Temperature of PH
    HX.SHintial(1)=oil_T_SH;                            %Oil Temperature of SH

    OP.shut_oil_T_SH=[OP.shut_oil_T_SH  break_time_norma_hr  oil_T_SH ];
    OP.shut_oil_T_PH=[OP.shut_oil_T_PH break_time_norma_hr  oil_T_PH];

    shut_PH=[shut_PH oil_T_PH];
    shut_SH=[shut_SH oil_T_SH];

    simulation_night=0;

end
if Type==1
    ip2=1441;
end
ip3=ip2;
end