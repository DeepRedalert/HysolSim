%Function file tO find density of oil with respect to temperature
%Polynomial fit has been taken from THerminol-PV1 PDF file.

function [row]=density_oil(T)
         row=(-0.90797*T)+(0.00078116*T^2)+(-2.367*10^-6*T^3)+1083.25; 
end
