%Function file for Calculating Thermal Conductivity
%Polynomial has been taken form Therminol-PV1 PDF

function [t]=Ther_con(T)
t=(-8.19477*10^-5*T)+(-1.92257*10^-7*T^2)+(2.5034*10^-11*T^3)+(-7.2974*10^-15*T^4)+0.137743;
end