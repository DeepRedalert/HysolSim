% Function file for LFR HTC calculation

function [hp]=compute_hp(velo,dens,press,enthal,time,poistion,phase)

global  hfg LFR

global single_scaling two_scaling

% liquid_sat=XSteam('hL_p',press);
% vapo_sat=XSteam('hV_p',press);
g=9.8;

mw_kgs_in=LFR.mw_indi;  %0.3 value from main file    %(velo*dens*LFR.dia_ab^2)/1.2734;
enthal=enthal*10^-3;    %Enthalpy of fluid

%%  Single phase HTC: Dittus bolter equation
%if ( phase==0  || phase >1)         %??
if ( phase==0  || phase ==1)         %??
    den_grid=XSteam('rho_ph',press,enthal);         %rho_ph	Density as a function of pressure and enthalpy
    cp_grid=(XSteam('Cp_ph',press,enthal))*1000;    %Cp_ph	Specific isobaric heat capacity as a function of pressure and enthalpy
    dyn_vis=XSteam('my_ph',press,enthal);           %my_ph	Viscosity as a function of pressure and enthalpy
    Th_lfr=XSteam('tc_ph',press,enthal) ;           %tc_ph	Thermal conductivity as a function of pressure and enthalpy

    if ( isnan(dyn_vis)==1 )
        dyn_vis=h2o_muf(press*100);                 %h2o_muf=  Dynamic viscosity of saturated fluid at a given pressure
    end
    if  isnan(cp_grid)==1
        cp_grid=(XSteam('CpL_p',press))*1000;       %CpL_p	Saturated liquid heat capacity 
    end

    KVis_lfr=dyn_vis/den_grid;                  %Kinetic viscosity
    
    %vol=mw_kg_in/den_grid;
    %vel_lfr=(1.2734*vol)/(dia^2);

    ren_lfr=(LFR.dia_ab*velo)/KVis_lfr;         %Reynolds Number
    pr_lfr=(cp_grid*dyn_vis)/Th_lfr;            %Prandtl Number
    % Single phase convective HTC
    hp=0.023*(ren_lfr^0.8)*(pr_lfr^0.4)*(Th_lfr/LFR.dia_ab);
    hp=single_scaling*hp;                       %Here single_scaling=1
else
%% Two phase HTC: Odeh et al.  & Aurousseau et al.

    xx=phase;
    den_lfr_g=XSteam('rhoV_p',press);       %rhoV_p	Saturated vapour density
    den_lfr_L=XSteam('rhoL_p',press);       %rhoL_p	Saturated liquid density

    den_grid=xx*den_lfr_g+(1-xx)*den_lfr_L; %Denisity of ??

    cp_grid_V=(XSteam('CpV_p',press))*1000;     %CpV_p	Saturated vapour heat capacity 
    cp_grid_L=(XSteam('CpL_p',press))*1000;     %CpL_p	Saturated liquid heat capacity 
    cp_grid=(xx*cp_grid_V)+((1-xx)*cp_grid_L);

    Th_lfr=XSteam('tc_ph',press,enthal) ;       %tc_ph	Thermal conductivity as a function of pressure and enthalpy

    mu_V=XSteam('my_ph',press,enthal);          %my_ph	Viscosity as a function of pressure and enthalpy
    mu_L=XSteam('my_ph',press,enthal);

    if  isnan(Th_lfr)==1                        %To check NAN elements
        disp('Thermal is nan');
    end

    mu_L=h2o_muf(press*100);                    % h2o_muf  Dynamic viscosity of saturated fluid at a given pressure
    mu_V=h2o_mug(press*100);                    % H2O_MUG  Dynamic viscosity of saturated steam at a given pressure

    mu_2ph=mu_V;                                %Dynamic viscosity of steam
    dyn_vis=mu_V;                               %Dynamic viscosity

    pr_lfr=(cp_grid*dyn_vis)/Th_lfr;            %Prandtl Number

    LFR.rai=LFR.dia_ab/2;                       %LFR radius
    G= mw_kgs_in/(pi*(LFR.rai^2));              %Mass flux     kg/m^2 S
    Fr=(G^2)/((den_grid^2)*g*LFR.dia_ab);       %Froud number
%Equation A.21 in the thesis, page no 155 (Dittus boelter equation)
    h1=0.023*(Th_lfr/LFR.dia_ab)*(((G*(1-xx)*LFR.dia_ab)/mu_2ph)^0.8)*(pr_lfr^0.4);     %HTC ??? in thesis problem, mu_2ph should mu_l

%% 2 phase HTC condition w.r.t Froud number
    if ( Fr < 0.04 )
        disp('fround number <0.04');
        h2ph=3.9*(Fr^0.24)*((xx/(1-xx))^0.64)*((den_grid/den_lfr_g)^0.4)*h1;            %Equation A.21 on 155 page of thesis
        pause
    else
        Pcr=221;                %Critical pressure for water=221 bar
        P=press;                %Working pressure
        q=LFR.I*0.25;           %Quality of steam    
        Pn=P/Pcr;               %Pressure of working fluid

        Bo=q/(G*hfg*1000);      %Boiling number
        Re_lfr=(G*(1-xx)*LFR.dia_ab)/mu_2ph;
        nlfr=0.9-(0.3*(Pn^0.15));
% These relations are given by Stephan (1992)
        Fp=2.55*(Pn^0.27)*(9+(1/(1-(Pn^2))))*(Pn^2);
        hb=3800*((q/20000)^nlfr)*Fp;

        Xtt=((den_lfr_g/den_lfr_L)^0.5)*(((1-xx)/xx)^0.9);%*((mu_L/mu_V)^0.1);              %Martinelli parameter

        Ffact=1+((2.4*10^4)*(Bo^1.16))+(1.37*(Xtt^-0.86));      %Enhancement factor
        Sfact=1/( 1+(1.15*10^-6)*(Ffact^2)*(Re_lfr^1.17) );     %Correction factor

        h1das=h1*Ffact;
        hbdas=hb*Sfact;
        h2ph=hbdas+h1das;           %Equation A.22 in the thesis
    end
    h2ph=two_scaling*h2ph;          %two_scaling=1
    hp=h2ph;                        %Final HTC for 2 phase flow
end
end