%Function file for calculating Enthalpy of LT oil

function f=enthal_Temp_LT(hoilout_LT)
 
global LT 
 
   f=h_oil(hoilout_LT)-LT.hout;            %hoilout_HT ----KJ/Kg
   
end


