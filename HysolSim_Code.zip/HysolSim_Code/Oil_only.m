function X=Oil_only(Mode,Type,Startup)

global PTC_scf PTC_SCF PTC_HT_OD  Type  Mode ip3 Startup dt HT HX SH SG PH LT OP PTC_Fullplant  lfr_I_sec

global iter_scf PTC_HT PTC_LT Xa XA  Xax POW POWeT_pos_pow timestart break_time_stop shut_cou_sg shut_cou_sd

%To load the all initial values for respective type 
if Type==0          %(Constant Solar radiation)
    load lfr_I_sec_700_all_Lgp.mat                                                       %700 all with low g.points
    %     load lfr_I_sec_700_all_hgp.mat                                    %700 all with high g.points
    simu_time_end=9*3600;
elseif Type==1      %(Constant Solar radiation with step change)
    load lfr_I_sec_step_Lgp.mat
    %     lfr_I_sec_700_all_hgp
    %load I_step_updated2.mat %700--400                                    %Step solar raqdiation should not below 200
elseif Type==2      %(Real time Solar radiation)
    load lfr_I_sec_real_Lgp.mat                                            %Real time with less g.points
    %load lfr_I_sec_real_Lgp3.mat                                          %Real time with less g.points
    %load lfr_I_sec_real_hgp.mat                                           %Real time with less g.points
elseif Type==3      %(Quadratic Solar radiation)
    load lfr_I_sec_quad_Lgp.mat                                            %Real time with less g.points
    %     load lfr_I_sec_quad_hgp.mat                                      %Real time with less g.points---
end

if Type==2
    load RealTIme_solar_rad.mat
end

%simu_time_end=9*3600;     %For 9hrs simulation
shut_cou_sg=1;
shut_cou_sd=1;

if Startup==1                           %Cold strtup
    tic                                 %To see the total time for the simulation
    for i=1:1:leng_I
        while SG.boiling==0                                                         %When there is no boiling happan

            for iter_scf=timestart:dt.scf:simu_time_end
                iter_scf_oil_loop=iter_scf                                          %To display the iteration no

                % 1. LT-PTC-LT Connection
                PTC_scf.Toilin=LT.Toout;                                            %Output of LT goes into PTC, So LT-PTC connected

                if  mod(iter_scf,60)==0                                             %After every 60 sec
                    PTC_scf.I= lfr_I_sec(ip1);                                      %ip1 takes 1 solar radiation value at a time and will reamins for 60 sec
                    Ambient_Temp=Ambient_Temp_ind(ip1);                             %Ambient Temperature                oC
                    if ip1<length(lfr_I_sec)                                        %Loop for ip1 does not exceed lfr_I_sec size
                        ip1=ip1+1;
                    else
                        count=1
                    end
                end
                HX.Ambient_Tempr=Ambient_Temp;                                      %HX stands for Heat exchanger

                %For storing purpose
                OP.I_solar=[OP.I_solar PTC_scf.I];                                  %To save the solar radiation
                OP.Ambient_T=[OP.Ambient_T Ambient_Temp];                           %To save the ambient temperature

                %Condition for Bypass HX
                if  PTC_SCF.Xintial(PTC_scf.grid) < 150                             %Output of PTC oil temp < 150
                    PTC_HT_LTalone=1;                                               %PTC, HT, LT form route and bypass rest(HX)
                else
                    PTC_HT_LTalone=0;                                               %PTC,HT,LT not alone, HX added
                end

                if PTC_HT_LTalone==1                                                %PTC, HT, LT form route and bypass rest,PTC op temp<150
                    %% Oil loop

                    %Connect PTC
                    Tspan=[0  dt.scf];                                              %o to 1 second
                    options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                    [Ts,Y_SCF]=ode15s(@solarfield,Tspan,PTC_SCF.Xintial,options);   %Integrate PTC tank ODEs
                    PTC_SCF.Xintial=(Y_SCF(length(Ts),:)');
                    PTC_out_temp=PTC_SCF.Xintial(15)                                %PTC outlet temp

                    if (HT.Toout<= PTC_SCF.Xintial(PTC_scf.grid))                   %If 40 oC (HT initial temp) <= Oil output temp of PTC
                        %Connect PTC-HT-LT
                        PTC_HT_OD=1;                                                %Then connect HT with PTC together and LT
                        PTC_LT_OD=0;
                        [HT_out_temp,LT_out_temp]=PTC_HT_LT_connection(Tspan);      %Calling function file with connection of PTC-HT-LT
                    else
                        %Connect PTC-LT
                        PTC_LT_OD=1;                                                %Connect PTC with LT only when HT temp >PTC outlet
                        PTC_HT_OD=0;
                        [LT_out_temp]=PTC_LT_connection(Tspan);                     %%Calling function file with connection of PTC-LT

                    end

                    %TO compute energy from PTC
                    [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);              %Function file calling for energy computation from PTC component
                    E_ptc_num=E_ptc_num+1;                                          %Update step

                end


                if PTC_HT_LTalone==0                                                %PTC, HT, LT with SG,PTC op temp>150
                    %% Oil loop

                    %Connect PTC
                    Tspan=[0  dt.scf];                                              %o to 1 second
                    options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                    [Ts,Y_SCF]=ode15s(@solarfield,Tspan,PTC_SCF.Xintial,options);   %Integrate PTC tank ODEs
                    PTC_SCF.Xintial=(Y_SCF(length(Ts),:)');
                    PTC_out_temp=PTC_SCF.Xintial(15)                                %PTC outlet temp

                    %Connect HT with PTC
                    HT.moilin=PTC_scf.moil*3;                                       %Mass of oil out from SCF enters to HT
                    HT.moilout=HT.moilin;                                           %Mass of oil out from HT same as mass of oil in to HT
                    HT.hin=h_oil(PTC_SCF.Xintial(PTC_scf.grid));                    %Enthalpy of oil in to HT

                    if  PTC_HT_OD==1                                                %If HT tank temp <= PTC outlet temp
                        %Connect HT
                        options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                        [Ts,Y_HT]=ode15s(@HTtank,Tspan,PTC_HT.Xintial,options);     %ODE integration of HT
                        PTC_HT.Xintial=(Y_HT(length(Ts),:)');

                        HT.hout=PTC_HT.Xintial(2);                                  %Enthalpy of oil coming out from HT
                        %opts = optimset('TolFun',1e-12,'Display','off') ;
                        %HT.Toout=fsolve('enthal_Temp_HT',HT.Toout,opts);
                        HT.Toout=(-1.49681+sqrt(1.49681^2-4*0.0014*(-18.17454-HT.hout)))/(2*0.0014);   %At current enthalpy HT output temperature
                        HT_out_temp=HT.Toout;                                       %For saving HT outlet Temp

                        %Connect HT with SG_Subcooled
                        SG.moil=HT.moilout;                                         %The mass of oil coming from HT goes into SG
                        SG.Toilin=HT.Toout;                                         %Temp of oil to SG=HT temp of oil out
                    else
                        %Connect HT with SG_Subcooled
                        SG.moil=PTC_scf.moil*3;                                     %Mass of oil out from SCF enters to SG (When HT not conected)
                        SG.Toilin=PTC_SCF.Xintial(PTC_scf.grid);                    %Outlet of SCF connected to SG
                    end

                    %At 1 bar saturation enthalpy of water is 417.44 kJ/kg (Check unit)
                    SG.Wsat=XSteam('hL_p',SG.press_int);                            %SG.press_int=1bar pressure at SG, which is saturation pressure of water.
                    check_Wsat_SG=(SG.Wsat-HX.SGintial(5));                         %HX.SGintial(5)=Current enthalpy

                    if  (check_Wsat_SG <=0)                                         %So if saturation enthalpy is zero/-ve then saturation will occure.
                        disp('Saturation occured');
                    else
                        %Connect SG_Subcooled: Here SG subcooled means no boiling happan till now, saturation has not occured yet
                        options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                        [Ts,Y_HXSG]=ode15s(@HXSG_subcool,Tspan,HX.SGintial,options);%HXSG_subcool will be connected till SG pressure reach setopint pressure
                        HX.SGintial=(Y_HXSG(length(Ts),:)');
                        SG.ODE=1;
                    end

                    %To store the variables
                    OP.SGuaf=[OP.SGuaf SG.UAF];                                     %To store Final UAF
                    OP.SGhtube=[OP.SGhtube  SG.htctube];                            %To store heat transfer coefficient of tube side
                    OP.SGhshell=[OP.SGhshell SG.htcshell];                          %TO store heat transfer coefficient of shell side
                    OP.SGF=[OP.SGF SG.htcF];                                        %To store correction factor
                    OP.SGU=[OP.SGU SG.htcU];                                        %TO store overall heat transfer coefficient

                    %Connect LT with SG
                    LT.moilin=SG.moil;                                              %LT mass of oil comes from SG
                    LT.moilout=LT.moilin;                                           %Mass of oil out from LT same as mass of oil in to LT

                    if iter_scf==1          %Why
                        LT.hin=h_oil(((HT.Tintial+LT.Tintial)/2)-1);                %Why like this??
                    else
                        LT.hin=h_oil(HX.SGintial(1));                               %Enthalpy of oil in to LT is calculated at SG output temperature.
                    end
                    %X.SGintial(1)=HT.Tintial-1 , why not HTtout
                    options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                    [Ts,Y_LT]=ode15s(@LTtank,Tspan,PTC_LT.Xintial,options);         %Integrating LT tank ODEs
                    PTC_LT.Xintial=(Y_LT(length(Ts),:)');

                    LT.hout=PTC_LT.Xintial(2);                                      %Enthalpy of oil out from LT

                    LT.Toout=(-1.49681+sqrt(1.49681^2-4*0.0014*(-18.17454-LT.hout)))/(2*0.0014);    %LT outlet temperature
                    LT_out_temp= LT.Toout;                                                          %LT temperature output
 
                    %LT again connected to PTC
                    PTC_SCF.Xintial(1)=LT.Toout;                                    %LT temperature output is going to PTC inlet

                    %TO compute energy
                    [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);              %Function file calling for energy compute from PTC
                    E_ptc_num=E_ptc_num+1;                                          %Update step

                    POWeT.powgen(iter_scf+1)=0;

                    %For power generation value positive
                    if  POWeT.powgen(iter_scf+1) >0
                        POWeT_pos_pow.powgen(xx)=POWeT.powgen(iter_scf+1);
                        xx=xx+1;
                    else
                        POWeT_pos_pow.powgen(xx)=0;
                        xx=xx+1;
                    end
                    Xax.POW=[Xax.POW iter_scf];                                     %Storing iter_scf at Xax.POW

                    %For Storing purpose
                    POW.ms_SG(iter_scf+1)=SG.msgen;                                 %To store the value of SG mass of steam generated
                    POW.Ts_turb(iter_scf+1)=HX.SHintial(2);                         %To store the value of temp of steam going out from Sh to turbine
                    TW_in_HX(iter_scf+1)=HX.Twin;                                   %To store the value of Temp of water in to Heat exchanger

                    OP_TTsteam=XSteam('Tsat_p',SG.press_int);
                    OP.Tsteam=[OP.Tsteam OP_TTsteam ];                              %Storing OP_TTsteam

                    SG.mwin=HX.mwin;                                                %Mass of water going in to Sg
                    PH.mwin=HX.mwin;                                                %Mass of water going in to PH
                    %For stroign purpose
                    PH.sav_mwin(iter_scf+1)=PH.mwin;                                %Mass of water in to PH
                    SG.sav_mwin(iter_scf+1)=SG.mwin;                                %Mass of water in to SG
                    HX.sav_mwin(iter_scf+1)=HX.mwin;                                %Mass of water in to HX

                    %TO compute energy
                    [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);
                    E_ptc_num=E_ptc_num+1;
                end

                %FOr storing purpose
                Xaxis=[Xaxis  iter_scf];
                OP.SCF=[OP.SCF  PTC_SCF.Xintial];                                   %Store PTC temp

                OP.HT_Temp=[OP.HT_Temp HT_out_temp];                                %Store HT temp

                OP.LT_Temp=[OP.LT_Temp LT_out_temp];                                %Store LT temp
                if SH.ODE==1
                    OP.SH=[OP.SH  HX.SHintial];
                    Xa.X_SH=[Xa.X_SH iter_scf];
                    OP.sh_tsout=[OP.sh_tsout SH.Tsout];             %TO store steam outlet temp of SH
                    Tur.msin=[Tur.msin SH.msin];
                    OP.SHuaf=[OP.SHuaf SH.UAF];
                    OP.SHhtube=[OP.SHhtube  SH.htctube];
                    OP.SHhshell=[OP.SHhshell SH.htcshell];
                    OP.SHF=[OP.SHF SH.htcF];
                    OP.SHU=[OP.SHU SH.htcU];
                    Xa.X_SH_U=[Xa.X_SH_U iter_scf];
                end

                if SG.ODE==1
                    OP.SG_temp=[OP.SG_temp HX.SGintial(1)];
                    OP.SGTw=[OP.SGTw SG.Twater];
                    XA.X_SG=[XA.X_SG iter_scf];
                    OP.SGmsgen=[OP.SGmsgen SG.msgen];
                    OP.SG_pressure=[OP.SG_pressure HX.SGintial(6)];
                end
                pow_PTC_arr=[pow_PTC_arr pow_PTC];              %power generation from PTC

                SG.Wsat=XSteam('hL_p',SG.press_int);                                %To check saturated liquid enthalpy
                check_Wsat_SG=(SG.Wsat-HX.SGintial(5));
                if  (check_Wsat_SG <=0 )
                    disp('Saturation Occured');
                    HX.SGintial(5)=SG.Wsat; %----correction to have equal value of satu enthalphy  ??
                    SG.boiling=1;
                    break
                end
            end
        end

        timestart=Xaxis(end);
        SG.msgen=0;% intial value
        while (SG.boiling==1  && PTC_Fullplant==0)

            for iter_scf=(timestart+1):dt.scf:simu_time_end
                boil_loop=iter_scf

                %% Oil loop

                % 1. LT-PTC-LT Connection
                PTC_scf.Toilin=LT.Toout;                                            %Output of LT goes into PTC=40 oC, So LT-PTC connected

                if  mod(iter_scf,60)==0                                             %After every 60 sec
                    PTC_scf.I= lfr_I_sec(ip1);
                    Ambient_Temp=Ambient_Temp_ind(ip1);
                    if ip1<length(lfr_I_sec)
                        ip1=ip1+1;
                    else
                        break
                    end
                end
                HX.Ambient_Tempr=Ambient_Temp;

                %For storing purpose
                OP.I_solar=[OP.I_solar PTC_scf.I];
                OP.Ambient_T=[OP.Ambient_T Ambient_Temp];

                %Connect PTC
                Tspan=[0  dt.scf];                      %o to 1 second
                options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                [Ts,Y_SCF]=ode15s(@solarfield,Tspan,PTC_SCF.Xintial,options);       %Integrate PTC tank ODEs
                PTC_SCF.Xintial=(Y_SCF(length(Ts),:)');
                PTC_out_temp=PTC_SCF.Xintial(15)                                    %PTC outlet temp

                %Connect HT with PTC
                HT.moilin=PTC_scf.moil*3;                                           %WHy not given in sir code
                HT.moilout=HT.moilin;
                HT.hin=h_oil(PTC_SCF.Xintial(PTC_scf.grid));

                if PTC_HT_OD==1
                    options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                    [Ts,Y_HT]=ode15s(@HTtank,Tspan,PTC_HT.Xintial,options);
                    PTC_HT.Xintial=(Y_HT(length(Ts),:)');

                    HT.hout=PTC_HT.Xintial(2);
                    opts = optimset('TolFun',1e-12,'Display','off') ;
                    %               HT.Toout=fsolve('enthal_Temp_HT',HT.Toout,opts);
                    HT.Toout=(-1.49681+sqrt(1.49681^2-4*0.0014*(-18.17454-HT.hout)))/(2*0.0014);
                    HT_out_temp=HT.Toout;

                    %Connect HT with SG_Subcooled
                    SG.moil=HT.moilout;
                    %HX.Toin=HT.Toout;
                    SG.Toilin=HT.Toout;                                             %Temp of oil to SG=HT temp of oil out
                else
                    SG.moil=HT.moilout;
                    SG.Toilin=PTC_SCF.Xintial(PTC_scf.grid);
                end
                SG.Wsat=XSteam('hL_p',SG.press_int);
                check_Wsat_SG=(SG.Wsat-HX.SGintial(5));
                SG.hs= XSteam('hV_p',HX.SGintial(6));
                SG.hw=XSteam('hL_p',HX.SGintial(6));

                %Connect SG_Saturated
                options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                [Ts,Y_HXSG]=ode15s(@HXSG_sat,Tspan,HX.SGintial,options);
                HX.SGintial=(Y_HXSG(length(Ts),:)');
                SG_pressure=HX.SGintial(6)
                SG.ODE=1;

                %To check is there any imaginary part
                nedstop=isreal(HX.SGintial );
                if (nedstop)==0   %has img part
                    disp('Imaginary number in HX.SGintial')
                end

                %To store the variables
                OP.SGuaf=[OP.SGuaf SG.UAF];
                OP.SGhtube=[OP.SGhtube  SG.htctube];
                OP.SGhshell=[OP.SGhshell SG.htcshell];
                OP.SGF=[OP.SGF SG.htcF];
                OP.SGU=[OP.SGU SG.htcU];

                %Connect LT with SG
                LT.moilin=SG.moil;  %Not in sir code why
                LT.moilout=LT.moilin;

                LT.hin=h_oil(HX.SGintial(1));

                options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                [Ts,Y_LT]=ode15s(@LTtank,Tspan,PTC_LT.Xintial,options);
                PTC_LT.Xintial=(Y_LT(length(Ts),:)');

                LT.hout=PTC_LT.Xintial(2);
                LT.Toout=(-1.49681+sqrt(1.49681^2-4*0.0014*(-18.17454-LT.hout)))/(2*0.0014);
                LT_out_temp=LT.Toout;

                %LT again connected to PTC
                PTC_SCF.Xintial(1)=LT.Toout;

                %TO compute energy
                [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);
                E_ptc_num=E_ptc_num+1;

                POWeT.powgen(iter_scf+1)=0;

                if  POWeT.powgen(iter_scf+1) >0
                    POWeT_pos_pow.powgen(xx)=POWeT.powgen(iter_scf+1);
                    xx=xx+1;
                else
                    POWeT_pos_pow.powgen(xx)=0;
                    xx=xx+1;
                end
                Xax.POW=[Xax.POW iter_scf];                                         %Storing iter_scf at Xax.POW

                OP.Tsteam=[OP.Tsteam SG.Twater];                                    %Storing OP_TTsteam

                SG.mwin=HX.mwin;                                                    %Mass of water going in to Sg
                PH.mwin=HX.mwin;                                                    %Mass of water going in to PH

                %For storing purpose
                PH.sav_mwin(iter_scf+1)=PH.mwin;                                    %Mass of water in to PH
                SG.sav_mwin(iter_scf+1)=SG.mwin;                                    %Mass of water in to SG
                HX.sav_mwin(iter_scf+1)=HX.mwin;                                    %Mass of water in to HX

                POW.ms_SG(iter_scf+1)=SG.msgen;
                POW.Ts_turb(iter_scf+1)=HX.SHintial(2);

                TW_in_HX(iter_scf+1)=HX.Twin;                                   %Temp of water in to Heat exchanger

                %TO compute energy
                [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);
                E_ptc_num=E_ptc_num+1;

                %For storing purpose
                OP.SCF=[OP.SCF  PTC_SCF.Xintial];                                   %Store PTC temp

                OP.HT_Temp=[OP.HT_Temp HT_out_temp];                                %Store HT temp
                %OP.LT_Temp=[OP.LT_Temp LT.Toout];                                  %Store LT temp
                OP.LT_Temp=[OP.LT_Temp LT_out_temp];
                if SH.ODE==1
                    OP.SH=[OP.SH  HX.SHintial];
                    Xa.X_SH=[Xa.X_SH iter_scf];
                    OP.sh_tsout=[OP.sh_tsout SH.Tsout];             %TO store steam outlet temp of SH
                    Tur.msin=[Tur.msin SH.msin];
                    OP.SHuaf=[OP.SHuaf SH.UAF];
                    OP.SHhtube=[OP.SHhtube  SH.htctube];
                    OP.SHhshell=[OP.SHhshell SH.htcshell];
                    OP.SHF=[OP.SHF SH.htcF];
                    OP.SHU=[OP.SHU SH.htcU];
                    Xa.X_SH_U=[Xa.X_SH_U iter_scf];
                end

                if SG.ODE==1
                    OP.SG_temp=[OP.SG_temp HX.SGintial(1)];
                    OP.SGTw=[ OP.SGTw SG.Twater];
                    XA.X_SG=[XA.X_SG iter_scf];
                    OP.SGmsgen=[OP.SGmsgen SG.msgen];
                    OP.SG_pressure=[OP.SG_pressure HX.SGintial(6)];
                end

                Xaxis=[Xaxis  iter_scf];

                pow_PTC_arr=[pow_PTC_arr pow_PTC];             %power generation from PTC

                if  HX.SGintial(6)>=SG.press_st
                    disp('pressure reached');
                    pressure_now=HX.SGintial(6)
                    PTC_Fullplant=1;
                    break
                end
            end
        end

        timestart=Xaxis(end);
        disp('SG Pressure reached 40bar, Now Full plant will work')

        SG.hs_steam= XSteam('hV_p',HX.SGintial(6));

        SG.LFR_Tsout=SG.Twater;

        mix_sh_intial=[0 0];

        HX.Twin=(SG.Twater/250)*75; 
        SG.Twin=HX.Twin;
        HX.PHintial=[HX.Twin+1 HX.SGintial(1)-1];

        HX.SHintial=[(HT.Toout-2 ) SG.LFR_Tsout+1] ;
        SH.msin=abs(SG.msgen);

        count=0;
        %% Full HSTPP component connected
        while  PTC_Fullplant==1

            for iter_scf=(timestart+1):dt.scf:simu_time_end
                iter_PTC_full=iter_scf;
                iter_PTC_full
                if iter_scf==32338
                    disp('see')
                end
                %%Oil loop
                PTC_scf.Toilin=LT.Toout;                                            %Output of LT goes into PTC=40 oC, So LT-PTC connected

                if  mod(iter_scf,60)==0                                             %After every 60 sec
                    PTC_scf.I= lfr_I_sec(ip1);
                    Ambient_Temp=Ambient_Temp_ind(ip1);
                    if ip1<length(lfr_I_sec)
                        ip1=ip1+1;
                    else
                        count=1;
                        disp('Taking last ip1 value of "lfr_I_sec" which will go to "PTC_scf.I"')
                    end
                end
                HX.Ambient_Tempr=Ambient_Temp;

                %For storing purpose
                OP.I_solar=[OP.I_solar PTC_scf.I];
                OP.Ambient_T=[OP.Ambient_T Ambient_Temp];
                %% Oil Loop

                %Connect PTC
                Tspan=[0  dt.scf];                      %o to 1 second
                options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                [Ts,Y_SCF]=ode15s(@solarfield,Tspan,PTC_SCF.Xintial,options);       %Integrate PTC tank ODEs
                PTC_SCF.Xintial=(Y_SCF(length(Ts),:)');
                PTC_out_temp=PTC_SCF.Xintial(15)                                    %PTC outlet temp

                %need to understand
                if  PTC_SCF.Xintial(PTC_scf.grid) < Temp_set_HT_SH  &&  PTC_HT.Xintial(1) > HT_mass_HTSH  && PTC_LT.Xintial(1) < LT_mass_HTSH_MAX
                    HT.moilout=9;
                else
                    HT.moilout=PTC_scf.moil*3;
                end

                %TO compute energy for PTC
                [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);
                E_ptc_num=E_ptc_num+1;

                %Connect full plant
                [HT_out_temp,LT_out_temp]=PTC_HT_SH_SG_PH_LT_connection(Tspan);

                %For storing purpose
                POW.ms_SG(iter_scf+1)=SG.msgen;
                POW.ms_turb(iter_scf+1)=0+SG.msgen;                        %Total Mass flow rate of steam
                POW.Ts_turb(iter_scf+1)=HX.SHintial(2);

                %Power generation   %Taken reference from Desai paper
                POWeT.Tot_ms=-0.263+(0.668*POW.ms_turb(iter_scf+1));
                POWei.oil_ms=-0.263+(0.668*SG.msgen );
                pow_PTC= POWei.oil_ms;                                              
                POWeT.CP=0.4+0.15*4;                                                %4 MPa pressure.. 40 bar converted to Mpa
                POWeT.temp=0.125+0.0025*POW.Ts_turb(iter_scf+1);
                POWeT.powgen(iter_scf+1)=POWeT.Tot_ms*POWeT.CP*POWeT.temp;

                if  POWeT.powgen(iter_scf+1) >0
                    POWeT_pos_pow.powgen(xx)=POWeT.powgen(iter_scf+1);
                    xx=xx+1;
                else
                    POWeT_pos_pow.powgen(xx)=0;
                    xx=xx+1;
                end
                Xax.POW=[Xax.POW iter_scf];                                         %Storing iter_scf at Xax.POW

                TW_in_HX(iter_scf+1)=HX.Twin;                                   %Temp of water in to Heat exchanger

                %For stroign purpose
                PH.sav_mwin(iter_scf+1)=PH.mwin;                                %Mass of water in to PH
                SG.sav_mwin(iter_scf+1)=SG.mwin;                                %Mass of water in to SG
                HX.sav_mwin(iter_scf+1)=HX.mwin;                                %Mass of water in to HX
               
                %TO compute energy
                [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);
                E_ptc_num=E_ptc_num+1;

                Xaxis=[Xaxis  iter_scf];
                OP.SCF=[OP.SCF  PTC_SCF.Xintial];                                   %Store PTC temp
                OP.HT_Temp=[OP.HT_Temp HT_out_temp];
                OP.LT_Temp=[OP.LT_Temp LT_out_temp];

                %OP.SCF1=[OP.SCF1  PTC_SCF.Xintial];
                OP.HT=[OP.HT PTC_HT.Xintial];
                OP.LT=[OP.LT PTC_LT.Xintial];
                if SH.ODE==1
                    OP.SH=[OP.SH  HX.SHintial];
                    OP.sh_tsout=[OP.sh_tsout SH.Tsout];             %TO store steam outlet temp of SH
                    Xa.X_SH=[Xa.X_SH iter_scf];
                    Tur.msin=[Tur.msin SH.msin];                                    %Mass flow rate of steam out from SH and going in to Turbine
                    OP.SHuaf=[OP.SHuaf SH.UAF];
                    OP.SHhtube=[OP.SHhtube  SH.htctube];
                    OP.SHhshell=[OP.SHhshell SH.htcshell];
                    OP.SHF=[OP.SHF SH.htcF];
                    OP.SHU=[OP.SHU SH.htcU];
                    Xa.X_SH_U=[Xa.X_SH_U iter_scf];
                end

                if PH.ODE==1
                    OP.PH=[OP.PH  HX.PHintial];
                    OP.ph_twout=[OP.ph_twout PH.Twout];             %TO store water outlet temp of PH
                    Xa.X_PH=[Xa.X_PH iter_scf];
                end

                if SG.ODE==1
                    OP.SG_temp=[OP.SG_temp HX.SGintial(1)];
                    OP.SGTw=[OP.SGTw SG.Twater];         %steam or water temp of SG
                    OP.Tsteam=[OP.Tsteam SG.Twater];
                    XA.X_SG=[XA.X_SG iter_scf];
                    OP.SGmsgen=[OP.SGmsgen SG.msgen];
                    OP.SG_pressure=[OP.SG_pressure HX.SGintial(6)];   
                end
                
                pow_PTC_arr=[pow_PTC_arr pow_PTC];             %power generation from PTC

                %%

                %Condition for Stop the plant for type 0 i.e. for constant solar radiation
                if Type==0
                    if iter_scf>=(simu_time_end-1)%32339 instead of 32399
                        break_time_stop=1;
                        day_count=day_count+1;
                        note_time_day_end=[note_time_day_end iter_scf];                      
                        iter_scf_1=iter_scf +4*3600;                            %iter_scf is the just before stop the plant. iter_scf_1 is 4 hrs after the plant stops. (Both in seconds)                    
                        ip2=ip1+(4*60);                                         %ip2 is basically updated ip1 after 4 hrs. (ip1 updated after every 60 sec)
                        simulation_night=1;                                     %Nighttime cooling will start
                        break_time_stop=1;
                        break  
                    end
                else
                    %Condition for Stop the plant for other than type 0
                    if (PTC_SCF.Xintial(PTC_scf.grid)) < 300 &&  HT.Toout < 300
                        bypass_plant=bypass_plant+1; %Need to understand

                        if  bypass_plant==2
                        end
                        if  bypass_plant >300  %5 min repeated
                            day_count=day_count+1;
                            note_time_day_end=[note_time_day_end iter_scf];
                            iter_scf_1=(iter_scf +1)+2*3600;                        %iter_scf is the just before stop the plant. iter_scf_1 is 4 hrs after the plant stops. (Both in seconds)
                            ip2=ip1+(4*60);                                         %ip2 is basically updated ip1 after 4 hrs. (ip1 updated after every 60 sec)
                            simulation_night=1;                                     %Nighttime cooling will start
                            break_time_stop=1;
                            break       
                        end
                    else
                        note_time_day_end=[note_time_day_end iter_scf];
                        iter_scf_1=(iter_scf +1)+2*3600;
                        ip2=ip1+(4*60);                                         %ip2 is basically updated ip1 after 4 hrs. (ip1 updated after every 60 sec)
                        simulation_night=1;
                    end
                end
            end

            %Before night time cooling temperature
            Before_Night_time_SG=[Before_Night_time_SG SG.press  SG.Mw  SG.Msteam  SG.Twater];
            % Before_Night_time_SD=[Before_Night_time_SD Drum.press Drum.Mass_wat Drum.Mass_steam Drum.Temp_wat];
            Before_Night_time_Tank=[Before_Night_time_Tank  HT.Toout  LT.Toout];
            Before_Night_time_HX=[Before_Night_time_HX HX.PHintial(2)  HX.SHintial(1)];

            %Night time coolong function call
            [ip3]=Nighttime_cooling_Oil_only(iter_scf_1, ip2, simulation_night, note_time_day_end,note_time_next_start);

            %After night time cooling temperature
            After_Night_time_SG=[After_Night_time_SG SG.press  SG.Mw  SG.Msteam  SG.Twater];
            %After_Night_time_SD=[After_Night_time_SD Drum.press Drum.Mass_wat Drum.Mass_steam Drum.Temp_wat];
            After_Night_time_Tank=[After_Night_time_Tank  HT.Toout  LT.Toout];
            After_Night_time_HX=[After_Night_time_HX HX.PHintial(2)  HX.SHintial(1)];

            if  break_time_stop==1
                disp('breaktime_stop=1')
                PTC_Fullplant=0;
                break   %it will jump to 1372
            end
        end

        %Use to stop the main for loop
        if  break_time_stop==1
            disp('o')
            break  %it will jump to 1382
        end
    end
    Simu_time=toc

    %Time axis converted to Seconds to Hours.
    Xaxis=Xaxis/3600;  %3600 (sec) instant converted to 1 (hr)
    Xa.X_SH=Xa.X_SH/3600;
    XA.X_SG=XA.X_SG/3600;
    Xa.X_PH=Xa.X_PH/3600;

    if Type==0
        save('Day1_over_Oil_Const')
    elseif Type==1
        save('Day1_over_Oil_step')
    elseif Type==2
        save('Day1_over_Oil_Real')
    elseif Type==3
        save('Day1_over_Oil_Quad')
    end
    save('Type.mat','Type')
    %% Call function to plot all figures for Day1: COLD START-UP

    D1=Plot_oil_only(Mode,iter_scf);
    X=1;
    %*******************************************************************************************************************************************************%
    %*******************************************************************************************************************************************************%
    if Type==0
        disp('Cold Startup for Type 0 of the PTC only loop is over')
    elseif Type==1
        disp('Cold Startup for Type 1 of the PTC only loop is over')
    elseif Type==2
        disp('Cold Startup for Type 2 of the PTC only loop is over')
    elseif Type==3
        disp('Cold Startup for Type 3 of the PTC only loop is over')
    end
    %Till here if Startup==1
%%





%***********************************************************************************************************************************************************************%







elseif Startup==2           %For hot startup with predefined coldstartup values

    %% Call function for Day2: HOT START-UP
    Start=1;
    Hot_startup=day2_oil_only(Start);

    %% Call function to plot all figures for Day2: HOT START-UP
    y=1;
    D2=Plot_hotSU_oil_only(y);

    X=1;

    if Type==0
        disp('Hot Startup for Type 0 of the PTC only loop is over')
    elseif Type==1
        disp('Hot Startup for Type 1 of the PTC only loop is over')
    elseif Type==2
        disp('Hot Startup for Type 2 of the PTC only loop is over')
    elseif Type==3
        disp('Hot Startup for Type 3 of the PTC only loop is over')
    end
    % Till here Hot strtup
%%






%***********************************************************************************************************************************************************************%







elseif Startup==3                       %Will perform for both Hot and cold strtup
    tic                                 %To see the total time for the simulation
    for i=1:1:leng_I
        while SG.boiling==0                                                         %When there is no boiling happan

            for iter_scf=timestart:dt.scf:simu_time_end
                iter_scf_oil_loop=iter_scf                                          %To display the iteration no

                % 1. LT-PTC-LT Connection
                PTC_scf.Toilin=LT.Toout;                                            %Output of LT goes into PTC, So LT-PTC connected

                if  mod(iter_scf,60)==0                                             %After every 60 sec
                    PTC_scf.I= lfr_I_sec(ip1);                                      %ip1 takes 1 solar radiation value at a time and will reamins for 60 sec
                    Ambient_Temp=Ambient_Temp_ind(ip1);                             %Ambient Temperature                oC
                    if ip1<length(lfr_I_sec)                                        %Loop for ip1 does not exceed lfr_I_sec size
                        ip1=ip1+1;
                    else
                        %                     break
                        count=1
                    end
                end
                HX.Ambient_Tempr=Ambient_Temp;                                      %HX stands for Heat exchanger

                %For storing purpose
                OP.I_solar=[OP.I_solar PTC_scf.I];                                  %To save the solar radiation
                OP.Ambient_T=[OP.Ambient_T Ambient_Temp];                           %To save the ambient temperature

                %Condition for Bypass HX
                if  PTC_SCF.Xintial(PTC_scf.grid) < 150                             %Output of PTC oil temp < 150
                    PTC_HT_LTalone=1;                                               %PTC, HT, LT form route and bypass rest(HX)
                else
                    PTC_HT_LTalone=0;                                               %PTC,HT,LT not alone, HX added
                end

                if PTC_HT_LTalone==1                                                %PTC, HT, LT form route and bypass rest,PTC op temp<150
                    %% Oil loop

                    %Connect PTC
                    Tspan=[0  dt.scf];                                              %o to 1 second
                    options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                    [Ts,Y_SCF]=ode15s(@solarfield,Tspan,PTC_SCF.Xintial,options);   %Integrate PTC tank ODEs
                    PTC_SCF.Xintial=(Y_SCF(length(Ts),:)');
                    PTC_out_temp=PTC_SCF.Xintial(15)                                %PTC outlet temp

                    if (HT.Toout<= PTC_SCF.Xintial(PTC_scf.grid))                   %If 40 oC (HT initial temp) <= Oil output temp of PTC
                        %Connect PTC-HT-LT
                        PTC_HT_OD=1;                                                %Then connect HT with PTC together and LT
                        PTC_LT_OD=0;
                        [HT_out_temp,LT_out_temp]=PTC_HT_LT_connection(Tspan);      %Calling function file with connection of PTC-HT-LT
                    else
                        %Connect PTC-LT
                        PTC_LT_OD=1;                                                %Connect PTC with LT only when HT temp >PTC outlet
                        PTC_HT_OD=0;
                        [LT_out_temp]=PTC_LT_connection(Tspan);                     %%Calling function file with connection of PTC-LT

                    end

                    %TO compute energy from PTC
                    [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);              %Function file calling for energy computation from PTC component
                    E_ptc_num=E_ptc_num+1;                                          %Update step
                end

                if PTC_HT_LTalone==0                                                %PTC, HT, LT with SG,PTC op temp>150
                    %% Oil loop

                    %Connect PTC
                    Tspan=[0  dt.scf];                                              %o to 1 second
                    options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                    [Ts,Y_SCF]=ode15s(@solarfield,Tspan,PTC_SCF.Xintial,options);  %Integrate PTC tank ODEs
                    PTC_SCF.Xintial=(Y_SCF(length(Ts),:)');
                    PTC_out_temp=PTC_SCF.Xintial(15)                               %PTC outlet temp

                    %Connect HT with PTC
                    HT.moilin=PTC_scf.moil*3;                                       %Mass of oil out from SCF enters to HT
                    HT.moilout=HT.moilin;                                           %Mass of oil out from HT same as mass of oil in to HT
                    HT.hin=h_oil(PTC_SCF.Xintial(PTC_scf.grid));                    %Enthalpy of oil in to HT

                    if  PTC_HT_OD==1                                                %If HT tank temp <= PTC outlet temp
                        %Connect HT
                        options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                        [Ts,Y_HT]=ode15s(@HTtank,Tspan,PTC_HT.Xintial,options);     %ODE integration of HT
                        PTC_HT.Xintial=(Y_HT(length(Ts),:)');

                        HT.hout=PTC_HT.Xintial(2);                                  %Enthalpy of oil coming out from HT

                        HT.Toout=(-1.49681+sqrt(1.49681^2-4*0.0014*(-18.17454-HT.hout)))/(2*0.0014);   %At current enthalpy HT output temperature
                        HT_out_temp=HT.Toout;                                       %For saving HT outlet Temp

                        %Connect HT with SG_Subcooled
                        SG.moil=HT.moilout;                                         %The mass of oil coming from HT goes into SG
                        SG.Toilin=HT.Toout;                                         %Temp of oil to SG=HT temp of oil out
                    else
                        %Connect HT with SG_Subcooled
                        SG.moil=PTC_scf.moil*3;                                     %Mass of oil out from SCF enters to SG (When HT not conected)
                        SG.Toilin=PTC_SCF.Xintial(PTC_scf.grid);                    %Outlet of SCF connected to SG
                    end

                    %At 1 bar saturation enthalpy of water is 417.44 kJ/kg (Check unit)
                    SG.Wsat=XSteam('hL_p',SG.press_int);                            %SG.press_int=1bar pressure at SG, which is saturation pressure of water.
                    check_Wsat_SG=(SG.Wsat-HX.SGintial(5));                         %HX.SGintial(5)=Current enthalpy

                    if  (check_Wsat_SG <=0)                                         %So if saturation enthalpy is zero/-ve then saturation will occure.
                        disp('Saturation occured');
                    else
                        %Connect SG_Subcooled: Here SG subcooled means no boiling happan till now, saturation has not occured yet
                        options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                        [Ts,Y_HXSG]=ode15s(@HXSG_subcool,Tspan,HX.SGintial,options);%HXSG_subcool will be connected till SG pressure reach setopint pressure
                        HX.SGintial=(Y_HXSG(length(Ts),:)');
                        SG.ODE=1;
                    end

                    %To store the variables
                    OP.SGuaf=[OP.SGuaf SG.UAF];                                     %To store Final UAF
                    OP.SGhtube=[OP.SGhtube  SG.htctube];                            %To store heat transfer coefficient of tube side
                    OP.SGhshell=[OP.SGhshell SG.htcshell];                          %TO store heat transfer coefficient of shell side
                    OP.SGF=[OP.SGF SG.htcF];                                        %To store correction factor
                    OP.SGU=[OP.SGU SG.htcU];                                        %TO store overall heat transfer coefficient

                    %Connect LT with SG
                    LT.moilin=SG.moil;                                              %LT mass of oil comes from SG
                    LT.moilout=LT.moilin;                                           %Mass of oil out from LT same as mass of oil in to LT

                    if iter_scf==1          %Why
                        LT.hin=h_oil(((HT.Tintial+LT.Tintial)/2)-1);                %Why like this??
                    else
                        LT.hin=h_oil(HX.SGintial(1));                               %Enthalpy of oil in to LT is calculated at SG output temperature.
                    end
 
                    options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                    [Ts,Y_LT]=ode15s(@LTtank,Tspan,PTC_LT.Xintial,options);         %Integrating LT tank ODEs
                    PTC_LT.Xintial=(Y_LT(length(Ts),:)');

                    LT.hout=PTC_LT.Xintial(2);                                      %Enthalpy of oil out from LT

                    %Enthalpy polynomial fit equation:
                    LT.Toout=(-1.49681+sqrt(1.49681^2-4*0.0014*(-18.17454-LT.hout)))/(2*0.0014);    %LT outlet temperature
                    LT_out_temp= LT.Toout;                                                          %LT temperature output

                    %LT again connected to PTC-
                    PTC_SCF.Xintial(1)=LT.Toout;                                    %LT temperature output is going to PTC inlet

                    %TO compute energy
                    [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);              %Function file calling for energy compute from PTC
                    E_ptc_num=E_ptc_num+1;                                          %Update step

                    POWeT.powgen(iter_scf+1)=0;

                    %For power generation value positive
                    if  POWeT.powgen(iter_scf+1) >0
                        POWeT_pos_pow.powgen(xx)=POWeT.powgen(iter_scf+1);
                        xx=xx+1;
                    else
                        POWeT_pos_pow.powgen(xx)=0;
                        xx=xx+1;
                    end
                    Xax.POW=[Xax.POW iter_scf];                                     %Storing iter_scf at Xax.POW

                    %For Storing purpose
                    POW.ms_SG(iter_scf+1)=SG.msgen;                                 %To store the value of SG mass of steam generated
                    POW.Ts_turb(iter_scf+1)=HX.SHintial(2);                         %To store the value of temp of steam going out from Sh to turbine
                    TW_in_HX(iter_scf+1)=HX.Twin;                                   %To store the value of Temp of water in to Heat exchanger

                    OP_TTsteam=XSteam('Tsat_p',SG.press_int);
                    OP.Tsteam=[OP.Tsteam OP_TTsteam ];                              %Storing OP_TTsteam

                    SG.mwin=HX.mwin;                                                %Mass of water going in to Sg
                    PH.mwin=HX.mwin;                                                %Mass of water going in to PH
                    %For stroign purpose
                    PH.sav_mwin(iter_scf+1)=PH.mwin;                                %Mass of water in to PH
                    SG.sav_mwin(iter_scf+1)=SG.mwin;                                %Mass of water in to SG
                    HX.sav_mwin(iter_scf+1)=HX.mwin;                                %Mass of water in to HX

                    %TO compute energy
                    [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);
                    E_ptc_num=E_ptc_num+1;
                end

                %FOr storing purpose
                Xaxis=[Xaxis  iter_scf];
                OP.SCF=[OP.SCF  PTC_SCF.Xintial];                                   %Store PTC temp

                OP.HT_Temp=[OP.HT_Temp HT_out_temp];                                %Store HT temp
                                  
                OP.LT_Temp=[OP.LT_Temp LT_out_temp];                                %Store LT temp
                if SH.ODE==1
                    OP.SH=[OP.SH  HX.SHintial];
                    Xa.X_SH=[Xa.X_SH iter_scf];
                    OP.sh_tsout=[OP.sh_tsout SH.Tsout];             %TO store steam outlet temp of SH
                    Tur.msin=[Tur.msin SH.msin];
                    OP.SHuaf=[OP.SHuaf SH.UAF];
                    OP.SHhtube=[OP.SHhtube  SH.htctube];
                    OP.SHhshell=[OP.SHhshell SH.htcshell];
                    OP.SHF=[OP.SHF SH.htcF];
                    OP.SHU=[OP.SHU SH.htcU];
                    Xa.X_SH_U=[Xa.X_SH_U iter_scf];
                end

                if SG.ODE==1
                    OP.SG_temp=[OP.SG_temp HX.SGintial(1)];
                    OP.SGTw=[OP.SGTw SG.Twater];
                    XA.X_SG=[XA.X_SG iter_scf];
                    OP.SGmsgen=[OP.SGmsgen SG.msgen];
                    OP.SG_pressure=[OP.SG_pressure HX.SGintial(6)];
                end

                pow_PTC_arr=[pow_PTC_arr pow_PTC];              %power generation from PTC

                SG.Wsat=XSteam('hL_p',SG.press_int);                                %To check saturated liquid enthalpy
                check_Wsat_SG=(SG.Wsat-HX.SGintial(5));
                if  (check_Wsat_SG <=0 )
                    disp('Saturation Occured');
                    HX.SGintial(5)=SG.Wsat; %----correction to have equal value of satu enthalphy  ??
                    SG.boiling=1;
                    break
                end
            end
        end

        timestart=Xaxis(end);
        SG.msgen=0;% intial value
        while (SG.boiling==1  && PTC_Fullplant==0)

            for iter_scf=(timestart+1):dt.scf:simu_time_end
                boil_loop=iter_scf

                %% Oil loop

                % 1. LT-PTC-LT Connection
                PTC_scf.Toilin=LT.Toout;                                            %Output of LT goes into PTC=40 oC, So LT-PTC connected

                if  mod(iter_scf,60)==0                                             %After every 60 sec
                    PTC_scf.I= lfr_I_sec(ip1);
                    Ambient_Temp=Ambient_Temp_ind(ip1);
                    if ip1<length(lfr_I_sec)
                        ip1=ip1+1;
                    else
                        break
                    end
                end
                HX.Ambient_Tempr=Ambient_Temp;

                %For storing purpose
                OP.I_solar=[OP.I_solar PTC_scf.I];
                OP.Ambient_T=[OP.Ambient_T Ambient_Temp];

                %Connect PTC
                Tspan=[0  dt.scf];                      %o to 1 second
                options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                [Ts,Y_SCF]=ode15s(@solarfield,Tspan,PTC_SCF.Xintial,options);       %Integrate PTC tank ODEs
                PTC_SCF.Xintial=(Y_SCF(length(Ts),:)');
                PTC_out_temp=PTC_SCF.Xintial(15)                                    %PTC outlet temp

                %Connect HT with PTC
                HT.moilin=PTC_scf.moil*3;                                           %WHy not given in sir code
                HT.moilout=HT.moilin;
                HT.hin=h_oil(PTC_SCF.Xintial(PTC_scf.grid));

                if PTC_HT_OD==1
                    options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                    [Ts,Y_HT]=ode15s(@HTtank,Tspan,PTC_HT.Xintial,options);
                    PTC_HT.Xintial=(Y_HT(length(Ts),:)');

                    HT.hout=PTC_HT.Xintial(2);
                    opts = optimset('TolFun',1e-12,'Display','off') ;

                    HT.Toout=(-1.49681+sqrt(1.49681^2-4*0.0014*(-18.17454-HT.hout)))/(2*0.0014);
                    HT_out_temp=HT.Toout;

                    %Connect HT with SG_Subcooled
                    SG.moil=HT.moilout;
                    
                    SG.Toilin=HT.Toout;                                             %Temp of oil to SG=HT temp of oil out
                else
                    SG.moil=HT.moilout;
                    SG.Toilin=PTC_SCF.Xintial(PTC_scf.grid);
                end
                SG.Wsat=XSteam('hL_p',SG.press_int);
                check_Wsat_SG=(SG.Wsat-HX.SGintial(5));
                SG.hs= XSteam('hV_p',HX.SGintial(6));
                SG.hw=XSteam('hL_p',HX.SGintial(6));

                %Connect SG_Saturated
                options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                [Ts,Y_HXSG]=ode15s(@HXSG_sat,Tspan,HX.SGintial,options);
                HX.SGintial=(Y_HXSG(length(Ts),:)');
                SG_pressure=HX.SGintial(6)
                SG.ODE=1;

                %To check is there any imaginary part
                nedstop=isreal(HX.SGintial );
                if (nedstop)==0   %has img part
                    disp('Imaginary number in HX.SGintial')
                end

                %To store the variables
                OP.SGuaf=[OP.SGuaf SG.UAF];
                OP.SGhtube=[OP.SGhtube  SG.htctube];
                OP.SGhshell=[OP.SGhshell SG.htcshell];
                OP.SGF=[OP.SGF SG.htcF];
                OP.SGU=[OP.SGU SG.htcU];

                %Connect LT with SG
                LT.moilin=SG.moil;  %Not in sir code why
                LT.moilout=LT.moilin;

                LT.hin=h_oil(HX.SGintial(1));

                options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                [Ts,Y_LT]=ode15s(@LTtank,Tspan,PTC_LT.Xintial,options);
                PTC_LT.Xintial=(Y_LT(length(Ts),:)');

                LT.hout=PTC_LT.Xintial(2);

                LT.Toout=(-1.49681+sqrt(1.49681^2-4*0.0014*(-18.17454-LT.hout)))/(2*0.0014);
                LT_out_temp=LT.Toout;

                PTC_SCF.Xintial(1)=LT.Toout;

                %TO compute energy
                [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);
                E_ptc_num=E_ptc_num+1;

                POWeT.powgen(iter_scf+1)=0;

                if  POWeT.powgen(iter_scf+1) >0
                    POWeT_pos_pow.powgen(xx)=POWeT.powgen(iter_scf+1);
                    xx=xx+1;
                else
                    POWeT_pos_pow.powgen(xx)=0;
                    xx=xx+1;
                end
                Xax.POW=[Xax.POW iter_scf];                                         %Storing iter_scf at Xax.POW

                OP.Tsteam=[OP.Tsteam SG.Twater]; %WHY                                 %Storing OP_TTsteam

                SG.mwin=HX.mwin;                                                    %Mass of water going in to Sg
                PH.mwin=HX.mwin;                                                    %Mass of water going in to PH

                %For storing purpose
                PH.sav_mwin(iter_scf+1)=PH.mwin;                                    %Mass of water in to PH
                SG.sav_mwin(iter_scf+1)=SG.mwin;                                    %Mass of water in to SG
                HX.sav_mwin(iter_scf+1)=HX.mwin;                                    %Mass of water in to HX
               
                POW.ms_SG(iter_scf+1)=SG.msgen;
                POW.Ts_turb(iter_scf+1)=HX.SHintial(2);

                TW_in_HX(iter_scf+1)=HX.Twin;                                   %Temp of water in to Heat exchanger

                %TO compute energy
                [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);
                E_ptc_num=E_ptc_num+1;

                %For storing purpose
                OP.SCF=[OP.SCF  PTC_SCF.Xintial];                                   %Store PTC temp
                OP.HT_Temp=[OP.HT_Temp HT_out_temp];                                %Store HT temp
                OP.LT_Temp=[OP.LT_Temp LT_out_temp];                                %Store LT temp
                if SH.ODE==1
                    OP.SH=[OP.SH  HX.SHintial];
                    Xa.X_SH=[Xa.X_SH iter_scf];
                    OP.sh_tsout=[OP.sh_tsout SH.Tsout];             %TO store steam outlet temp of SH
                    Tur.msin=[Tur.msin SH.msin];
                    OP.SHuaf=[OP.SHuaf SH.UAF];
                    OP.SHhtube=[OP.SHhtube  SH.htctube];
                    OP.SHhshell=[OP.SHhshell SH.htcshell];
                    OP.SHF=[OP.SHF SH.htcF];
                    OP.SHU=[OP.SHU SH.htcU];
                    Xa.X_SH_U=[Xa.X_SH_U iter_scf];
                end
 
                if SG.ODE==1
                    OP.SG_temp=[OP.SG_temp HX.SGintial(1)];
                    OP.SGTw=[ OP.SGTw SG.Twater];
                    XA.X_SG=[XA.X_SG iter_scf];
                    OP.SGmsgen=[OP.SGmsgen SG.msgen];
                    OP.SG_pressure=[OP.SG_pressure HX.SGintial(6)];
                end

                Xaxis=[Xaxis  iter_scf];
                pow_PTC_arr=[pow_PTC_arr pow_PTC];             %power generation from PTC

                if  HX.SGintial(6)>=SG.press_st
                    disp('pressure reached');
                    pressure_now=HX.SGintial(6)
                    PTC_Fullplant=1;
                    break
                end
            end
        end

        timestart=Xaxis(end);
        disp('SG Pressure reached 40bar, Now Full plant will work')

        %Saturated vapour enthalpy w.r.t pressure at SG
        SG.hs_steam= XSteam('hV_p',HX.SGintial(6));

        SG.LFR_Tsout=SG.Twater;

        mix_sh_intial=[0 0];

        HX.Twin=(SG.Twater/250)*75; 
        SG.Twin=HX.Twin;
        HX.PHintial=[HX.Twin+1 HX.SGintial(1)-1];

        HX.SHintial=[(HT.Toout-2 ) SG.LFR_Tsout+1] ;
        SH.msin=abs(SG.msgen);

        count=0;
        %% Full HSTPP component connected
        while  PTC_Fullplant==1

            for iter_scf=(timestart+1):dt.scf:simu_time_end
                iter_PTC_full=iter_scf;
                iter_PTC_full
                if iter_scf==32338
                    disp('see')
                end
                %%Oil loop
                PTC_scf.Toilin=LT.Toout;                                            %Output of LT goes into PTC=40 oC, So LT-PTC connected

                if  mod(iter_scf,60)==0                                             %After every 60 sec
                    PTC_scf.I= lfr_I_sec(ip1);
                    Ambient_Temp=Ambient_Temp_ind(ip1);
                    if ip1<length(lfr_I_sec)
                        ip1=ip1+1;
                    else
                        count=1;
                        disp('Taking last ip1 value of "lfr_I_sec" which will go to "PTC_scf.I"')
                    end
                end
                HX.Ambient_Tempr=Ambient_Temp;

                %For storing purpose
                OP.I_solar=[OP.I_solar PTC_scf.I];
                OP.Ambient_T=[OP.Ambient_T Ambient_Temp];
                %% Oil Loop

                %Connect PTC
                Tspan=[0  dt.scf];                      %o to 1 second
                options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                [Ts,Y_SCF]=ode15s(@solarfield,Tspan,PTC_SCF.Xintial,options);       %Integrate PTC tank ODEs
                PTC_SCF.Xintial=(Y_SCF(length(Ts),:)');
                PTC_out_temp=PTC_SCF.Xintial(15)                                    %PTC outlet temp

                %need to understand
                if  PTC_SCF.Xintial(PTC_scf.grid) < Temp_set_HT_SH  &&  PTC_HT.Xintial(1) > HT_mass_HTSH  && PTC_LT.Xintial(1) < LT_mass_HTSH_MAX
                    %SP_HT_LT_SH=2;
                    HT.moilout=9;
                else
                    %SP_HT_LT_SH=1;
                    HT.moilout=PTC_scf.moil*3;
                end

                %TO compute energy for PTC
                [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);
                E_ptc_num=E_ptc_num+1;

                %Connect full plant
                [HT_out_temp,LT_out_temp]=PTC_HT_SH_SG_PH_LT_connection(Tspan);

                %For storing purpose
                POW.ms_SG(iter_scf+1)=SG.msgen;
                % POW.LFR(iter_scf+1)=Drum.msout;
                POW.ms_turb(iter_scf+1)=0+SG.msgen;                        %Total Mass flow rate of steam
                POW.Ts_turb(iter_scf+1)=HX.SHintial(2);

                %Power generation   %Taken reference from Desai paper
                POWeT.Tot_ms=-0.263+(0.668*POW.ms_turb(iter_scf+1));
                POWei.oil_ms=-0.263+(0.668*SG.msgen );
                pow_PTC= POWei.oil_ms;                                              %Not used anywhere
                POWeT.CP=0.4+0.15*4;                                                %4 MPa pressure.. 40 bar converted to Mpa
                POWeT.temp=0.125+0.0025*POW.Ts_turb(iter_scf+1);
                POWeT.powgen(iter_scf+1)=POWeT.Tot_ms*POWeT.CP*POWeT.temp;

                if  POWeT.powgen(iter_scf+1) >0
                    POWeT_pos_pow.powgen(xx)=POWeT.powgen(iter_scf+1);
                    xx=xx+1;
                else
                    POWeT_pos_pow.powgen(xx)=0;
                    xx=xx+1;
                end
                Xax.POW=[Xax.POW iter_scf];                                         %Storing iter_scf at Xax.POW

                TW_in_HX(iter_scf+1)=HX.Twin;                                   %Temp of water in to Heat exchanger

                %For stroign purpose
                PH.sav_mwin(iter_scf+1)=PH.mwin;                                %Mass of water in to PH
                SG.sav_mwin(iter_scf+1)=SG.mwin;                                %Mass of water in to SG
                HX.sav_mwin(iter_scf+1)=HX.mwin;                                %Mass of water in to HX

                %TO compute energy
                [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);
                E_ptc_num=E_ptc_num+1;

                Xaxis=[Xaxis  iter_scf];
                OP.SCF=[OP.SCF  PTC_SCF.Xintial];                                   %Store PTC temp
                OP.HT_Temp=[OP.HT_Temp HT_out_temp];
                OP.LT_Temp=[OP.LT_Temp LT_out_temp];

                %OP.SCF1=[OP.SCF1  PTC_SCF.Xintial];
                OP.HT=[OP.HT PTC_HT.Xintial];
                OP.LT=[OP.LT PTC_LT.Xintial];
                if SH.ODE==1
                    OP.SH=[OP.SH  HX.SHintial];
                    OP.sh_tsout=[OP.sh_tsout SH.Tsout];             %TO store steam outlet temp of SH
                    Xa.X_SH=[Xa.X_SH iter_scf];
                    Tur.msin=[Tur.msin SH.msin];                                    %Mass flow rate of steam out from SH and going in to Turbine
                    OP.SHuaf=[OP.SHuaf SH.UAF];
                    OP.SHhtube=[OP.SHhtube  SH.htctube];
                    OP.SHhshell=[OP.SHhshell SH.htcshell];
                    OP.SHF=[OP.SHF SH.htcF];
                    OP.SHU=[OP.SHU SH.htcU];
                    Xa.X_SH_U=[Xa.X_SH_U iter_scf];
                end

                if PH.ODE==1
                    OP.PH=[OP.PH  HX.PHintial];
                    OP.ph_twout=[OP.ph_twout PH.Twout];             %TO store water outlet temp of PH
                    Xa.X_PH=[Xa.X_PH iter_scf];
                    %                 ph_twout=[ph_twout PH.Twout];   %To store water outlet temp of PH

                end

                if SG.ODE==1
                    OP.SG_temp=[OP.SG_temp HX.SGintial(1)];
                    OP.SGTw=[OP.SGTw SG.Twater];         %steam or water temp of SG
                    OP.Tsteam=[OP.Tsteam SG.Twater];
                    XA.X_SG=[XA.X_SG iter_scf];
                    OP.SGmsgen=[OP.SGmsgen SG.msgen];
                    OP.SG_pressure=[OP.SG_pressure HX.SGintial(6)];
                end

                %pow_LFR_arr=[pow_LFR_arr pow_LFR];              %power generation from LFR
                pow_PTC_arr=[pow_PTC_arr pow_PTC];             %power generation from PTC

                %%

                %Condition for Stop the plant for type 0 i.e. for constant solar radiation
                if Type==0
                    if iter_scf>=(simu_time_end-1)%32339 instead of 32399
                        break_time_stop=1;
                        day_count=day_count+1;
                        note_time_day_end=[note_time_day_end iter_scf];
                        iter_scf_1=iter_scf +4*3600;                            %iter_scf is the just before stop the plant. iter_scf_1 is 4 hrs after the plant stops. (Both in seconds)
                        ip2=ip1+(4*60);                                         %ip2 is basically updated ip1 after 4 hrs. (ip1 updated after every 60 sec)
                        simulation_night=1;                                     %Nighttime cooling will start
                        break_time_stop=1;
                        break  
                    end
                else
                    %Condition for Stop the plant for other than type 0
                    if (PTC_SCF.Xintial(PTC_scf.grid)) < 300 &&  HT.Toout < 300
                        bypass_plant=bypass_plant+1; %Need to understand

                        if  bypass_plant==2
                        end
                        if  bypass_plant >300     %5 min repeated
                            day_count=day_count+1;
                            note_time_day_end=[note_time_day_end iter_scf];
                            iter_scf_1=(iter_scf +1)+2*3600;                            %iter_scf is the just before stop the plant. iter_scf_1 is 4 hrs after the plant stops. (Both in seconds)
                            ip2=ip1+(4*60);                                         %ip2 is basically updated ip1 after 4 hrs. (ip1 updated after every 60 sec)
                            simulation_night=1;                                     %Nighttime cooling will start
                            break_time_stop=1;
                            break       
                        end
                    else
                        note_time_day_end=[note_time_day_end iter_scf];
                        iter_scf_1=(iter_scf +1)+2*3600;
                        ip2=ip1+(4*60);                                         %ip2 is basically updated ip1 after 4 hrs. (ip1 updated after every 60 sec)
                        simulation_night=1;
                    end
                end
            end

            %Before night time cooling temperature
            Before_Night_time_SG=[Before_Night_time_SG SG.press  SG.Mw  SG.Msteam  SG.Twater];
            % Before_Night_time_SD=[Before_Night_time_SD Drum.press Drum.Mass_wat Drum.Mass_steam Drum.Temp_wat];
            Before_Night_time_Tank=[Before_Night_time_Tank  HT.Toout  LT.Toout];
            Before_Night_time_HX=[Before_Night_time_HX HX.PHintial(2)  HX.SHintial(1)];

            %Night time coolong function call
            [ip3]=Nighttime_cooling_Oil_only(iter_scf_1, ip2, simulation_night, note_time_day_end,note_time_next_start);

            %After night time cooling temperature
            After_Night_time_SG=[After_Night_time_SG SG.press  SG.Mw  SG.Msteam  SG.Twater];
            After_Night_time_Tank=[After_Night_time_Tank  HT.Toout  LT.Toout];
            After_Night_time_HX=[After_Night_time_HX HX.PHintial(2)  HX.SHintial(1)];

            if  break_time_stop==1
                disp('breaktime_stop=1')
                PTC_Fullplant=0;
                break   
            end
        end
        %Use to stop the main for loop
        if  break_time_stop==1
            disp('o')
            break 
        end
    end
    Simu_time=toc

    %Time axis converted to Seconds to Hours.
    Xaxis=Xaxis/3600;  %3600 (sec) instant converted to 1 (hr)
    Xa.X_SH=Xa.X_SH/3600;
    XA.X_SG=XA.X_SG/3600;
    Xa.X_PH=Xa.X_PH/3600;

    if Type==0
        save('Day1_over_Oil_Const')
    elseif Type==1
        save('Day1_over_Oil_step')
    elseif Type==2
        save('Day1_over_Oil_Real')
    elseif Type==3
        save('Day1_over_Oil_Quad')
    end
    save('Type.mat','Type')
    %% Call function to plot all figures for Day1: COLD START-UP

    D1=Plot_oil_only(Mode,iter_scf);

    %*******************************************************************************************************************************************************%
    %*******************************************************************************************************************************************************%

    disp('Day 1 over')
    %% Call function for Day2: HOT START-UP
    Start=1;
    Hot_startup=day2_oil_only(Start);

    %%
    %Call function to plot all figures for Day2: HOT START-UP
    y=1;
    D2=Plot_hotSU_oil_only(y);
    
    if Type==0
        disp('Cold+Hot Startup for Type 0 of the PTC only loop is over')
    elseif Type==1
        disp('Cold+Hot Startup for Type 1 of the PTC only loop is over')
    elseif Type==2
        disp('Cold+Hot Startup for Type 2 of the PTC only loop is over')
    elseif Type==3
        disp('Cold+Hot Startup for Type 3 of the PTC only loop is over')
    end

    X=1;
end
end

% ******************************************* END ***********************************************%