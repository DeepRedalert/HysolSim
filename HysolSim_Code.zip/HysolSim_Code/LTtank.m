%% LT storage tank function file

%%
function [dT_LT] =LTtank(t,T)

global LT
global PTC_LT_OD


%T(1)=Mass of oil present in LT
%T(2)=Enthalpy of oil flowing out of LT


if  PTC_LT_OD==0
    Maccumulation_LT=0;         %Mass accumulation in LT
    dh_LT_tank=0;               %Enthalpy of oil flowing out of LT
else
    Maccumulation_LT=LT.moilin-LT.moilout;     %Mass accumulation in LT, Equation 15a in IECER paper
    %Total_Mass_LT=LT.int_Mass+Maccumulation_LT;    
    enthalpy_LT=T(2);                           %Enthalpy of oil flowing out of LT    
    dh_LT_tank=(((LT.moilin*LT.hin)-(LT.moilout*enthalpy_LT)-(enthalpy_LT*(LT.moilin-LT.moilout)))/T(1));   %Enthalpy of oil flowing out of LT, equation 15b in IECER paper
    %Not matching with equation, loss term not here
end
dT_LT=[Maccumulation_LT  dh_LT_tank]';
end
