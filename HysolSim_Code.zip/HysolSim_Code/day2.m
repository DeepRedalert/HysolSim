function Hot_startup=day2(Type)

clear all

global PTC_scf PTC_SCF  steamgen_LFR_bef_PTC PTC_scf_OD PTC_HT_OD w_iter_scf Type LFR_n Mode

global dt stef_const msgenout
global SCF_TF_implic SCF_TA_implic SCF_TE_implic ip3 test Eng_gain_arr_PTC_salt

global HT HX SH SG PH LT
global HT_Mass_implic  HT_Entha_implic

global OP PTC_Fullplant LFRsim  lfr_I_sec
global theta  sin_zero steaystate tim_iter phase_enth

global msgen_drum drum_msgen mwin_dear

global single_scaling two_scaling
global LFR Drum  Dear SD first_LFR_IC iter_scf

global PTC_HT PTC_LT ph_twout sh_tsout shut_cou_sg shut_cou_sd

global U he_supp lfr_press_sec  dru_press_sec hwin_dear   msteam_lfr Two  Two_sec   dea_flo phase_pipeend
global delta_absor dt_par Tabsor_pre hs_drum hp rho P h u T x TAbo  Tglass Ck  hpp Ckk g dpbydt  scfhp LFR_Temp_WAT LFR_msteam

global simulation_complete  shut_HT shut_LT shut_PH shut_SH shut_SG shut_SD SG_night SD_night break_time timestart break_time_stop

global Xa XA  Xax POW POWeT_pos_pow

load Type.mat

if Type==0
    load Day1_over_Const.mat
elseif Type==1
    load Day1_over_Step.mat
elseif Type==2
    load Day1_over_Real.mat
elseif Type==3
    load Day1_over_Quad.mat
end


%% All saved data of Day1(Last day) should be null or removed so that frest 2nd day (Next day) data will only store
%PTC
OP.SCF=[];
Eng_gain_arr_PTC=[];
Eng_gain_arr_PTC1=[];

%HT/LT
OP.LT=[];
OP.HT=[];
OP.LT_Temp=[LT.Toout];
OP.HT_Temp=[HT.Toout];

%SG
OP.SG_pressure=[SG.press];
OP.SGmsgen=[];
OP.SGTw=[SG.Twater];
OP.SG_temp=[];
OP.Tsteam=[];
OP.SGuaf=[];
OP.SGhtube=[];
OP.SGhshell=[];
OP.SGF=[];
OP.SGU=[];
XA.X_SG=[];

%SH/PH
OP.ph_twout=[];
OP.PH=[HX.PHintial];
OP.sh_tsout=[];
OP.SH=[HX.SHintial];
Xa.X_SH=[];
Xa.X_SH_U=[];
Xa.X_PH=[];
Tur.msin=[];
OP.SHU=[];
OP.SHF=[];
OP.SHhshell=[];
OP.SHhtube=[];
OP.SHuaf=[];
OP.PHU=[];
OP.PHF=[];
OP.PHhshell=[];
OP.PHhtube=[];
OP.PHuaf=[];


%LFR
OP.LFR_Temp=[];
Xax.LFR=[];
LFR.IP_mwin=[];
LFR_msteam_out_nos_pipe=[];
LFR_mwater_out_nos_pipe=[];
LFR_temp_fluid=[];
LFRsim=[];
mwin_LFR_indi=[];
mwin_LFR_total=[];
phase_enth=[];
LFR_mwater_out_nos_pipe=[];
LFR_msteam_out_nos_pipe=[];
LFR_temp_fluid=[];%%LFR.Temp_wat        %Output temp of LFR Fluid
Eng_gain_arr_LFR=[];
Eng_gain_arr_LFR1=[];
tim_iter=[];

%SD
OP.Drum_Temp_wat=[];
OP.SDr=[];
Xax.SD=[0];
SD.IP_mwin=[];
SD.IP_mwin_time=[];
drum_hsteam=[Drum.hst*10^-3];
drum_row_st=[];
drum_Vsteam=[Drum.Vsteam];                        %NOT USED
drum_Mass=[Drum.Mass];                            %Total mass
drum_Mass_wat=[Drum.Mass_wat];                    %Mass of water
drum_Mass_steam=[Drum.Mass_steam];                %MAss of steam
drum_pressure=[];                       %Drum pressure=2bar
drum_hwat=[Drum.hwat*10^-3];                          %Enthalpy of water
drum_Twat=[];                        %SD water temp
drum_msgen=[];                          %SD mass of steam generation
drum_ms_out40=[];                       %SD mass of steam going out
Drum.msout=[];
waterin_drum=[];
Drum.mwin_n=[];
Drum.msout_dear=[];
Drum.mwin_n=[];                       %The amount of steam produced and going out=Mass of water in from deareator to maintain the water level
Yax.press_SD=[];
XA.X_SD=[];
Steam_Q_drum=[];
Twin_SD=[];
waterin_drum=[];
waterin_drum=[];%Mass of water in to the drum
Steam_Q_drum=[];                   %Steam quality

%Power
Xax.POW=[];
POW.ms_turb=[];
POW.Ts_turb=[];
pow_LFR_arr=[];
pow_PTC_arr=[];
POWei.lfr_powgen=[];
POWeT.powgen=[];
POWeT_pos_pow.powgen=[];
POW.LFR=[];
pow_LFR_arr=[];
pow_PTC_arr=[];
POW.ms_SG=[];

%Other
OP.I_solar=[];
OP.Ambient_T=[];
Xaxis=[];
Xaxis_water=[];
TW_in_HX=[];
steam_phase=0;
IP_mwin_flag=0;
Twin_SD_axis=[];
phase=0;
Xax.SD_steam=[0];
drum_Tsteam=[];
%% Initialization
time_run=1;
xx=1;
Drum.msout(1)=0;
waterin_drum(1)=0;
Drum.mwin_n(1)=0;
Drum.msout_dear(1)=0;
LFR_n=0;
drum_Twat(1)=Drum.Temp_wat;
drum_Tsteam(1)=Drum.temp_steam;
Mass_steam_SD=0;
%% Second day simulation start ______ Initial condition for secnd day simulation

%%PTC
Amb_T=Ambient_Temp_ind(ip1);   %ip1=506 min i.e 8hr 43min, so at Amb_T is 506th value of Ambient temp which is basically when plant stop
% As in the morning ambient temp is same as evening temp (Last day evening temp taken)
PTC_SCF.Xintial=[Amb_T*ones(1,PTC_scf.grid)    Amb_T*ones(1,PTC_scf.grid)   Amb_T*ones(1,PTC_scf.grid)]';
PTC_SCF.Xintial1=PTC_SCF.Xintial;
PTC_Fullplant=0;

%% HT Tank
PTC_HT.Xintial(2)=h_oil(HT.Toout);  %Enthalpy of oil at cooldown temp
PTC_HT_OD=0;

%% LT tank
PTC_LT.Xintial(2)=h_oil(LT.Toout);  %Enthalpy of oil at cooldown temp


%% SG
HX.SGintial(2)= SG.Mw ;             %Mass of water (After cooldown)
HX.SGintial(3)= SG.Mw+SG.Msteam;    %Mass of system (After cooldown)
HX.SGintial(4)= SG.Msteam;          %Mass of steam (After cooldown)
SG.press_int=SG.press;              %Cooldown SG pressure as Initial SG pressure for Hot startup
HX.SGintial(5)=XSteam('hL_p',SG.press);%Enthalpy of water at cooldown pressure
HX.SGintial(6)= SG.press;           %SG pressure (after cooldown)
SG.Twin=45;                         %75 oC to 45 oC taken as SG temp of water in
SG.boiling=1;                       %SG water boiling
SG.ODE=0;
SG.Twater= XSteam('Tsat_p',SG.press); %WAter temp at cooldown SG pressure
%% SH
SH.ODE=0;                           %SH not connected
%HX.SHintial=[HX.SHintial(1)-2 XSteam('Tsat_p',Drum.press,Drum.hst*10^-3)];  %HX.SHintial(1): Nighttimne cooling temp. _2 oC is for as day2 at the begening the sh wont start so.
HX.SHintial=[SH.Toilin-2 XSteam('T_ph',Drum.press,Drum.hst*10^-3)];

%% PH
PH.ODE=0;                           %PH not connected

%% LFR

LFR.Twin=HX.Ambient_Tempr;                                  %Ambient temp as LFR inlet temp (45 oC)
LFR.hin=XSteam('h_pT',LFR.Press_in,HX.Ambient_Tempr);       %Enthalpy of Water in to the LFR at amb temp
LFRsim.ha1=LFR.hin*1000;                                    %Specific Enthalpy
LFRsim.Pa1=LFR.Press_in;                                    %%Pressure=45bar (Initialisation)                          bar
LFRsim.rhoa1=XSteam('rho_ph',LFR.Press_in,LFR.hin);         %Density as a function of pressure and enthalpy           kg/m^3
vis_La1=XSteam('my_ph',LFRsim.Pa1,LFRsim.ha1*10^-3);        %Dynamic Viscosity as a function of pressure and enthalpy
LFRsim.Ta1=LFR.Twin;                                        %Temp of water in to LFR (Initial)       0C
volumetric=LFR.mw_indi/LFRsim.rhoa1;                        %volumetric flow rate=Mass flow rate/Density
velocity=(1.2734*volumetric)/(LFR.dia_ab^2);                %Velocity, %V=Q/A or V=(4/pi)*(Q/d^2)
LFRsim.ua1=velocity;                                        %Velocity of the fluid
LFRsim.xa1=LFRsim.rhoa1;                                    %LFRsim.x NOT USED HERE
LFR.Tfluid=LFR.Twin;                                        %Initial temp of water in LFR
LFRsim.Taboa1=LFR.Twin;                                     %Temp of absorber pipe of LFR
LFRsim.phase=0;                                             %No steam prom LFR yet produced
REY=(LFRsim.rhoa1*LFRsim.ua1*LFR.dia_ab)/vis_La1 ;          %Reynolds number
f=ffrough(REY, LFR.dia_ab, 0);                              %Used to calcultae friction no
LFRsim.Cka1=f/(2*LFR.dia_ab);                               %Friction factor
sin_zero=0;
theta=0;
poi=1;
i=1;


for n=time_run:1:LFR.tot_run                                %LFR.tot_run=(hour_s*3600)/LFR.dt;  %Total run is 2880 for 2 days
    for poi=1:1:LFR.points                                  %LFR points 4880 for 10 no of grid points (480*10)
        LFRsim.rho(n,poi)= LFRsim.rhoa1;                    %Density of fluid           kg/m^3
        LFRsim.P(n,poi) = LFRsim.Pa1;                       %Pressure                   bar
        LFRsim.h(n,poi)=LFRsim.ha1;                         %Enthalpy                   J/kg
        LFRsim.u(n,poi)=LFRsim.ua1;                         %Velocity                   m/s
        LFRsim.T(n,poi)= LFRsim.Ta1;                        %Temperature of water       0C
        LFRsim.x(n,poi)=0;
        LFRsim.Ck(n,poi)=LFRsim.Cka1;                       %Friction facotr
        LFRsim.Tabo(n,poi)=LFR.Twin;                        %Temp of absorber pipe      0C
        LFRsim.Tgla(n,poi)=LFR.Tsky;                        %Temp of glass envelope     0C
    end
end

%% SD
Drum.msout=0;                                               %Drum mass of steam out is zero
Drum.Temp_wat= XSteam('Tsat_p',SD.press)-1;                 %At nighttime cooling SD pressure water temp taken (-1 oC is for loss)
Drum.hst=XSteam('hV_p',SD.press)*1000;                      %Saturated vapour enthalpy, Enthalpy of steam at nighttime cooling SD pressure
Drum.hwat=XSteam('hL_p',SD.press)*1000;                     %Saturated water enthalpy at nightime cooling pressure
Drum.press=SD.press;                                        %SD pressure after nightime cooling
Drum.den_wat=XSteam('rho_ph',Drum.press,Drum.Temp_wat);     %Density of water in SD     kg/m^3
Drum.Vol_wat= Drum.Mass_wat/Drum.den_wat;                   %Volume of water in SD after nightime cooling             m^3
Drum.Vol_steam=Drum.Vsys-Drum.Vol_wat;                      %Volume of steam in SD after nightime cooling            m^3
Drum.den_steam=Drum.Mass_steam/Drum.Vol_steam;              %Saturated vapour density
%XSteam('rhoV_p',Drum.press);
SD_intial=[Drum.Mass  Drum.Mass_wat  Drum.Mass_steam  Drum.hwat   Drum.hst]; %[%Toal mass in Drum    Mass of water    Mass balance of steam     Enthalpy of water    Enthalpy of steam]
SD.press_st=41;                                             %SD setpoint pressure               bar
SD.ODE=0;
%%
break_time_stop=0;                                          %Used for stop the plant if it is 1
simulation_next=0;                                          %
start_sim_next=1;
plant_shut_down=0;

% w_iter_scf=break_time;
first_LFR_IC=1;
%ip1=round(break_time/60);
ip1=ip3;
timestart=break_time;
timestart=0;
timend=timestart+dt.scf;
dayss=2;
if Type==0
    time_hour=9;
    simu_time_end=time_hour*3600;
end
i=1;
bypass_plant=0;
if length(Xax.SD_steam)~=length(drum_Tsteam)
    disp('Pause')
end
Eng_gain_arr_PTC_salt=[];

%SG boiling cond include
%%
tic
while plant_shut_down==0
    %     HT.Tintial1=HT.Toout;
    SG.msgen=0;
    while (SG.boiling==1  && PTC_Fullplant==0 )
        for w_iter_scf=timestart:dt.scf:simu_time_end
            day2_boil=w_iter_scf


            PTC_scf.Toilin=LT.Toout;

            if  mod( w_iter_scf,60)==0
                PTC_scf.I= lfr_I_sec(ip1);
                Ambient_Temp=Ambient_Temp_ind(ip1);
                ip1=ip1+1;
            end

            HX.Ambient_Tempr=Ambient_Temp;

            %For storing purpose
            OP.I_solar=[OP.I_solar PTC_scf.I];
            OP.Ambient_T=[OP.Ambient_T Ambient_Temp];

            %Condition for Bypass HX
            if  PTC_SCF.Xintial(PTC_scf.grid) < HT.Toout %300                             %Output of PTC oil temp < 150
                PTC_HT_LTalone=1;                                               %PTC, HT, LT form route and bypass rest(HX)
            else
                PTC_HT_LTalone=0;                                               %PTC,HT,LT not alone, HX added
            end

            %if HX.intial
            if PTC_HT_LTalone==1
                %% Oil loop

                %Connect PTC
                Tspan=[0  dt.scf];                                              %o to 1 second
                options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                [Ts,Y_SCF]=ode15s(@solarfield,Tspan,PTC_SCF.Xintial,options);   %Integrate PTC tank ODEs
                PTC_SCF.Xintial=(Y_SCF(length(Ts),:)');
                PTC_out_temp=PTC_SCF.Xintial(15)

                if (HT.Toout<= PTC_SCF.Xintial(PTC_scf.grid))                   %If 40 oC (HT initial temp) <= Oil output temp of PTC
                    %Connect PTC-HT-LT
                    PTC_HT_OD=1;                                                %Then connect HT with PTC together and LT
                    PTC_LT_OD=0;
                    [HT_out_temp,LT_out_temp]=PTC_HT_LT_connection(Tspan);      %Calling function file with connection of PTC-HT-LT
                    HT_out_temp
                    LT_out_temp
                else
                    %Connect PTC-LT
                    PTC_LT_OD=1;                                                %Connect PTC with LT only when HT temp >PTC outlet
                    PTC_HT_OD=0;
                    [LT_out_temp]=PTC_LT_connection(Tspan);                     %%Calling function file with connection of PTC-LT

                end

                %TO compute energy from PTC
                % if w_iter_scf<8.8*3600
                %     [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);              %Function file calling for energy computation from PTC component
                %     E_ptc_num=E_ptc_num+1;
                % end
                %% Water loop
                if mod(w_iter_scf,LFR.dt)==0 && w_iter_scf~=0
                    [time_run]=LFR_sub_fun1(LFR_n);                             %LFR Initialization function
                    %                   LFR_n=LFR_n+1;                                              %Update step

                    %For storing purpose
                    LFR.IP_mwin=[LFR.IP_mwin LFR.mw_indi];                      %What is the input mass of water going in to LFR, here indi=Invidual pipe

                    % Calling LFRsimulation file
                    [iter]=LFRsimulation(LFR_n);                                %LFR simulation function file

                    %For storing purpose
                    Xax.LFR=[Xax.LFR w_iter_scf];                                 %Storing iteration number

                    if  first_LFR_IC==1                                         %Only for 1st time, after that it reach 2 and Drum.Temp_wat will take
                        first_LFR_IC=first_LFR_IC+1;                            %After 2nd iteration comes it is not needed
                    end

                    %phase 1=Pure steam, phase 0=No steam
                    LFR.msteam_out_indi=LFRsim.phase*LFR.mw_indi;               %Mass of steam out from LFR
                    LFR.msteam_pipeout8=LFR.nos_pipe*LFR.msteam_out_indi;       %Total Mass of steam out from LFR
                    LFR.mwater_out=(1-LFRsim.phase)*LFR.mw_indi;                %Mass of water out from LFR=1*0.3
                    LFR.mwater_pipeout8=LFR.nos_pipe*LFR.mwater_out;            %Total Mass of water from all 8 pipe=8*0.3

                    %For storing purpose: LFr mass of water & steam out at every time instant
                    LFR_mwater_out_nos_pipe(time_run+1)=LFR.mwater_pipeout8;    %Mass of water out from LFR
                    LFR_msteam_out_nos_pipe(time_run+1)=LFR.msteam_pipeout8;    %Mass of steam out from LFR

                    h_out_lfr=LFRsim.h(time_run+1,end);                         %Enthalpy of water out from LFR
                    hwin_drum=h_out_lfr;                                        %Enthalpy of water in to SD
                    LFR.press_end=LFRsim.P(time_run+1,end);                     %LFR end point pressure
                    LFR.Temp_wat=XSteam('T_ph',LFR.press_end,h_out_lfr*10^-3);

                    if LFRsim.phase >0                                          %If there is steam
                        mwin_dear=LFR.msteam_pipeout8;                          %The amount of steam produced and going out=Mass of water in from deareator to maintain the water level
                        Dear.mwin=mwin_dear;                                    %Mass of water in to LFR = Dear mass of water in
                        Dear.Twin=HX.Twin;                                      %Temp of water in to the hX is same as temp of water from Dear        30 0C
                        Dear.hwin=XSteam('h_pT',LFR.Press_in,Dear.Twin)*1000;   %Specific enthalpy of water flowing into SD      J/kg
                        steam_phase=1;
                    else                                                        %If there is no steam the values will be zero
                        mwin_dear=0;
                        Dear.mwin=0;
                        Dear.Twin=0;
                        Dear.hwin=0;
                    end
                    %Our aim is to generate steam from the LFR not from SD. So to check SD water saturated or not.
                    sat_h_drum=(XSteam('hL_p',Drum.press))*1000;                %Saturated liquid enthalpy of drum from Drum pressure, Water got saturated or not we need, Here Drum pressure will be initial one i.e. 2bar

                    %For connecting LFR-SD
                    Drum.mwin=LFR.mwater_pipeout8;                              %SD mass of water in from LFR
                    Drum.mwout=LFR.total_mw_in;                                 %Total mass of water out from SD will go to LFR as input         %LFR.total_mw_in=LFR.nos_pipe*LFR.mw_indi;   %2.4 kg/s is coming/8 pipes=1 pipe flow
                    %Drum.hwin=hwin_drum;                                       %Enthalpy of water in to SD
                    Drum.hwin_SD=hwin_drum;                                     %Enthalpy of water in to SD

                    %For storing purpose
                    if Dear.mwin>0
                        SD.IP_mwin=[SD.IP_mwin Dear.mwin];                          %What is the SD mass of water in from LFR
                        SD.IP_mwin_time=[SD.IP_mwin_time w_iter_scf];
                        IP_mwin_flag=1;
                    end
                    if time_run==1
                        drum_pressure(1)=Drum.press;                       %Drum pressure=1 bar (Initial)
                    end
                    %Connect SD
                    options= odeset('Events',@event_fun_SD);%??
                    [TS_SD,Y_SD,TE,VE]=ode45(@SD_dynamics_updated_ode,T_SPAN_SD,SD_intial,options);         %Integrate SD dynamics
                    SD_intial=(Y_SD(length(TS_SD),:)');                                                     %Updating step
                    SD.ODE=1;                                                                               %For plotting purpose to match the time axis

                    %For storing purpose
                    Yax.press_SD=[Yax.press_SD Drum.press ];                    %Y is for other variable save
                    Xax.SD=[Xax.SD w_iter_scf];                                   %X is for time axis save
                    OP.SDr=[OP.SDr ;SD_intial'];                                %To save SD initial value for every time instant, it will alwyas update

                    Drum.Mass=SD_intial(1);                                     %Total mass
                    Drum.Mass_wat=SD_intial(2);                                 %Mass of water
                    Drum.Mass_steam=SD_intial(3);                               %MAss of steam
                    Drum.hwat=SD_intial(4);                                     %Enthalpy of water
                    Drum.hst=SD_intial(5);                                      %Enthalpy of steam
                    if test==1
                        Drum.Temp_wat=XSteam('T_ph',LFR.press_end,Drum.hwat*10^-3); %SD water temp
                    else
                        Drum.Temp_wat=XSteam('T_ph',Drum.press,Drum.hwat*10^-3); %SD water temp
                    end

                    if Drum.Mass_steam >0
                        Drum.temp_steam=XSteam('T_ph',Drum.press,Drum.hst*10^-3); %SD steam temp
                        drum_Tsteam(time_run+1)=Drum.temp_steam;
                        Xax.SD_steam=[Xax.SD_steam w_iter_scf];
                    end
                    if length(Xax.SD_steam)~=length(drum_Tsteam)
                        disp('Pause')
                    end

                    % drum_pressure(1)=Drum.press;
                    %To store the variable wrt time
                    %drum_hsteam(time_run+1)=Drum.hst;                           %Enthalpy of steam
                    drum_hsteam(time_run+1)=Drum.hst*10^-3;                           %Enthalpy of steam
                    drum_row_st(time_run+1)=Drum.rho_st;                        %Density of steam present in SD     kg/m^3
                    drum_Vsteam(time_run+1)=Drum.Vsteam;                        %NOT USED
                    drum_Mass(time_run+1)=Drum.Mass;                            %Total mass
                    drum_Mass_wat(time_run+1)=Drum.Mass_wat;                    %Mass of water
                    drum_Mass_steam(time_run+1)=Drum.Mass_steam;                %MAss of steam
                    drum_pressure(time_run+1)=Drum.press;                       %Drum pressure=2bar
                    %drum_hwat(time_run+1)=Drum.hwat;                            %Enthalpy of water
                    drum_hwat(time_run+1)=Drum.hwat*10^-3;                            %Enthalpy of water
                    drum_Twat(time_run+1)=Drum.Temp_wat;                        %SD water temp

                    drum_msgen(time_run+1)=Drum.msgen;                          %SD mass of steam generation
                    drum_ms_out40(time_run+1)=Drum.msout;                       %SD mass of steam going out
                    Drum.msout_dear(time_run+1)=Drum.msout_dear(time_run)+(LFR.dt*Drum.msout);
                    waterin_drum(time_run+1)=waterin_drum(time_run)+(LFR.dt*mwin_dear);%Mass of water in to the drum
                    Steam_Q_drum(time_run+1)=LFRsim.phase;                      %Steam quality
                    Drum.mwin_n(time_run+1)=mwin_dear;                          %The amount of steam produced and going out=Mass of water in from deareator to maintain the water level
                    LFR_temp_fluid(time_run+1)=LFR.Tfluid;%%LFR.Temp_wat        %Output temp of LFR Fluid

                    %Energy computation from LFR
                    [Eng_gain_arr_LFR]=Energy_Compute_LFR(E_lfr_num,time_run); %Function file calling energy computation from LFR
                    E_lfr_num=E_lfr_num+1;                                      %Update setp

                    POWeT_pos_pow.powgen(xx)=0;
                    xx=xx+1;

                    Xax.POW=[Xax.POW w_iter_scf];                                     %Storing w_iter_scf at Xax.POW

                    if length(Xax.POW)~=length(POWeT_pos_pow.powgen)
                        Disp('Take pause here')
                    end

                    % if  IP_mwin_flag==1
                    %     SD.IP_mwin_time=[SD.IP_mwin_time w_iter_scf];
                    % end
                    if length(SD.IP_mwin_time)~=length(SD.IP_mwin)
                        disp('See length')
                    end
                end

            end

            if  PTC_HT_LTalone==0
                %% Oil loop

                %Connect PTC
                Tspan=[0  dt.scf];                                              %o to 1 second
                options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                [Ts,Y_SCF]=ode15s(@solarfield,Tspan,PTC_SCF.Xintial,options);  %Integrate PTC tank ODEs
                PTC_SCF.Xintial=(Y_SCF(length(Ts),:)');
                PTC_out_temp=PTC_SCF.Xintial(15)                               %PTC outlet temp

                %Connect HT with PTC
                HT.moilin=PTC_scf.moil*3;                                       %Mass of oil out from SCF enters to HT
                HT.moilout=HT.moilin;                                           %Mass of oil out from HT same as mass of oil in to HT
                HT.hin=h_oil(PTC_SCF.Xintial(PTC_scf.grid));                    %Enthalpy of oil in to HT

                if  PTC_HT_OD==1                                                %If HT tank temp <= PTC outlet temp
                    %Connect HT
                    options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                    [Ts,Y_HT]=ode15s(@HTtank,Tspan,PTC_HT.Xintial,options);     %ODE integration of HT
                    PTC_HT.Xintial=(Y_HT(length(Ts),:)');

                    HT.hout=PTC_HT.Xintial(2);                                  %Enthalpy of oil coming out from HT
                    %opts = optimset('TolFun',1e-12,'Display','off') ;
                    %HT.Toout=fsolve('enthal_Temp_HT',HT.Toout,opts);
                    HT.Toout=(-1.49681+sqrt(1.49681^2-4*0.0014*(-18.17454-HT.hout)))/(2*0.0014);   %At current enthalpy HT output temperature
                    HT_out_temp=HT.Toout;                                       %For saving HT outlet Temp

                    %Connect HT with SG_Subcooled
                    SG.moil=HT.moilout;                                         %The mass of oil coming from HT goes into SG
                    SG.Toilin=HT.Toout;                                         %Temp of oil to SG=HT temp of oil out
                else
                    %Connect HT with SG_Subcooled
                    SG.moil=PTC_scf.moil*3;                                     %Mass of oil out from SCF enters to SG (When HT not conected)
                    SG.Toilin=PTC_SCF.Xintial(PTC_scf.grid);                    %Outlet of SCF connected to SG
                end


                %At 1 bar saturation enthalpy of water is 417.44 kJ/kg (Check unit)
                SG.Wsat=XSteam('hL_p',SG.press_int);
                check_Wsat_SG=(SG.Wsat-HX.SGintial(5));

                if  (check_Wsat_SG <=0)                                         %So if saturation enthalpy is zero/-ve then saturation will occure.
                    disp('Saturation occured');
                end

                SG.hs= XSteam('hV_p',HX.SGintial(6));
                SG.hw=XSteam('hL_p',HX.SGintial(6));
                %check
                SG.mwin=0; %Not in day 1 why

                %Connect SG_Saturated
                options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                [Ts,Y_HXSG]=ode15s(@HXSG_sat,Tspan,HX.SGintial,options);
                HX.SGintial=(Y_HXSG(length(Ts),:)');
                SG_pressure=HX.SGintial(6)
                SG.ODE=1;

                %To check is there any imaginary part
                nedstop=isreal(HX.SGintial);
                if (nedstop)==0   %has img part
                    disp('Imaginary number in HX.SGintial')
                end

                %To store the variables
                OP.SGuaf=[OP.SGuaf SG.UAF];
                OP.SGhtube=[OP.SGhtube  SG.htctube];
                OP.SGhshell=[OP.SGhshell SG.htcshell];
                OP.SGF=[OP.SGF SG.htcF];
                OP.SGU=[OP.SGU SG.htcU];

                %Connect LT with SG
                LT.moilin=SG.moil;  %Not in sir code why
                LT.moilout=LT.moilin;
                LT.hin=h_oil(HX.SGintial(1));

                options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
                [Ts,Y_LT]=ode15s(@LTtank,Tspan,PTC_LT.Xintial,options);
                PTC_LT.Xintial=(Y_LT(length(Ts),:)');

                LT.hout=PTC_LT.Xintial(2);
                %opts = optimset('TolFun',1e-12,'Display','off') ;
                %LT.Toout=fsolve('enthal_Temp_LT',LT.Toout,opts);

                %Enthalpy polynomial fit equation:
                %Enthalpy=(0.0014*T^2)+(1.49681*T)-18.17454; (TAken from thermino VP1 pdf file)
                %Concidering only +ve part
                LT.Toout=(-1.49681+sqrt(1.49681^2-4*0.0014*(-18.17454-LT.hout)))/(2*0.0014);
                LT_out_temp=LT.Toout;

                %LT again connected to PTC
                PTC_SCF.Xintial(1)=LT.Toout;                                    %It may disturbe while saving OP.scf 1st temp so initialize before this
                %% Water loop: It should be parallelly run with OIL loop


                if mod(w_iter_scf,LFR.dt)==0

                    [time_run]=LFR_sub_fun1(LFR_n);
                    %                 LFR_n=LFR_n+1;

                    %For storing purpose
                    LFR.IP_mwin=[LFR.IP_mwin LFR.mw_indi];                          %What is the input mass of water going in to LFR, here indi=Invidual pipe

                    % Calling LFRsimulation file
                    [iter]=LFRsimulation(LFR_n);

                    %For storing purpose
                    Xax.LFR=[Xax.LFR w_iter_scf];

                    %       %Energy computation of LFR
                    %       [Eng_gain_arr_LFR1]=Energy_Compute_LFR(E_lfr_num,time_run);
                    %       E_lfr_num=E_lfr_num+1;

                    if  first_LFR_IC==1
                        first_LFR_IC=first_LFR_IC+1;
                    end

                    %phase 1=Pure steam, phase 0=No steam
                    LFR.msteam_out_indi=LFRsim.phase*LFR.mw_indi;                   %Mass of steam out from LFR
                    LFR.msteam_pipeout8=LFR.nos_pipe*LFR.msteam_out_indi;           %Total Mass of steam out from LFR
                    LFR.mwater_out=(1-LFRsim.phase)*LFR.mw_indi;                    %Mass of water out from LFR=1*0.3
                    LFR.mwater_pipeout8=LFR.nos_pipe*LFR.mwater_out;                %Total Mass of water from all 8 pipe=8*0.3

                    %For storing purpose: LFr mass of water & steam out at every time instant
                    LFR_mwater_out_nos_pipe(time_run+1)=LFR.mwater_pipeout8;        %Mass of water out from LFR
                    LFR_msteam_out_nos_pipe(time_run+1)=LFR.msteam_pipeout8;        %Mass of steam out from LFR

                    h_out_lfr=LFRsim.h(time_run+1,end);                             %Enthalpy of water out from LFR
                    hwin_drum=h_out_lfr;                                            %Enthalpy of water in to SD
                    LFR.press_end=LFRsim.P(time_run+1,end);                         %LFR end point pressure
                    LFR.Temp_wat=XSteam('T_ph',LFR.press_end,h_out_lfr*10^-3);

                    if LFRsim.phase >0                                              %If there is steam
                        mwin_dear=LFR.msteam_pipeout8;                              %The amount of steam produced and going out=Mass of water in from deareator to maintain the water level
                        Dear.mwin=mwin_dear;                                        %Mass of water in to LFR = Dear mass of water in
                        Dear.Twin=HX.Twin;                                          %Temp of water in to the hX is same as temp of water from Dear        30 0C
                        Dear.hwin=XSteam('h_pT',LFR.Press_in,Dear.Twin)*1000;       %Specific enthalpy of water flowing into SD      J/kg
                        steam_phase=1;
                    else                                                            %If there is no steam
                        mwin_dear=0;
                        Dear.mwin=mwin_dear;%check
                        Dear.Twin=0;
                        Dear.hwin=0;
                    end

                    %Our aim is to generate steam from the LFR not from SD. So to check SD water saturated or not.
                    sat_h_drum=(XSteam('hL_p',Drum.press))*1000;                    %Saturated liquid enthalpy of drum from Drum pressure, Water got saturated or not we need

                    if  isnan(Drum.hwat)==1                                         %IF NAN element is there
                        disp('Null elements captured in Drum.hwat')
                    end

                    %For connecting LFR-SD
                    Drum.mwin=LFR.mwater_pipeout8;                                  %SD mass of water in from LFR
                    Drum.mwout=LFR.total_mw_in;                                     %Total mass of water out from SD will go to LFR as input
                    %Drum.hwin=hwin_drum;                                            %Enthalpy of water in to SD
                    Drum.hwin_SD=hwin_drum;

                    %For storing purpose
                    IP_mwin_flag=0;
                    if Dear.mwin>0
                        SD.IP_mwin=[SD.IP_mwin Dear.mwin];                          %What is the SD mass of water in from LFR
                        SD.IP_mwin_time=[SD.IP_mwin_time w_iter_scf];
                        IP_mwin_flag=1;
                    end

                    % Connect SD
                    options= odeset('Events',@event_fun_SD);
                    [TS_SD,Y_SD,TE,VE]=ode45(@SD_dynamics_updated_ode,T_SPAN_SD,SD_intial,options);         %Integrate SD dynamics
                    SD_intial=(Y_SD(length(TS_SD),:)');
                    SD.ODE=1;

                    if isnan(Drum.press)==1                                         %To check any NAN for Drum pressure
                        disp('Null elements captured in Drum Pressure')
                    end

                    %For storing purpose
                    Yax.press_SD=[Yax.press_SD Drum.press];                         %To save Drum pressure ... Y is for other variable save
                    Xax.SD=[Xax.SD w_iter_scf];                                       %X is for time axis save
                    OP.SDr=[OP.SDr ; SD_intial'];

                    Drum.Mass=SD_intial(1);                                         %Total mass
                    Drum.Mass_wat=SD_intial(2);                                     %Mass of water
                    Drum.Mass_steam=SD_intial(3);                                   %MAss of steam
                    Drum.hwat=SD_intial(4);                                         %Enthalpy of water
                    Drum.hst=SD_intial(5);                                          %Enthalpy of steam
                    if test==1
                        Drum.Temp_wat=XSteam('T_ph',LFR.press_end,Drum.hwat*10^-3); %SD water temp
                    else
                        Drum.Temp_wat=XSteam('T_ph',Drum.press,Drum.hwat*10^-3); %SD water temp
                    end
                    if Drum.Mass_steam >0
                        %     Mass_steam_SD=1;
                        % end
                        % if Mass_steam_SD==1
                        % Drum.temp_steam=XSteam('T_ph',LFR.press_end,Drum.hst*10^-3); %SD steam temp
                        Drum.temp_steam=XSteam('T_ph',Drum.press,Drum.hst*10^-3); %SD steam temp
                        drum_Tsteam(time_run+1)=Drum.temp_steam;
                        Xax.SD_steam=[Xax.SD_steam w_iter_scf];
                    end
                    if length(Xax.SD_steam)~=length(drum_Tsteam)
                        disp('Pause')
                    end

                    if isnan(Drum.Temp_wat)==1
                        disp('Null elements captured in Drum Water Temperature')     %To check any NAN for Drum water Temperature
                    end

                    if isnan(Drum.press)==1
                        disp('Null element captured in Drum Pressure')
                    end

                    %To store the variable wrt time i.e after every 60 sec
                    %drum_hsteam(time_run+1)=Drum.hst;                           %Enthalpy of steam
                    drum_hsteam(time_run+1)=Drum.hst*10^-3;                           %Enthalpy of steam
                    drum_row_st(time_run+1)=Drum.rho_st;                            %Density of steam present in SD     kg/m^3
                    drum_Vsteam(time_run+1)=Drum.Vsteam;                            %NOT USED
                    drum_Mass(time_run+1)=Drum.Mass;                                %Total mass
                    drum_Mass_wat(time_run+1)=Drum.Mass_wat;                        %Mass of water
                    drum_Mass_steam(time_run+1)=Drum.Mass_steam;                    %MAss of steam
                    drum_pressure(time_run+1)=Drum.press;                           %Drum pressure
                    %drum_hwat(time_run+1)=Drum.hwat;                            %Enthalpy of water
                    drum_hwat(time_run+1)=Drum.hwat*10^-3;                            %Enthalpy of water
                    drum_Twat(time_run+1)=Drum.Temp_wat;                            %SD water temp

                    drum_msgen(time_run+1)=Drum.msgen;                              %SD mass of steam generation
                    drum_ms_out40(time_run+1)=Drum.msout;                           %SD mass of steam going out
                    Drum.msout_dear(time_run+1)=Drum.msout_dear(time_run)+(LFR.dt*Drum.msout);
                    waterin_drum(time_run+1)=waterin_drum(time_run)+(LFR.dt*mwin_dear);
                    Steam_Q_drum(time_run+1)=LFRsim.phase;                          %Steam quality
                    Drum.mwin_n(time_run+1)=mwin_dear;                              %The amount of steam produced and going out=Mass of water in from deareator to maintain the water level
                    LFR_temp_fluid(time_run+1)=LFR.Tfluid;                          %LFR.Temp_wat

        
                    %Energy computation of LFR
                    [Eng_gain_arr_LFR1]=Energy_Compute_LFR(E_lfr_num,time_run);
                    E_lfr_num=E_lfr_num+1;

                    %POWeT_pos_pow.powgen(xx)=0;
                    %xx=xx+1;

                    % if  IP_mwin_flag==1
                    %     SD.IP_mwin_time=[SD.IP_mwin_time w_iter_scf];
                    % end
                    if length(SD.IP_mwin_time)~=length(SD.IP_mwin)
                         disp('See length')
                    end

                end

                POW.ms_SG(w_iter_scf+1)=SG.msgen;
                POW.LFR(w_iter_scf+1)=Drum.msout;
                POW.ms_turb(w_iter_scf+1)=Drum.msout+0;
                POW.Ts_turb(w_iter_scf+1)=HX.SHintial(2);


                if  Drum.press>SD.press_st
                    if HT.Toout >300 || PTC_SCF.Xintial(PTC_scf.grid) >300
                        steamgen_LFR_bef_PTC=1;    %Steam generation will start from LFR before PTC loop i.e SG
                        SH.ODE_bef_PTC=1;
                    end
                end

                %Some time SD pressure(e.g:65 bar) will be way more than SG pressure(e.g: 12
                %bar), and Temp of oil in to SH is very less (e.g: 260 oC), But
                %we need abobe 300 oC. Then Heat the oil loop again to reach
                %the certain temperature, and vent out the SD pressure till
                %temp reach.


                if steamgen_LFR_bef_PTC == 1

                    if PTC_HT_OD==1
                        SHLFR.Toilin=HT.Toout;           %HT_OD is connected  else SCF
                    else
                        SHLFR.Toilin=PTC_SCF.Xintial(PTC_scf.grid);                 %SG is connected to Solar field
                    end

                    SH.mixh=(XSteam('hV_T',LFR.Tfluid));
                    SH.moil=HT.moilout;
                    SG.moil=HT.moilout;
                    PH.moil=HT.moilout;

                    %As the oil out temp slightly lower than oil in temp as
                    %well as Temp of steam out from SH slightly should be
                    %greater than Steam in temp due to heat exchange from Oil
                    %to steam.

                    %HX.SHintial=[SH.Toilin-2 LFR.Tfluid+1];                        %Initial Guess Temp of oil out and steam out from SH.
                    %HX.SHintial=[HX.SHintial(1) LFR.Tfluid+1];                      %From night time cooling temp taken
                    %HX.SHintial=[SH.Toilin-2 XSteam('Tsat_p',Drum.press,Drum.hst*10^-3)];
                    % HX.SHintial=[HX.SHintial(1)-2 XSteam('Tsat_p',Drum.press,Drum.hst*10^-3)];  %HX.SHintial(1): Nighttimne cooling temp. _2 oC is for as day2 at the begening the sh wont start so.
                    HX.SHintial=[SHLFR.Toilin-2 XSteam('T_ph',Drum.press,Drum.hst*10^-3)];
                    %Connect SH
                    SH.ODE=1;
                    %[~,sh_tsout]=HXSH(Tspan,HX.SHintial);
                    options(1) = odeset('RelTol',1e-5,'AbsTol',1e-5);
                    [Ts,Y_HXSH]=ode15s(@HXSH_bef_PTC,Tspan,HX.SHintial,options);
                    HX.SHintial=(Y_HXSH(length(Ts),:)');

                    %                     PHOP=[0;0]; OP.PH=[OP.PH PHOP ];
                    %                     OP.SH_noZ=[OP.SH_noZ  HX.SHintial];

                    %Power generation
                    POWei.lfr_ms=-0.263+ (0.668*Drum.msout );
                    POWei.lfr_CP=0.4+0.15*4;
                    POWei.lfr_temp=0.125+0.0025*HX.SHintial(2);
                    POWei.lfr_powgen(w_iter_scf+1)=POWei.lfr_ms*POWei.lfr_CP*POWei.lfr_temp;
                    pow_LFR=POWei.lfr_powgen(w_iter_scf+1);

                    POWeT.Tot_ms=POWei.lfr_ms;
                    POWeT.CP=POWei.lfr_CP;
                    POWeT.temp=POWei.lfr_temp;
                    POWeT.powgen(w_iter_scf+1)=POWei.lfr_powgen(w_iter_scf+1);
                else
                    POWeT.powgen(w_iter_scf+1)=0;
                end

                if  POWeT.powgen(w_iter_scf+1) >0
                    POWeT_pos_pow.powgen(xx)=POWeT.powgen(w_iter_scf+1);
                    xx=xx+1;
                else
                    POWeT_pos_pow.powgen(xx)=0;
                    xx=xx+1;
                end
                Xax.POW=[Xax.POW w_iter_scf];

                if length(Xax.POW)~=length(POWeT_pos_pow.powgen)
                    disp('Take pause here')
                end

                OP.Tsteam=[OP.Tsteam SG.Twater ];

                if  msgenout>0
                    HX.mwin= msgenout;
                    SG.mwin=HX.mwin;                                                %Mass of water going in to Sg
                    PH.mwin=HX.mwin;                                                %Mass of water going in to PH
                else
                    HX.mwin=0.5;
                    SG.mwin=HX.mwin;                                                %Mass of water going in to Sg
                    PH.mwin=HX.mwin;                                                %Mass of water going in to PH
                end

                %For storing purpose
                PH.sav_mwin(w_iter_scf+1)=PH.mwin;                                    %Mass of water in to PH
                SG.sav_mwin(w_iter_scf+1)=SG.mwin;                                    %Mass of water in to SG
                HX.sav_mwin(w_iter_scf+1)=HX.mwin;                                    %Mass of water in to HX
                mwin_SD(w_iter_scf+1)=Dear.mwin;                                      %Mass of water in to SD from Deaerator
                %Twin_SD(w_iter_scf+1)=Dear.Twin;                                      %Temp of water in to SD from Deaerator      oC
                mwin_LFR_indi(w_iter_scf+1)=LFR.mw_indi;                              %Mass of water in to individual LFR pipe
                mwin_LFR_total(w_iter_scf+1)=LFR.total_mw_in;                         %Total Mass of water in to LFR

                %TO compute energy
                if w_iter_scf<8.8*3600
                    [Eng_gain_arr_PTC_salt]=Energy_Compute_PTC_salt(E_ptc_num); 
                    [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);              %Function file calling for energy computation from PTC component
                    E_ptc_num=E_ptc_num+1;
                end

                if length(OP.SHU)~=length(Xa.X_SH_U)
                    disp('Length problem SH UAF')
                end

            end

            OP.SCF=[OP.SCF  PTC_SCF.Xintial];
            OP.HT_Temp=[OP.HT_Temp HT.Toout];                                %Store HT temp
            OP.LT_Temp=[OP.LT_Temp LT.Toout];

            if SH.ODE==1
                OP.SH=[OP.SH  HX.SHintial];
                OP.sh_tsout=[OP.sh_tsout  HX.SHintial(2)];
                Xa.X_SH=[Xa.X_SH w_iter_scf];
                Tur.msin=[Tur.msin SH.msin];                                    %Mass flow rate of steam out from SH and going in to Turbine
                if Mode==1
                    OP.SHuaf=[OP.SHuaf SH.UAF];
                    OP.SHhtube=[OP.SHhtube  SH.htctube];
                    OP.SHhshell=[OP.SHhshell SH.htcshell];
                    OP.SHF=[OP.SHF SH.htcF];
                    OP.SHU=[OP.SHU SH.htcU];
                    Xa.X_SH_U=[Xa.X_SH_U iter_scf];
                elseif Mode==2
                    if SH.ODE_bef_PTC==1
                        OP.SHuaf=[OP.SHuaf SH.UAF];
                        OP.SHhtube=[OP.SHhtube  SH.htctube];
                        OP.SHhshell=[OP.SHhshell SH.htcshell];
                        OP.SHF=[OP.SHF SH.htcF];
                        OP.SHU=[OP.SHU SH.htcU];
                        Xa.X_SH_U=[Xa.X_SH_U w_iter_scf];
                    end
                end
            end

            if SG.ODE==1
                OP.SG_temp=[OP.SG_temp HX.SGintial(1)];
                OP.SGTw=[ OP.SGTw SG.Twater];
                XA.X_SG=[XA.X_SG w_iter_scf];
                OP.SGmsgen=[OP.SGmsgen SG.msgen];
                OP.SG_pressure=[OP.SG_pressure HX.SGintial(6)];
                TW_in_HX=[TW_in_HX HX.Twin];                                       %To store the value of Temp of water in to Heat exchanger
            end
            if length(TW_in_HX)~=length(XA.X_SG)
                disp('Pause')
            end
            if SD.ODE==1
                OP.Drum_Temp_wat=[OP.Drum_Temp_wat Drum.Temp_wat];
                OP.LFR_Temp=[OP.LFR_Temp LFR.Tfluid];
                XA.X_SD=[XA.X_SD w_iter_scf];
            end

            if steam_phase>0
                Twin_SD=[Twin_SD Dear.Twin];
                Twin_SD_axis=[Twin_SD_axis w_iter_scf];
            end

            Xaxis=[Xaxis  w_iter_scf];
            pow_LFR_arr=[pow_LFR_arr pow_LFR];
            pow_PTC_arr=[pow_PTC_arr pow_PTC];
            if HX.SGintial(6)>=38.41
                disp('pasue')
            end
            if Type==1
                if  HX.SGintial(6)>=SG.press_st && PTC_HT_LTalone==0
                    disp('SG pressure reached 40 bar');
                    pressure_now=HX.SGintial(6)
                    PTC_Fullplant=1;
                    break
                end

            else
                if  HX.SGintial(6)>=SG.press_st %&& PTC_HT_LTalone==0
                    disp('SG pressure reached 40 bar');
                    pressure_now=HX.SGintial(6)
                    PTC_Fullplant=1;
                    break
                end
            end
        end

    end
    %w_iter-scf=4405;
    timestart=Xaxis(end);
    disp('SG Pressure reached 40bar, Now Full plant will work')

    steamgen_LFR_bef_PTC=0;

    %Saturated vapour enthalpy w.r.t pressure at SG
    SG.hs_steam= XSteam('hV_p',HX.SGintial(6));

    if Drum.press>SD.press_st
        LFR.Tfluid_ph=LFR.Tfluid;
        Drum.Temp_wat1=XSteam('T_ph',Drum.press,Drum.hst*10^-3);
        SG.LFR_Tsout=(SG.Twater+Drum.Temp_wat1)/2;                              %Concider both oil and water side temperature
    else  %Only concider oil side temperature
        LFR.Tfluid_ph=0;
        SG.LFR_Tsout=SG.Twater;
    end

    mix_sh_intial=[0 0];

    LFR_msteam=0;
    HX.Twin=(SG.Twater/250)*75;
    SG.Twin=HX.Twin;
    HX.PHintial(1)= HX.Twin+1;
    PH.ODE=1;
    HX.SHintial(2)=SG.LFR_Tsout+1;  %2nd day SH receive steam from both SG and SD same time. So temp is taken from SG
    SH.ODE=1;

    SH.msin=abs(SG.msgen);

    count=0;

    % SG.Twin
    %% Full HSTPP component connected
    while (PTC_Fullplant==1 && simulation_next==0 && PTC_HT_LTalone==0 )

        for w_iter_scf=(timestart+1):dt.scf:simu_time_end
            day2_fullplant=w_iter_scf

            PTC_scf.Toilin=LT.Toout;

            if  mod(w_iter_scf,60)==0
                PTC_scf.I= lfr_I_sec(ip1);
                Ambient_Temp=Ambient_Temp_ind(ip1);
                if ip1<length(lfr_I_sec)
                    ip1=ip1+1;
                else
                    count=1;
                    disp('Taking last ip1 value of "lfr_I_sec" which will go to "PTC_scf.I"')
                end
            end

            HX.Ambient_Tempr=Ambient_Temp;

            %For storing purpose
            OP.I_solar=[OP.I_solar PTC_scf.I];
            OP.Ambient_T=[ OP.Ambient_T Ambient_Temp];

            %% Oil loop
            %Connect PTC

            Tspan=[0  dt.scf];                      %o to 1 second
            options(1) = odeset('RelTol',1e-9,'AbsTol',1e-9);
            [Ts,Y_SCF]=ode15s(@solarfield,Tspan,PTC_SCF.Xintial,options);       %Integrate PTC tank ODEs
            PTC_SCF.Xintial=(Y_SCF(length(Ts),:)');
            PTC_out_temp=PTC_SCF.Xintial(15)

            % %TO compute energy for PTC
            % [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);
            % E_ptc_num=E_ptc_num+1;

            %Connect full plant
            [HT_out_temp,LT_out_temp]=PTC_HT_SH_SG_PH_LT_connection(Tspan);


            %% Water Loop

            if mod(w_iter_scf,LFR.dt)==0 && LFR_n <= runLFR                  %mod(w_iter_scf,60)=0

                [time_run]=LFR_sub_fun1(LFR_n);

                %For storing purpose
                LFR.IP_mwin=[LFR.IP_mwin LFR.mw_indi];                      %What is the input mass of water going in to LFR, here indi=Invidual pipe

                % Calling LFRsimulation file
                [iter]=LFRsimulation(LFR_n);

                %For storing purpose
                Xax.LFR=[Xax.LFR w_iter_scf];

                if  first_LFR_IC==1
                    first_LFR_IC=first_LFR_IC+1;
                end

                %phase 1=Pure steam, phase 0=No steam
                LFR.msteam_out_indi=LFRsim.phase*LFR.mw_indi;               %Mass of steam out from LFR
                LFR.msteam_pipeout8=LFR.nos_pipe*LFR.msteam_out_indi;       %Total Mass of steam out from LFR
                LFR.mwater_out=(1-LFRsim.phase)*LFR.mw_indi;                %Mass of water out from LFR=1*0.3
                LFR.mwater_pipeout8=LFR.nos_pipe*LFR.mwater_out;            %Total Mass of water from all 8 pipe=8*0.3

                %For storing purpose: LFr mass of water & steam out at every time instant
                LFR_mwater_out_nos_pipe(time_run+1)=LFR.mwater_pipeout8;    %Mass of water out from LFR
                LFR_msteam_out_nos_pipe(time_run+1)=LFR.msteam_pipeout8;    %Mass of steam out from LFR

                h_out_lfr=LFRsim.h(time_run+1,end);                         %Enthalpy of water out from LFR
                hwin_drum=h_out_lfr;                                        %Enthalpy of water in to SD
                LFR.press_end=LFRsim.P(time_run+1,end);                     %LFR end point pressure
                LFR.Temp_wat=XSteam('T_ph',LFR.press_end,h_out_lfr*10^-3);


                if LFRsim.phase >0
                    mwin_dear=LFR.msteam_pipeout8;%mwin_dear_intial;
                    %mwin_dear=Drum.msout;
                    Dear.mwin=mwin_dear;
                    steam_phase=1;
                else
                    mwin_dear=0;
                    Dear.mwin=mwin_dear;
                end
                %Our aim is to generate steam from the LFR not from SD. So to check SD water saturated or not.
                sat_h_drum=(XSteam('hL_p',Drum.press))*1000;                %Saturated liquid enthalpy of drum from Drum pressure, Water got saturated or not we need


                %For connecting LFR-SD
                Drum.mwin=LFR.mwater_pipeout8;                              %SD mass of water in from LFR
                Drum.mwout=LFR.total_mw_in;                                 %Total mass of water out from SD will go to LFR as input
                %Drum.hwin=hwin_drum;                                       %Enthalpy of water in to SD
                Drum.hwin_SD=hwin_drum;                                     %Enthalpy of water in to SD      ?Why this and above line
                IP_mwin_flag=0;
                %For storing purpose
                if Dear.mwin>0
                    SD.IP_mwin=[SD.IP_mwin Dear.mwin];                          %What is the SD mass of water in from LFR
                    SD.IP_mwin_time=[SD.IP_mwin_time w_iter_scf];
                    IP_mwin_flag=1;
                end
                % Connect SD
                options= odeset('Events',@event_fun_SD);
                [TS_SD,Y_SD,TE,VE]=ode45(@SD_dynamics_updated_ode,T_SPAN_SD,SD_intial,options);         %Integrate SD dynamics
                SD_intial=(Y_SD(length(TS_SD),:)');
                SD.ODE=1;
                %For storing purpose
                Yax.press_SD=[Yax.press_SD Drum.press ];                    % Y is for other variable save
                Xax.SD=[Xax.SD w_iter_scf];                                   % X is for time axis save
                OP.SDr=[OP.SDr ;SD_intial'];                                %To save SD initial value for every time instant, it will alwyas update

                Drum.Mass=SD_intial(1);                                     %Total mass
                Drum.Mass_wat=SD_intial(2);                                 %Mass of water
                Drum.Mass_steam=SD_intial(3);                               %MAss of steam
                Drum.hwat=SD_intial(4);                                     %Enthalpy of water
                Drum.hst=SD_intial(5);                                      %Enthalpy of steam
                if test==1
                    Drum.Temp_wat=XSteam('T_ph',LFR.press_end,Drum.hwat*10^-3); %SD water temp
                else
                    Drum.Temp_wat=XSteam('T_ph',Drum.press,Drum.hwat*10^-3); %SD water temp
                end
                if Drum.Mass_steam >0
                    %     Mass_steam_SD=1;
                    % end
                    % if Mass_steam_SD==1
                    % Drum.temp_steam=XSteam('T_ph',LFR.press_end,Drum.hst*10^-3); %SD steam temp
                    Drum.temp_steam=XSteam('T_ph',Drum.press,Drum.hst*10^-3); %SD steam temp
                    drum_Tsteam(time_run+1)=Drum.temp_steam;
                    Xax.SD_steam=[Xax.SD_steam w_iter_scf];
                end
                if length(Xax.SD_steam)~=length(drum_Tsteam)
                    disp('Pause')
                end
                %To store the variable wrt time
                %drum_hsteam(time_run+1)=Drum.hst;                           %Enthalpy of steam
                drum_hsteam(time_run+1)=Drum.hst*10^-3;                           %Enthalpy of steam
                drum_row_st(time_run+1)=Drum.rho_st;                        %Density of steam present in SD     kg/m^3
                drum_Vsteam(time_run+1)=Drum.Vsteam;                        %NOT USED
                drum_Mass(time_run+1)=Drum.Mass;                            %Total mass
                drum_Mass_wat(time_run+1)=Drum.Mass_wat;                    %Mass of water
                drum_Mass_steam(time_run+1)=Drum.Mass_steam;                %Mass of steam out from SD
                drum_pressure(time_run+1)=Drum.press;                       %Drum pressure=2bar
                %drum_hwat(time_run+1)=Drum.hwat;                            %Enthalpy of water
                drum_hwat(time_run+1)=Drum.hwat*10^-3;                            %Enthalpy of water
                drum_Twat(time_run+1)=Drum.Temp_wat;                        %SD water temp

                drum_msgen(time_run+1)=Drum.msgen;                          %SD mass of steam generation
                drum_ms_out40(time_run+1)=Drum.msout;                       %SD mass of steam going out
                Drum.msout_dear(time_run+1)=Drum.msout_dear(time_run)+(LFR.dt*Drum.msout);
                waterin_drum(time_run+1)=waterin_drum(time_run)+(LFR.dt*mwin_dear);
                Steam_Q_drum(time_run+1)=LFRsim.phase;                      %Steam quality
                Drum.mwin_n(time_run+1)=mwin_dear;                          %The amount of steam produced and going out=Mass of water in from deareator to maintain the water level
                LFR_temp_fluid(time_run+1)=LFR.Tfluid;                      %LFR.Temp_wat

                %Energy computation of LFR
                [Eng_gain_arr_LFR1]=Energy_Compute_LFR(E_lfr_num,time_run);
                E_lfr_num=E_lfr_num+1;

                % if  IP_mwin_flag==1
                %     SD.IP_mwin_time=[SD.IP_mwin_time w_iter_scf];
                % end
                if length(SD.IP_mwin_time)~=length(SD.IP_mwin)
                     disp('See length')
                end
            end
            %%
            %For storing purpose
            POW.ms_SG(w_iter_scf+1)=SG.msgen;
            POW.LFR(w_iter_scf+1)=Drum.msout;
            POW.ms_turb(w_iter_scf+1)=Drum.msout+SG.msgen;
            POW.Ts_turb(w_iter_scf+1)=HX.SHintial(2);

            %Power generation   %Taken reference from Desai paper
            POWeT.Tot_ms=-0.263+ (0.668*POW.ms_turb(w_iter_scf+1) );
            POWei.oil_ms=-0.263+ ( 0.668*SG.msgen );
            pow_PTC= POWei.oil_ms;
            POWeT.CP=0.4+0.15*4;
            POWeT.temp=0.125+0.0025*POW.Ts_turb(w_iter_scf+1);
            POWeT.powgen(w_iter_scf+1)=POWeT.Tot_ms*POWeT.CP*POWeT.temp;

            if  POWeT.powgen(w_iter_scf+1) >0
                POWeT_pos_pow.powgen(xx)=POWeT.powgen(w_iter_scf+1);
                xx=xx+1;
            else
                POWeT_pos_pow.powgen(xx)=0;
                xx=xx+1;
            end
            Xax.POW=[Xax.POW w_iter_scf];

            if length(Xax.POW)~=length(POWeT_pos_pow.powgen)
                disp('Take pause here')
            end

            if LFRsim.phase >0                                              %If there is steam
                mwin_dear=LFR.msteam_pipeout8;                              %The amount of steam produced and going out=Mass of water in from deareator to maintain the water level
                Dear.mwin=mwin_dear;                                        %Mass of water in to LFR = Dear mass of water in
                Dear.Twin=HX.Twin;                                          %Temp of water in to the hX is same as temp of water from Dear        30 0C
                Dear.hwin=XSteam('h_pT',LFR.Press_in,Dear.Twin)*1000;       %Specific enthalpy of water flowing into SD      J/kg
                steam_phase=1;
            else                                                            %If there is no steam
                mwin_dear=0;
                Dear.mwin=0;
                Dear.Twin=HX.Twin;
                Dear.hwin=0;
            end

            %For stroign purpose
            PH.sav_mwin(w_iter_scf+1)=PH.mwin;
            SG.sav_mwin(w_iter_scf+1)=SG.mwin;
            HX.sav_mwin(w_iter_scf+1)=HX.mwin;
            mwin_SD(w_iter_scf+1)=Dear.mwin;
            mwin_LFR_indi(w_iter_scf+1)=LFR.mw_indi;
            mwin_LFR_total(w_iter_scf+1)=LFR.total_mw_in;

            %TO compute energy
            [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num);
            E_ptc_num=E_ptc_num+1;

            %% To save variables
            Xaxis=[Xaxis  w_iter_scf];
            OP.SCF=[OP.SCF  PTC_SCF.Xintial];                                   %Store PTC temp
            OP.HT_Temp=[OP.HT_Temp HT_out_temp];
            OP.LT_Temp=[OP.LT_Temp LT_out_temp];

            OP.HT=[OP.HT PTC_HT.Xintial];
            OP.LT=[OP.LT PTC_LT.Xintial];
            if SH.ODE==1
                OP.SH=[OP.SH  HX.SHintial];
                %                 OP.sh_tsout=[OP.sh_tsout SH.Tsout];             %TO store steam outlet temp of SH
                OP.sh_tsout=[OP.sh_tsout  HX.SHintial(2)];
                Xa.X_SH=[Xa.X_SH w_iter_scf];
                Tur.msin=[Tur.msin SH.msin];                                    %Mass flow rate of steam out from SH and going in to Turbine
                OP.SHuaf=[OP.SHuaf SH.UAF];
                OP.SHhtube=[OP.SHhtube  SH.htctube];
                OP.SHhshell=[OP.SHhshell SH.htcshell];
                OP.SHF=[OP.SHF SH.htcF];
                OP.SHU=[OP.SHU SH.htcU];
                Xa.X_SH_U=[Xa.X_SH_U w_iter_scf];
            end

            if PH.ODE==1
                OP.PH=[OP.PH  HX.PHintial];
                OP.ph_twout=[OP.ph_twout PH.Twout];             %TO store water outlet temp of PH
                Xa.X_PH=[Xa.X_PH  w_iter_scf];
            end

            if SG.ODE==1
                OP.SG_temp=[OP.SG_temp HX.SGintial(1)];
                OP.SGTw=[OP.SGTw SG.Twater];         %steam or water temp of SG
                OP.Tsteam=[OP.Tsteam SG.Twater];
                XA.X_SG=[XA.X_SG w_iter_scf];
                OP.SGmsgen=[OP.SGmsgen SG.msgen];
                OP.SG_pressure=[OP.SG_pressure HX.SGintial(6)];
                TW_in_HX=[TW_in_HX HX.Twin];
            end
            if length(TW_in_HX)~=length(XA.X_SG)
                disp('Pause')
            end

            if SD.ODE==1
                OP.Drum_Temp_wat=[OP.Drum_Temp_wat Drum.Temp_wat];
                OP.LFR_Temp=[OP.LFR_Temp LFR.Tfluid];
                XA.X_SD=[XA.X_SD  w_iter_scf];
            end
            if steam_phase>0
                Twin_SD=[Twin_SD Dear.Twin];
                Twin_SD_axis=[Twin_SD_axis w_iter_scf];
            end

            pow_LFR_arr=[pow_LFR_arr pow_LFR];             %power generation from LFR
            pow_PTC_arr=[pow_PTC_arr pow_PTC];             %power generation from PTC

            if length(SD.IP_mwin_time)~=length(SD.IP_mwin)
                disp('See length')
            end

            %%
            %Condition for Stop the plant
            if Type==0
                if w_iter_scf>=(simu_time_end-1)
                    break_time_stop=1;
                    day_count=day_count+1;
                    note_time_day_end=[note_time_day_end w_iter_scf];
                    note_time_LFR=[note_time_LFR time_run+1];
                    w_iter_scf_1=w_iter_scf +4*3600;                            %w_iter_scf is the just before stop the plant. iter_scf_1 is 4 hrs after the plant stops. (Both in seconds)
                    ip2=ip1+(2*60);                                         %ip2 is basically updated ip1 after 4 hrs. (ip1 updated after every 60 sec)
                    simulation_night=1;                                     %Nighttime cooling will start
                    break_time_stop=1;
                    break  
                end
            else
                disp('Type')
            end

            if  (PTC_SCF.Xintial(PTC_scf.grid)) < 300 &&  HT.Toout < 300
                stop_time_1=w_iter_scf;
                bypass_plant=bypass_plant+1;

                if  bypass_plant > 300 %----5 sec repeated
                    %                     save result_for_temp_file
                    day_count=day_count+1;
                    note_time_day_end=[note_time_day_end w_iter_scf];
                    note_time_LFR=[note_time_LFR time_run+1];
                    w_iter_scf_1=w_iter_scf +2*3600;
                    %                     w_iter_scf21=w_iter_scf+(1*3600);
                    w_iter_scf21=ip1+(1*60);
                    simulation_night=1;
                    simulation_next=1;
                    break
                end
            end
        end

        if  simulation_night==1
            disp('Break in full plant occur');
            PTC_Fullplant=0;
        end

        leng_shut_down= length(note_time_day_end);

        if  (leng_shut_down == dayss+1)
            plant_shut_down=1;
            break;
        end

    end

    %%
    if  plant_shut_down==1
        disp(' Plant run for days is Over');
        break;
    end

end
Simu_time=toc
enthal_LFR=LFRsim.h*10^-3;

%Time axis converted to Seconds to Hours.
Xaxis=Xaxis/3600;  %3600 (sec) instant converted to 1 (hr)
Xa.X_SH=Xa.X_SH/3600;
Xa.X_SH_U=Xa.X_SH_U/3600;
XA.X_SG=XA.X_SG/3600;
Xa.X_PH=Xa.X_PH/3600;


LFR_time_run=0:1:runLFR;
time_lfr=(LFR_time_run*LFR.dt)/3600;%in Hr , time_lfr=runLFR
Xaxis_water=[Xaxis_water Xax.SD/60];
%Time axis converted to min to Hours.
Xaxis_water=Xaxis_water/60;
LFRsim.h=LFRsim.h*10^-3;

if Type==0
    save('Day2_over_Const')
elseif Type==1
    save('Day2_over_Step')
elseif Type==2
    save('Day2_over_Real')
elseif Type==3
    save('Day2_over_Quad')
end
Hot_startup=1;
end