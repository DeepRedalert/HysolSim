%% This is for SD night time. No control work has been done by surrender sir for this.SD.Mmeta
% Only for case study purpose it has been done.
% At night time steam changes to water again due to condensation.

function [dpdt_SD1] =SD_night1(t,T)

global SG  Drum SD U dhst_n

Drum_press=T(1);                    %Drum pressure
Mass_wat= T(2);                     %MAss of water in SD
Mass_st= T(3);                      %Mass of steam in SD

row_st=XSteam('rhoV_p',Drum_press);     %rhoV_p	Saturated vapour density

%SD pressure unit conversion
SD_press_n=Drum_press*10^5;

%hV_p	Saturated vapour enthalpy
dhst_n= ( (XSteam('hV_p',(Drum_press+(1*10^-6))))-(XSteam('hV_p',(Drum_press-(1*10^-6)))) )/(2*(0.1));
%rhoV_p	Saturated vapour density
drow_st=( (XSteam('rhoV_p',(Drum_press+(1*10^-6))))-(XSteam('rhoV_p',(Drum_press-(1*10^-6)))) )/(2*(0.1));
%hL_p	Saturated liquid enthalpy
dhw_n=( (XSteam('hL_p',(Drum_press+(1*10^-6))))-(XSteam('hL_p',(Drum_press-(1*10^-6)))) )/(2*(0.1));
%Tsat_p	Saturation temperature
dts=( (XSteam('Tsat_p',(Drum_press+(1*10^-6))))-(XSteam('Tsat_p',(Drum_press-(1*10^-6)))) )/(2*(0.1));

dhst_n=dhst_n*1000;     %Saturated vapour enthalpy
dhw_n=dhw_n*1000;       %Saturated liquid enthalpy

U_SD=U.SD_night;        %HTC of SD
F_SD=0.6;               %Correction factor

%% To calculate A_wair
R=SD.radi;              %Radius
L=SD.heig;              %Length

den_wat=XSteam('rhoL_p',Drum_press);        %rhoL_p	Saturated liquid density
Vol_wat=Mass_wat/den_wat;                   %Water volume
hw=Vol_wat/ (pi*R^2);                       %Enthalpy of water
conv=(pi/180);

if  (R-hw) >0
    Rmhw=R-hw;
    R2hm2=R^2-hw^2;
    anglee=(((Rmhw)/R) *conv);
    angle1=(180*(conv)-2*asin(anglee));
    A_wair=(2*pi*R^2*angle1-((sqrt(R2hm2)) ) ) +  ( ( (pi*R*L)/360) *angle1 );
else
    angle1=((hw-R)/R);
    angle1=angle1*conv;
    A_wair=((pi*R*L)/(360*conv))*( (180*conv)+ 2*asin(angle1) );
end

if  isreal(A_wair)~=1
    A_wair
    pause
end

%% For pressure equation
Total_area=(2*pi*R^2) +(pi*R*L);    %Total area of SD
A_stair= Total_area-A_wair;         %Area of steam=Area of SD-Area of water
A_SD=Total_area;

Drum_Temp_wat=XSteam('Tsat_p',Drum_press);      %SD water temp  oC

deltaT_stair=Drum_Temp_wat-30;       %Temp diff of steam and air
deltaT_wair=Drum_Temp_wat-30;        %Temp diff of water and air

hwx=XSteam('hL_p',Drum_press);       %Water enthalpy........%hL_p	Saturated liquid enthalpy
hs=XSteam('hV_p',Drum_press);        %Steam enthalpy........%hV_p	Saturated vapour enthalpy 
h_cond=(hs-hwx)*1000;                %Condensation enthalpy

%g in equation (D) in the night time SD model derivation
GG=(Mass_st*dhst_n)-(Drum.Vsys)+(SD_press_n*(Mass_st/(row_st^2))*drow_st);
%alpha in equation (F) in the night time SD model derivation
alpha_SD= (U_SD*A_stair*F_SD*deltaT_stair)+ (U_SD*A_wair*F_SD*deltaT_wair);
alpha_SD=-1*alpha_SD;
%X in equation (G) in the night time SD model derivation
XX_SD=(Mass_wat*dhw_n)+(Mass_st*dhst_n)-(Drum.Vsys)+(SG.Mmeta*SG.Cpmeta*dts);
%Rate of change of Pressure equation: *in the night time SD model derivation
dpdt_SD=((alpha_SD -(h_cond*(row_st/SD_press_n)*U_SD*A_stair*F_SD*deltaT_stair) )/(XX_SD+h_cond*GG*(row_st / SD_press_n)))*(1/10^5);
GG=GG*(1/10^5); %Unit conversion

%% For mass of water and mass of steam equation
m_cond_SD =( (-1*U_SD*A_SD*F_SD*deltaT_stair) -(GG *dpdt_SD) )*(row_st / SD_press_n);
Drum.m_cond=m_cond_SD;

if  Mass_st < 1
    dmwdt=0;
    dmsdt=0;
else
    dmwdt= -m_cond_SD;
    dmsdt= m_cond_SD;

end
%%
dpdt_SD1=[dpdt_SD dmwdt dmsdt]';        %Returning Rate of change of pressure in SD, Mass of water, Mass of steam

end