%Function file for compute Kinematic viscosity

function [k]=Kin_vis(T)

kv1=((544.149/(T+114.5))-2.59578);
k=exp(kv1);
k=k*10^-6;          %m2/s

end