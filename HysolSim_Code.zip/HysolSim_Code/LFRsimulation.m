% Function file for LFR
% For LFR Simulation we have 3 equations: Mass balance, Momentum balance, Energy balance.
%n=No of states

%%
function [iter]=LFRsimulation(tim)          %tim=1

global LFR LFRsim steaystate  first_LFR_IC Drum HX  tim_iter

global Tabsor_pre hfg 


theta=0;
sin_zero=0;%?
LFR.hppoint12=[];
% LFRsim.P(tim,poi+1)=Drum.press;


for poi=1:1:LFR.points-1                                %Grid point:4800
    rho_tol=10;                                         %Guess valjue for density
% Initialization
    LFRsim.rho(tim+1,poi+1)= LFRsim.rho(tim,poi+1);     %Density
    LFRsim.P(tim+1,poi+1) = LFRsim.P(tim,poi+1);        %Pressure
    LFRsim.h(tim+1,poi+1)=LFRsim.h(tim,poi+1);          %Enthalpy
    LFRsim.u(tim+1,poi+1)=LFRsim.u(tim,poi+1);          %Velocity
    LFRsim.x(tim+1,poi+1)=LFRsim.x(tim,poi+1);          %
    LFRsim.Tgla(tim+1,poi+1)=LFRsim.Tgla(tim,poi+1);    %Temp of glass absorber
    LFRsim.Ck(tim+1,poi+1)=LFRsim.Ck(tim,poi+1);        %Friction factor: Single phase and two phase

    if  first_LFR_IC==1
        LFRsim.Tabo(tim,poi)=HX.Ambient_Tempr;          %LFR Temp of Absorber pipe at initial, Ambient_Tempr=29.1 oC
        LFRsim.T(tim,poi)=  HX.Ambient_Tempr;           %Temp of water in to the LFR
        
        LFRsim.Tabo(tim+1,poi+1)=HX.Ambient_Tempr;      %Same as above, but for next time and grid position
        LFRsim.T(tim+1,poi+1)=  HX.Ambient_Tempr;       %Same as above, but for next time and grid position
    else
        LFRsim.Tabo(tim+1,poi+1)=LFRsim.Tabo(tim,poi+1);
        LFRsim.T(tim+1,poi+1)=LFRsim.T(tim,poi+1);
    end

    iter = 0;                                           %Iteration initialization

    while ( rho_tol>= 0.01)                             %Condition for while loop to continue, tolerence value should>=0.01
        iter = iter+1;                                  %Iteration increment

        P_bar=LFRsim.P(tim+1,poi+1);
        h_kj=LFRsim.h(tim+1,poi+1)*10^-3;               %

        hf=XSteam('hL_p',P_bar)*1000;                   %hL_p	Saturated liquid enthalpy, Enthalpy of fluid
        hg=XSteam('hV_p',P_bar)*1000;                   %hV_p	Saturated vapour enthalpy, Enthalpy of gas
        hfg=hg-hf;                                      %Enthalpy diff of both

        temp_W_lfr=XSteam('T_ph',P_bar,h_kj);              %T_ph	Temperture as a function of pressure and enthalpy

        if  hf > ( h_kj*1000)%  Not boiling here
            vis_L(tim+1,poi+1)=XSteam('my_ph',P_bar,h_kj); %my_ph	Viscosity as a function of pressure and enthalpy
            vis_g(tim+1,poi+1)=h2o_mug(P_bar*100);         %Viscosity of gas..(**)
        else                    %Boiling
            vis_L(tim+1,poi+1)=h2o_muf(P_bar*100);          %Comapare the values with Xsteam
            vis_g(tim+1,poi+1)=h2o_mug(P_bar*100);
        end

%% Mass Balance
%LFR.dt should not be less then no of segment length, LFR.dt=60 from main global

        Qn(tim,poi) = -LFR.dx*(LFRsim.rho(tim,poi)+LFRsim.rho(tim,poi+1))/(2*LFR.dt);
        Ri(tim+1,poi) =((LFR.dx/(2*LFR.dt))-LFRsim.u(tim+1,poi))*LFRsim.rho(tim+1,poi);
%Equation no A10 from thesis, Page 150, after taking to the side side
        LFRsim.u(tim+1,poi+1)=((-Ri(tim+1,poi)-Qn(tim,poi))/LFRsim.rho(tim+1,poi+1))-(LFR.dx/(2*LFR.dt));      

%         den1=LFRsim.rho(tim+1,poi);
%         ve1=LFRsim.u(tim+1,poi); 
%         den2=LFRsim.rho(tim,poi+1);

        enthalpy_grid= LFRsim.h(tim+1,poi+1);   %?

        if (enthalpy_grid > hf)     %Boiling cond
            LFRsim.phase=(enthalpy_grid-hf)/(hfg);      %Steam quality calculation,  %phase 1=Pure steam, phase 0=No steam
        else                        %Not boiling cond
            LFRsim.phase=0;
        end

        LFRsim.Qst(tim+1,poi+1)=LFRsim.phase;

        velocity=LFRsim.u(tim+1,poi+1);         %Velocity
        density=LFRsim.rho(tim+1,poi+1);        %Density
        pressure=LFRsim.P(tim+1,poi+1);         %Pressure
        enthalpy_grid=LFRsim.h(tim+1,poi+1);    %Enthalpy

%Function for comuputing HTC for single and two phase flow in LFR
        LFR.hppoint=compute_hp(velocity,density,pressure,enthalpy_grid,tim,poi,LFRsim.phase);       %HTC of LFR

        Tabsorber=LFRsim.Tabo(tim+1,poi+1);                     %Temp of absorber pipe
        area_ab=pi*LFR.rai_ab*2*LFR.dx;                         %Area of absorber pipe
        Qheat=LFR.hppoint*area_ab*(Tabsorber-LFR.Tfluid);       %Solar energy received, LFR.Tfluid=?, page 152
%Equation A.16 from thesis, Page no 152    
        q(poi)=Qheat/(pi*LFR.rai_ab^2*LFR.dx);                  %q=Heat per unit volume of flow         W/m^3, This added to water

%% Momentum Balance

        if ( LFRsim.h(tim+1,poi+1) < hf )
            Re =(LFRsim.rho(tim+1,poi+1)*LFRsim.u(tim+1,poi+1)*LFR.dia_ab)/vis_L(tim+1,poi+1);                  %Reynolds number 
        else
            if  LFRsim.h(tim+1,poi+1) > hg
                Re =(LFRsim.rho(tim+1,poi+1)*LFRsim.u(tim+1,poi+1)*LFR.dia_ab)/vis_g(tim+1,poi+1);              %Reynolds number 
            else
                Visco_2ph=( LFRsim.phase/vis_g(tim+1,poi+1) )+((1-LFRsim.phase)/vis_L(tim+1,poi+1)) ;
                visocity(tim+1,poi+1)= 1/Visco_2ph;
                Re =(LFRsim.rho(tim+1,poi+1)*LFRsim.u(tim+1,poi+1)*LFR.dia_ab)/visocity(tim+1,poi+1);           %Reynolds number 
            end
        end

        ERH=0;%2*10^-6;         %Equivalent roughness height (m)
        DH=LFR.dia_ab;          %Hydralulic diameter (m)

% To find friction factor (LFRsim.Ck)
        if (LFRsim.phase==0 || LFRsim.phase >1)         %
            f=ffrough(Re, DH, ERH);                                 %skin friction loss coefficient return, function file 
            LFR.fric=f;
            LFRsim.Ck(tim+1,poi+1)=(1*f)/(2*LFR.dia_ab);            %Equation A.18: Friction factor
        else    %2 phase friction factor calculation
%             G=LFRsim.rho(tim+1,poi+1)*LFRsim.u(tim+1,poi+1);
%             two_multi=Tpm_HOM(P_bar*100,LFRsim.phase);
            LFRsim.Ck(tim+1,poi+1)=(2*ffrough(Re, DH, ERH) )/(2*LFR.dia_ab);   %*? why 2 mult: Surrender sir
        end


% Equation A.11 in thesis 150 page
        Sn1=(LFR.dx/(2*LFR.dt))*((LFRsim.rho(tim,poi)*LFRsim.u(tim,poi))+(LFRsim.rho(tim,poi+1)*LFRsim.u(tim,poi+1)));
        Sn2=(1-theta)*(((LFRsim.rho(tim,poi+1)*LFRsim.u(tim,poi+1))*LFRsim.u(tim,poi+1))*(1+(LFRsim.Ck(tim,poi+1)*LFR.dx/2)));
        Sn3=(1-theta)*(LFRsim.rho(tim,poi)*LFRsim.u(tim,poi))*LFRsim.u(tim,poi)*(1-(LFRsim.Ck(tim,poi)*LFR.dx/2));
        Sn4=(1-theta)*(LFR.g*sin_zero*LFR.dx/2)*(LFRsim.rho(tim,poi+1)+LFRsim.rho(tim,poi));
        Sn=-Sn1+Sn2-Sn3+Sn4;

        T1=(LFR.dx/(2*LFR.dt))*(LFRsim.rho(tim+1,poi)*LFRsim.u(tim+1,poi));
        T2=(theta*(LFR.g*sin_zero*LFR.dx/2)*LFRsim.rho(tim+1,poi));
        T3= theta*(LFRsim.rho(tim+1,poi)*LFRsim.u(tim+1,poi)*LFRsim.u(tim+1,poi))*(1-(LFRsim.Ck(tim+1,poi)*LFR.dx/2));%Problem
        T4=(LFRsim.P(tim+1,poi))*10^5;
        Tot=T1+T2-T3-T4;

        P1=theta*LFRsim.rho(tim+1,poi+1)*(LFR.g*sin_zero*LFR.dx/2); %Problem: Theta should not be here
        P2=theta*LFRsim.rho(tim+1,poi+1)*(LFRsim.u(tim+1,poi+1)*LFRsim.u(tim+1,poi+1)*(1+(LFRsim.Ck(tim+1,poi+1)*LFR.dx/2)));
        P3=(LFR.dx*LFRsim.rho(tim+1,poi+1)*LFRsim.u(tim+1,poi+1))/(2*LFR.dt) ;
        LFRsim.P(tim+1,poi+1)=(-Sn-Tot-P1-P2-P3)*10^-5; %A.11 equation

%% Energy Balance   %Equation A.12

        Y1=(LFRsim.rho(tim,poi+1)*(LFRsim.h(tim,poi+1)+((LFRsim.u(tim,poi+1)*LFRsim.u(tim,poi+1))/2)));
        Y2=(LFRsim.rho(tim,poi)*(LFRsim.h(tim,poi)+((LFRsim.u(tim,poi)*LFRsim.u(tim,poi))/2)));
        Y3=-1*( (LFRsim.P(tim,poi+1)+LFRsim.P(tim,poi))*10^5  );
        Yn=-(LFR.dx/(2*LFR.dt))*(Y1+Y2+Y3);

        W1=(LFR.dx/(2*LFR.dt))*( ( LFRsim.rho(tim+1,poi)*(LFRsim.h(tim+1,poi)+((LFRsim.u(tim+1,poi)*LFRsim.u(tim+1,poi))/2)) )-(LFRsim.P(tim+1,poi)*10^5) );
        W2=-1*(LFRsim.rho(tim+1,poi)*LFRsim.u(tim+1,poi))*(LFRsim.h(tim+1,poi)+((LFRsim.u(tim+1,poi)*LFRsim.u(tim+1,poi))/2));
        W3=(LFR.g*sin_zero*LFR.dx*(LFRsim.rho(tim+1,poi)*LFRsim.u(tim+1,poi))/2);%Why sin_zero=Horizontal pipe
        W4=(-q(poi)*LFR.dx);
        Wi=W1+W2+W3+W4;

        E1=(LFRsim.rho(tim+1,poi+1)*LFRsim.u(tim+1,poi+1))+(LFRsim.rho(tim+1,poi+1)*(LFR.dx/(2*LFR.dt)));
        E2=LFR.g*sin_zero*LFR.dx*(LFRsim.rho(tim+1,poi+1)*LFRsim.u(tim+1,poi+1))/2;
        E3=-(LFR.dx/(2*LFR.dt))*LFRsim.P(tim+1,poi+1)*10^5;
        LFRsim.h(tim+1,poi+1)=( (-Yn-Wi-E3-E2)/E1)-((LFRsim.u(tim+1,poi+1)*LFRsim.u(tim+1,poi+1))/2 );          %Equation A.12

        %%
        LFR.Tfluid=XSteam('T_ph',LFRsim.P(tim+1,poi+1),LFRsim.h(tim+1,poi+1)*10^-3);  %From momentum and energy bal      %Temp of water in to LFR    %T_ph=Temperture as a function of pressure and enthalpy
        Tabsor_pre=[LFRsim.Tabo(tim,poi+1)  LFRsim.Tgla(tim,poi+1)];        %[Temp of absorber pipe    %Temp of glass absorber]

        Tabsorber_SS=Tabsor_pre;
        
        
%% Implicit Euler method        
        if steaystate==0        %Transient because steady state value =0 in main
            dt_par=LFR.dt;       %60
            %delta_absor = (dt_par*feval(@absorb_exp,Tabsor_pre))+Tabsor_pre;  % explicit euler method used to get the initial guess for applying implicit euler method
            delta_absor = (dt_par*absorb_exp(Tabsor_pre))+Tabsor_pre;  % explicit euler method used to get the initial guess for applying implicit euler method
            options11 = optimset('TolFun',[1e-12],'Display','off') ; 
            %Tabsorber =fsolve(@absorb_exp,delta_absor,options11);     %delta_absor=Initial guess   
            Tabsorber =fsolve(@absorb,delta_absor,options11) ;%delta_absor=Initial guess
            Tabsor_pre = Tabsorber;
        else
% Run in Steady state
            options11 = optimset('TolFun',[1e-12],'Display','off') ;
            Tabsorber_SS =  fsolve(@absorb_exp,Tabsorber_SS,options11);
            Tabsorber =Tabsorber_SS ;
        end

        LFRsim.Tabo(tim+1,poi+1)=Tabsorber(1);  
        LFRsim.Tgla(tim+1,poi+1)=Tabsorber(2);
        LFRsim.T(tim+1,poi+1)=LFR.Tfluid;  %Written by Deep
%% Equation of State

        h_kj=LFRsim.h(tim+1,poi+1)*10^-3;                           %Enthalpy
        rho_newp=LFRsim.rho(tim+1,poi+1);
        P_bar=LFRsim.P(tim+1,poi+1);                                %Pressure
        rho_new(tim+1,poi+1)=XSteam('rho_ph',P_bar,h_kj);           %rho_ph	Density as a function of pressure and enthalpy 
        rho_tol = abs((rho_newp - rho_new(tim+1,poi+1)));           %rho_new(tim+1,poi+1) ); ??**

%         row_Lsat=XSteam('rhoL_p',P_bar);
%         row_Vsat=XSteam('rhoV_p',P_bar);

        LFRsim.rho(tim+1,poi+1)=rho_new(tim+1,poi+1);           %DENSITY
%         Pasc(tim+1,poi+1)=LFRsim.P(tim+1,poi+1)*10^5;
        LFRsim.Pendpipe=LFRsim.P(tim+1,poi+1);                  %PRESSURE
%         Ckk(tim+1,poi+1)=LFRsim.Ck(tim+1,poi+1);
        LFRsim.hpp(tim+1,poi+1)=LFR.hppoint;                    %LFR HTC

        tim_iter(tim+1,poi+1)=iter;
%         press_final_pas=Pasc(tim+1,poi+1);
%         fghj=LFRsim.Ck(tim+1,poi+1);

        if iter>2000
            disp('iteration grater 2000');
%             pause
            LFR.break1=1;
            LFR.break_count=LFR.break_count+1;
            break
        end
        LFR_iteration=iter;
        LFR_iteration
        if LFR_iteration>=6
            disp('pause,3')
        end
    end

    if LFR.break1==1
        LFR.break1=0;
        break
    end
end
return
