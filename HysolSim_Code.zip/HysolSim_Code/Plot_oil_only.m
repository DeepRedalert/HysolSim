function D1=Plot_oil_only(Mode,Add_path)
Mode;
global Type iter_scf

if Type==0
    load Day1_over_Oil_Const.mat
elseif Type==1
    load Day1_over_Oil_step.mat
elseif Type==2
    load Day1_over_Oil_Real.mat
elseif Type==3
    load Day1_over_Oil_Quad.mat
end


set(0,'DefaultLineLineWidth',4)
set(0,'DefaultLineMarkerSize',10)
set(0,'DefaultAxesFontSize',18);
set(0,'DefaultTextFontSize',20);

Solar_axis=round(iter_scf/60);

SetGraphics;

if Type==0
    cd iMAGE/Type0/Day1_oilonly/
elseif Type==1
    cd iMAGE/Type1/Day1_oilonly/
elseif Type==2
    cd iMAGE/Type2/Day1_oilonly/
elseif Type==3
    cd iMAGE/Type3/Day1_oilonly/
end


axis=1:1:Solar_axis;

figure(1)
figure1=figure(1);
axes1 = axes('Parent',figure1); % Create axes
plot(axis/60,lfr_I_sec(:,1:Solar_axis))
legend('Solar radiation','fontsize',20)
grid on
xlabel('Time (Hrs)','FontWeight','bold')
ylabel('w/m^2','FontWeight','bold')
if Type==0
    title('Constant radiation','FontWeight','bold')
elseif Type==1
    title('Step change radiation','FontWeight','bold')
elseif Type==2
    title('Real-time radiation','FontWeight','bold')
elseif Type==3
    title('Quadratic radiation','FontWeight','bold')
end
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(1).jpg');

figure(2)
figure1=figure(2);
axes1 = axes('Parent',figure1); % Create axes
plot(Xaxis(:,1:end),TW_in_HX)
xlabel('Time (Hrs)','FontWeight','bold')
ylabel('Temperature ^oC','FontWeight','bold')
grid on
hx = legend('$T_{W,i,HX}$','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex')
title('Temperature profile of water in HX','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','13 PM','14 PM','15 PM','16 PM','17 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(2).jpg');

figure(3)
figure1=figure(3);
axes1 = axes('Parent',figure1); % Create axes
plot(Xaxis,OP.SCF(15,1:end),'b','LineWidth',3)
hold on
plot(Xaxis,OP.HT_Temp(:,1:end),'g','LineWidth',3)
hold on
plot(Xa.X_SH,OP.SH(1,:),'k','LineWidth',3)
hold on
plot(XA.X_SG,OP.SG_temp,'m','LineWidth',3)
hold on
plot(Xa.X_PH,OP.PH(2,:),'r','LineWidth',3)
hold on
plot(Xaxis,OP.LT_Temp(1:end),'c','LineWidth',3)
hold off
grid on
hx=legend('$T_{(o,o,PTC)}$','$T_{(o,o,HT)}$','$T_{(o,o,SH)}$','$T_{(o,o,SG)}$','$T_{(o,o,PH)}$','$T_{(o,o,LT)}$','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex')
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('Temperature ^oC','FontWeight','bold');
title('Output Oil Temprature profile','FontWeight','bold')
text(XA.X_SG(1),OP.SG_temp(1),'\bf \leftarrow SG connected cold startup','FontSize',11)
text(Xa.X_SH(1),OP.SH(1,1),'\bf \leftarrow SH connected cold startup','FontSize',11)
text(Xa.X_PH(1),OP.PH(2,1),'\bf \leftarrow PH connected cold startup','FontSize',11)
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','13 PM','14 PM','15 PM','16 PM','17 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(3).jpg');


figure(4)
figure1=figure(4);
axes1 = axes('Parent',figure1); % Create axes
plot(Xa.X_SH,OP.sh_tsout,'b','LineWidth',3)
hold on
plot(XA.X_SG,OP.SGTw,'g','LineWidth',3)
hold on
plot(Xa.X_PH,OP.ph_twout,'r','LineWidth',3)         %see graph
hold off
grid on
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('Temperature ^oC','FontWeight','bold');
hx=legend('$T_{(st,o,SH)}$','$T_{(w,SG)}$','$T_{(w,o,PH)}$','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex')
title('Water/Steam outlet temperature profile','FontWeight','bold')
text(Xa.X_SH(1),OP.sh_tsout(1),'\bf \leftarrow SH connected cold startup','FontSize',11)
text(XA.X_SG(1),OP.SGTw(1),'\bf \leftarrow SG connected cold startup','FontSize',11)
text(Xa.X_PH(1),OP.ph_twout(1),'\bf \leftarrow PH connected cold startup','FontSize',11)
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','13 PM','14 PM','15 PM','16 PM','17 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(4).jpg');


figure(5)
figure1=figure(5);
axes1 = axes('Parent',figure1); % Create axes
plot(Xaxis,OP.SCF(1,1:end),'m','LineWidth',3)
hold on
plot(Xaxis,OP.SCF(8,1:end),'b','LineWidth',3)
hold on
plot(Xaxis,OP.SCF(15,1:end),'g','LineWidth',3)
hold off
grid on
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('Temperature ^oC','FontWeight','bold');
hx=legend('T(o,o,33m)','T(o,o,264m)','T(o,o,500m)','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex')
title('PTC oil outlet temperature profile','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','13 PM','14 PM','15 PM','16 PM','17 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(5).jpg');

figure(6)
figure1=figure(6);
axes1 = axes('Parent',figure1); % Create axes
plot(XA.X_SG,OP.SG_pressure)
xlabel('Time (Hrs)','FontWeight','bold')
ylabel('bar','FontWeight','bold')
grid on
title('Pressure Profiles','FontWeight','bold')
hx = legend('$P_{SG}$','fontsize',20);
set(hx,'Interpreter','latex')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','13 PM','14 PM','15 PM','16 PM','17 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(6).jpg');


figure(7)      %see graph
figure1=figure(7);
axes1 = axes('Parent',figure1); % Create axes
plot(Xaxis,POW.ms_SG)%SG.msgen
xlabel('Time (Hrs)','FontWeight','bold')
ylabel('kg/s','FontWeight','bold')
grid on
title('Flowrate of steam Profile','FontWeight','bold')
hx = legend('$\dot{m}_{(st,o,SG)}$','fontsize',20);
set(hx,'Interpreter','latex')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','13 PM','14 PM','15 PM','16 PM','17 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(7).jpg');


figure(8)
figure1=figure(8);
axes1 = axes('Parent',figure1); % Create axes
plot(Xax.POW/3600,POWeT_pos_pow.powgen)
xlabel('Time(Hrs)','FontWeight','bold')
ylabel('MWe','FontWeight','bold')
legend('Total Power','fontsize',20)
grid on
title('Power Generation Electrical','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','13 PM','14 PM','15 PM','16 PM','17 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(8).jpg');


figure(9)
figure1=figure(9);
axes1 = axes('Parent',figure1); % Create axes
plot(XA.X_SG,OP.SG_temp,'m','LineWidth',3)
grid on
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('Temperature ^oC','FontWeight','bold');
title('SG Output Oil Temprature profile and SG pressure','FontWeight','bold')
hold on
yyaxis right
plot(XA.X_SG,OP.SG_pressure,'b','LineWidth',3)
ylabel('SG Pressure (bar)','FontWeight','bold');
hold off
hx=legend('$T_{(o,o,SG)}$','$P_{SG}$','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex', 'fontsize', 20)
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','13 PM','14 PM','15 PM','16 PM','17 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(9).jpg');


figure(10)
figure1=figure(10);
axes1 = axes('Parent',figure1); % Create axes
plot1=plot(Xaxis,OP.LT_Temp(1:end),'c','LineWidth',3);
datatip(plot1,'DataIndex',885,'Location','northwest');
datatip(plot1,'DataIndex',8650,'Location','northwest');
ylabel('Temperature ^oC','FontWeight','bold')
hold on
yyaxis right
plot2=plot(Xaxis(:,1:end),TW_in_HX,'b','LineWidth',3);
ylabel('Temperature ^oC','FontWeight','bold')
hold off
xlabel('Time,hours','FontWeight','bold')
grid on
hx = legend('$T_{(o,o,LT)}$','$T_{W,i,HX}$','Location','southeast','fontsize',20);
set(hx,'Interpreter','latex', 'fontsize', 20)
title('LT oil outlet temp & HX water inlet temp','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','13 PM','14 PM','15 PM','16 PM','17 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(10).jpg');


figure(11)
figure1=figure(11);
axes1 = axes('Parent',figure1); % Create axes
plot(Xa.X_SH,OP.SHU)%not same
hold on
plot(XA.X_SG,OP.SGU,'m','LineWidth',3)
hold on
plot(Xa.X_PH,OP.PHU,'r','LineWidth',3)
hold off
grid on
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('W/(m^2 K)','FontWeight','bold');
hx=legend('$U_{SG}$','$U_{PH}$','Location','northeast','fontsize',20);
set(hx,'Interpreter','latex')
title('Heat transfer coeeficient','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','13 PM','14 PM','15 PM','16 PM','17 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(11).jpg');


D1=1;
cd(Add_path)
end