%Function file for compute PTC energy

function [Eng_gain_arr_PTC1]=Energy_Compute_PTC(E_ptc_num)

global PTC_SCF PTC_scf dt Eng_gain_arr_PTC1

hout_oil_ptc=h_oil(PTC_SCF.Xintial(PTC_scf.grid));
hin_oil_ptc=h_oil(PTC_scf.Toilin);
Enge_gain_PTC1=((PTC_scf.moil*(hout_oil_ptc-hin_oil_ptc))*dt.scf );
%Eng_gain_arr_PTC1(E_ptc_num)=Enge_gain_PTC1;
Eng_gain_arr_PTC1=[Eng_gain_arr_PTC1  Enge_gain_PTC1];
end