 %Function for Energy balance for LFR pipe
 
function [Tem] =absorb_exp(Tabsorber)

global  LFR

TEgi=Tabsorber(2);
%Equation A.13: Energy balance for LFR absorber pipe
Tem(1)=((LFR.hppoint*LFR.pai*(LFR.Tfluid-Tabsorber(1)))-((LFR.sig/((1/LFR.ea)+(((1-LFR.ee)/LFR.ee)*(LFR.rao_ab/LFR.rei))))...
                         *(LFR.pao*(((Tabsorber(1)+273.15)^4)-((TEgi+273.15)^4))))+(0.25*(LFR.I*LFR.no*LFR.width)))/(LFR.den_abso*LFR.Cp_abso*LFR.Aai);

%Equation A.14: Energy balance for LFR glass envelop
Tem(2)=(((LFR.sig/((1/LFR.ea)+((1-LFR.ee)/LFR.ee)*(LFR.rao_ab/LFR.rei)))*(LFR.pao*(((Tabsorber(1)+273.15)^4)-((TEgi+273.15)^4))))...
                -(LFR.sig*LFR.ee*LFR.peo*(((TEgi+273.15)^4)-((LFR.Tsky+273.15)^4)))...
                 -(LFR.hair*LFR.peo*(TEgi-LFR.Tair)))/(LFR.den_gla*LFR.Ce_gla*LFR.Ae);
end

%LFR.I=PTC_scf.I;   %Solar radiation same for LFR also  %Mention in LfR_sub_fun1