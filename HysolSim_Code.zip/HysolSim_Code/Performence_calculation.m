%This file is for to see the performence results
clc

% global Type
% load Type.mat
if Type==0
    load Day1_over_Const.mat
elseif Type==1
    load Day1_over_Step.mat
elseif Type==2
    load Day1_over_Real.mat
elseif Type==3
    load Day1_over_Quad.mat
end

%global PTC_scf LFR POWeT_pos_pow POW

%1. Soler energy received per tube Qsolar,r (MJ)
%For PTC, This is for per tube, for now there is 3 PTC, so for PTC multiply
%with 3
Q_solar_r_PTC=(sum(lfr_I_sec(1:LFR_n),2)*PTC_scf.leng*PTC_scf.aper_wid*60)/10^6;
Q_solar_r_PTC=Q_solar_r_PTC*3
%For LFR
Q_solar_r_LFR=(sum(lfr_I_sec(1:LFR_n),2)*LFR.Length*LFR.width*60)/10^6
%Overall
Q_solar_r_overall=Q_solar_r_PTC+Q_solar_r_LFR


%2. Soler energy collected per tube Qsoalr,c (MJ)
%For PTC
Q_solar_c_PTC=Q_solar_r_PTC*PTC_scf.effici
%For LFR
Q_solar_c_LFR=Q_solar_r_LFR*LFR.no
%Overall
Q_solar_c_overall=Q_solar_c_PTC+Q_solar_c_LFR


%3. Thermal energy extracted per tube, Qth (MJ)
%For PTC
Q_th_PTC=(sum(Eng_gain_arr_PTC1,2))/10^3;
Q_th_PTC=Q_th_PTC*3
%For LFR
Q_th_LFR=(sum(Eng_gain_arr_LFR1,2))/10^3
%Overall
Q_th_overall=Q_th_PTC+Q_th_LFR


%4. Average thermal efficiency
%For PTC
T_eff_PTC=Q_th_PTC/Q_solar_c_PTC
%For LFR
T_eff_LFR=Q_th_LFR/Q_solar_c_LFR


%5. Total steam produced,
%By PTC
Steam_PTC=sum(POW.ms_SG)
%By LFR
Steam_LFR=sum(POW.LFR)
% Total steam
Steam_Total=Steam_PTC+Steam_LFR


%6. Electric energy generated in MWh(e)
Electric_energy_total=(sum(POWeT_pos_pow.powgen))/3600

%7. Peak electric power (MWe)
PeaK_elec_pow=max(POWeT_pos_pow.powgen)

%8. Duration of plant operation (hrs)
Plant_op_time=LFR_n/60

%9. Duration of power generation
%Pow_en_time=