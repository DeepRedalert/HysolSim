% Main file for SG saturated. Here change in pressure. Whatever water
% coming in it get accumulated and temperature and enthalpy will increase.
% Pressure change only occure in saturation condition. Steam will come out.
% Here tube side=oil, Shell side=Water+Steam



function [dHX_SG] =HXSG_sat(t,T)

global PTC_HT_OD
global SG
global HT
global HX
global SH
global PTC_Fullplant PTC_SCF  PTC_scf msgenout PH

if PTC_HT_OD==1
    SG.Toilin=HT.Toout;                         %HT_OD is connected  else SCF
    if  SH.ODE==1
        SG.Toilin=HX.SHintial(1);           %Scf-HT-SH-SG------
    end
else
    SG.Toilin=PTC_SCF.Xintial(PTC_scf.grid);    %SG is connected to Solar field
end

%In main line no 252
SG.Toout=T(1);          %Outlet oil temp of SG
SG.Mw=T(2);             %Mass of water
SG.Msteam=T(4);         %Mass  of steam
SG.press=T(6);          %SG  pressure

if  PTC_Fullplant==1
    % SG.mwin=abs(SG.msgen);
    msgenout=abs(SG.msgen);    %Steam leaving SG
else
    msgenout=0;
end

if  msgenout>0
    HX.mwin= msgenout;
    SG.mwin=HX.mwin;                                                %Mass of water going in to Sg
    PH.mwin=HX.mwin;                                                %Mass of water going in to PH
else
    HX.mwin=0.5;
    SG.mwin=HX.mwin;                                                %Mass of water going in to Sg
    PH.mwin=HX.mwin;                                                %Mass of water going in to PH
end

% SG.mwin=HX.mwin;                                                %Mass of water going in to Sg
% PH.mwin=HX.mwin;                                                %Mass of water going in to PH

if (SG.mwin==0)
    SG.Twin=0;
    SG.hwin=0;
else
    SG.hwin=XSteam('h_pT',SG.press,SG.Twin);
end
SG.Twater=XSteam('Tsat_p',SG.press);    %Tsat_p	Saturation temperature
row_w=XSteam('rhoL_p',SG.press);        %rhoL_p	Saturated liquid density
row_s=XSteam('rhoV_p',SG.press);        %rhoV_p	Saturated vapour density
SG.VLwat= SG.Mw/row_w;                  %Volume of water inside SG
SG.Vsteam= SG.Msteam/row_s;             %Volume of steam inside SG

%% Numerical value for partial derivative
%rhoV_p	Saturated vapour density
drow_s=( (XSteam('rhoV_p',(SG.press+(1*10^-6))))-(XSteam('rhoV_p',(SG.press-(1*10^-6)))) )/(2*(0.1));
%hV_p	Saturated vapour enthalpy
dhs=( (XSteam('hV_p',(SG.press+(1*10^-6))))-(XSteam('hV_p',(SG.press-(1*10^-6)))) )/(2*(0.1));
%hL_p	Saturated liquid enthalpy
dhw=( (XSteam('hL_p',(SG.press+(1*10^-6))))-(XSteam('hL_p',(SG.press-(1*10^-6)))) )/(2*(0.1));
%Tsat_p	Saturation temperature
dts=( (XSteam('Tsat_p',(SG.press+(1*10^-6))))-(XSteam('Tsat_p',(SG.press-(1*10^-6)))) )/(2*(0.1));
%rhoL_p	Saturated liquid density
drow_w=( (XSteam('rhoL_p',(SG.press+(1*10^-6))))-(XSteam('rhoL_p',(SG.press-(1*10^-6)))) )/(2*(0.1));
dhs=dhs*1000;           %Saturated steam enthalpy
dhw=dhw*1000;           %Saturated water enthalpy

%%
SG.ODE=1;
if  SG.ODE==1
    %% Function for calculating UAF
    [SG.UAF,SG.htctube,SG.htcshell, SG.htcF,SG.htcU] =UAF_SG_fun(SG.moil,SG.Toilin,SG.Toout,SG.mwin,SG.Twin,SG.Twater,SG.press,t);
    
       
    SG.UAF=0.6*SG.UAF; % Through validation of real plant data

    %% Calculation of LMTD
    SG.hot=SG.Toilin-SG.Twater;       %Hot side temp diff
    SG.cold=SG.Toout-SG.Twin;          %Cold side temp diff
    oilside= (SG.Toilin+SG.Toout)/2;    %Avg oil temp for PH in and out
    steamside=(SG.Twater+SG.Twin)/2;    %Avg water temp for PH in and out

    if (SG.hot/SG.cold)==1  || (SG.Twin > SG.Toout)|| (SG.Twater > SG.Toilin)
        SG.Lmtd=oilside-steamside;
        disp('AR SG');
    else
        SG.Lmtd=(SG.hot-SG.cold)/( log(SG.hot/SG.cold) );       %LMTD
    end

    %% Some parameter calculation
    %lm_sg=SG.Toout-SG.Twater;
    oil_diff_sg=SG.Toilin - SG.Toout;           %Temp diff of oil of in & out of SG
    oil_avg_sg=(SG.Toilin+ SG.Toout)/2;         %Avg Temp of oil of in & out of SG: HOT
    cold_avg_sg=(SG.Twater+ SG.Twin)/2;         %Avg Temp of water of in & out of SG: COLD
    SG.AMTD=(oil_avg_sg-cold_avg_sg);           %Avg temp diff of hot and cold fluid
    %% Oil side temp equation Eqiation 30 in IECER paper.  1. OIL

    deno_HX_3=(SG.tube_side_volume*SG.Toout*density_oil(SG.Toout)*(dbyCp_sf(SG.Toout)*10^(-3)))+...
        (SG.tube_side_volume*SG.Toout*dbyden_sf(SG.Toout)*(Cp_oil(SG.Toout) * 10^(-3)))+...
        (SG.tube_side_volume*density_oil(SG.Toout)*(Cp_oil(SG.Toout) * 10^(-3)));

    dTdt3 = ((SG.moil *(Cp_oil(oil_avg_sg)*10^(-3))*(oil_diff_sg))-(SG.UAF*SG.Lmtd))...
        /(deno_HX_3);

    %% Msgen
    %     ua=5;
    %     Tl=SG.Twater;
    %     Tamb=30;
    %     Tw=Tl;

    %unit conversion KJ to joules
    hwin_n=SG.hwin*1000;                 %Specific enthalpy of water flowing to SG
    hw_n=SG.hw*1000;
    hs_n=SG.hs*1000;     %Specific enthalpy of water present in SG
    dhs_n=dhs;                           %Saturated vapour enthalpy
    dhw_n=dhw;                           %Saturated liquid enthalpy
    UAFgen_sg_add_n=SG.UAF*1000;         %? why * by 1000:Conversion to KW?
    Pres_n=SG.press*10^5;                %SG pressure

    %% other 3 ODEs
    dMwatbydt=SG.mwin-SG.msgen;          %2. MAss of water
    dMsysbydt=SG.mwin+SG.msgen-msgenout; %3. Mass of system         ***check it
    %[SG.msgen  msgenout];

    %SG.Msteam=T(4);
    if  SG.Msteam < 0
        dMsteambydt=0;                          %No steam produced
        disp('NO STEAM PRODUCED');
    else
        dMsteambydt=SG.msgen-msgenout;          % This line should be below 159
    end

    dhwbydt=0;                                  %4. Enthalpy of water, not concidering,water temp not changing

    %% Equation 26 in IECER paper: 5. dP/dt (PRessure)
    %Vwt=SG.VLwat;
    Pres=SG.press;
    Masswater= SG.Mw;
    Masssteam= SG.Msteam;

    hwx=XSteam('hL_p',Pres);            %hL_p	Saturated liquid enthalpy
    hs=XSteam('hV_p',Pres);             %hV_p	Saturated vapour enthalpy
    hc=(hs-hwx)*1000;                   %Condensation enthalpy
   
    f=(Masswater*dhw_n)+(Masssteam*dhs_n)-(SG.Vsys)+(SG.Mmeta*SG.Cpmeta*dts)+(hc*row_s*(Masswater/(row_w^2))*drow_w)+(hc*SG.Vsteam*drow_s);
    pre_rhs=(SG.mwin*(hwin_n-hw_n))-(msgenout*(hs_n-hw_n))+(UAFgen_sg_add_n*SG.Lmtd)+(((hc*row_s*(SG.mwin))/row_w));

    e1=((Masswater*dhw_n)-SG.VLwat+((Pres_n/(row_w^2))*Masswater*drow_w));
    a2=(SG.mwin*(hwin_n-hw_n+(Pres_n/row_w)));
    a3=(UAFgen_sg_add_n*SG.Lmtd);
    com=((hs_n-hw_n)+(Pres_n/row_w));
    numer_pres=(pre_rhs*com)-(a2*((hc*row_s)/row_w))-(a3*((hc*row_s)/row_w))-(SG.Uloss*SG.loss_A*(SG.Toilin- HX.Ambient_Tempr));

    deno_pres=(f*com)-(((hc*row_s)/row_w)*e1);
    dpbydt=((numer_pres/deno_pres)*(1/10^5));

    %% Equation 29 in IECER paper, in paper loss term not concidered, 6.  Mass flowrate of steam
    e1=((Masswater*dhw_n)-SG.VLwat+((Pres_n/(row_w^2))*Masswater*drow_w));
    num1=((SG.mwin*(hwin_n-hw_n+(Pres_n/row_w)))+(UAFgen_sg_add_n*SG.Lmtd)-(SG.Uloss*SG.loss_A*(SG.Toilin- HX.Ambient_Tempr)));
    deno=((hs_n-hw_n)+(Pres_n/row_w));
    SG.msgen=((num1-(e1*(dpbydt*10^5)))/deno) ;         %Used in mixer

    dHX_SG=[dTdt3 dMwatbydt dMsysbydt dMsteambydt dhwbydt dpbydt]';       %Return all 6 output
    %[Mass flow rate of oil, Mass flow rate of water,Mass of system,Mass flow rate of steam, Enthalpy of water, Pressure]
else
    dHX_SG=[0 0 0 0 0 0]';       %Return all 6 output
    SG.ODE=1;                    %??
end
%implicit

end