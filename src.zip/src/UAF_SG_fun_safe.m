function [UAF,hi_t_turb,hb_sg,F,U]=UAF_SG_fun_safe(mo,Toi,Too,mw,Twi,Two,press,t)
%% Steam generator HTC: Saturated condition (SAFE, behavior-preserving)
% Same physics/correlations as original code.
% Only adds numerical protection to avoid NaN/Inf/imaginary values.

global SG

% Small number for safe division/checks
epsx = 1e-12;

% Default outputs
UAF = 0;
hi_t_turb = 0;
hb_sg = 0;
F = 1;
U = 0;

%% Basic input checks
if ~isfinite(mo) || ~isfinite(Toi) || ~isfinite(Too) || ~isfinite(mw) || ...
   ~isfinite(Twi) || ~isfinite(Two) || ~isfinite(press)
    disp('Invalid input in UAF_SG_fun_safe')
    return
end

if ~isreal(Toi),  Toi = real(Toi);  disp('Toi imaginary in UAF_SG_fun_safe');  end
if ~isreal(Too),  Too = real(Too);  disp('Too imaginary in UAF_SG_fun_safe');  end
if ~isreal(Twi),  Twi = real(Twi);  disp('Twi imaginary in UAF_SG_fun_safe');  end
if ~isreal(Two),  Two = real(Two);  disp('Two imaginary in UAF_SG_fun_safe');  end
if ~isreal(press), press = real(press); disp('press imaginary in UAF_SG_fun_safe'); end

%% Averages
P     = press;
To_av = (Toi + Too)/2;
Tw_av = (Twi + Two)/2; %#ok<NASGU>

g  = 9.8;
Pc = 220;   % bar

%% Geometry
Nt       = SG.No_tubes;
Di_t     = SG.tube_Id;
ri_t     = SG.tube_Id/2;
Do_t     = SG.tube_OD;
ro_t     = SG.tube_OD/2;
nopass_t = 2;
L_t      = SG.tube_length;
Area     = pi*Do_t*L_t*(Nt*2);
Therma   = 49;

% Geometry validation
if ~isfinite(Nt) || ~isfinite(Di_t) || ~isfinite(Do_t) || ~isfinite(L_t) || ...
   Nt <= 0 || Di_t <= 0 || Do_t <= 0 || L_t <= 0 || ri_t <= 0 || ro_t <= 0
    disp('Invalid SG geometry in UAF_SG_fun_safe')
    return
end

if Do_t <= Di_t
    disp('SG tube_OD <= tube_Id in UAF_SG_fun_safe')
    return
end

if ~isfinite(Area) || Area <= 0
    disp('Invalid SG area in UAF_SG_fun_safe')
    return
end

%% ================== Shell side HTC calculation ==================
% Saturated boiling side from original model

sur_s   = XSteam('st_p',SG.press);
row_l_s = XSteam('rhoL_p',SG.press);
row_v_s = XSteam('rhoV_p',SG.press);

hV_p = XSteam('hV_p',SG.press);
hL_p = XSteam('hL_p',SG.press);

latent_s = (hV_p - hL_p) * 1000;
h_w_sg   = hL_p;

dyn_vis_s = XSteam('my_ph',SG.press,h_w_sg);

if isnan(dyn_vis_s) || ~isfinite(dyn_vis_s) || dyn_vis_s <= 0
    vis_L = h2o_muf(SG.press*100);
    dyn_vis_s = vis_L;
end

cpW_s  = XSteam('CpL_p',SG.press) * 1000;
Ther_s = XSteam('tcL_p',SG.press);

% Property validation
if ~isfinite(sur_s) || sur_s <= 0
    disp('Surface tension invalid in SG UAF')
    return
end
if ~isfinite(row_l_s) || row_l_s <= 0
    disp('Saturated liquid density invalid in SG UAF')
    return
end
if ~isfinite(row_v_s) || row_v_s < 0
    disp('Saturated vapour density invalid in SG UAF')
    return
end
if ~isfinite(latent_s) || latent_s <= 0
    disp('Latent heat invalid in SG UAF')
    return
end
if ~isfinite(dyn_vis_s) || dyn_vis_s <= 0
    disp('Dynamic viscosity invalid in SG UAF')
    return
end
if ~isfinite(cpW_s) || cpW_s <= 0
    disp('Liquid Cp invalid in SG UAF')
    return
end
if ~isfinite(Ther_s) || Ther_s <= 0
    disp('Liquid thermal conductivity invalid in SG UAF')
    return
end
if (row_l_s - row_v_s) <= 0
    disp('row_l_s - row_v_s invalid in SG UAF')
    return
end

% Original Te logic retained exactly
if (Too - Two) > 0
    Te = (0.3 * ((Too - Two)/3));
else
    disp('CHECK TE');
    Te = abs(0.001 * ((Too - Two)/3));
end

if ~isfinite(Te) || Te < 0
    disp('Te invalid in SG UAF')
    return
end

Pra_Sg = (cpW_s * dyn_vis_s) / Ther_s;

if ~isfinite(Pra_Sg) || Pra_Sg <= 0
    disp('Pra_Sg invalid in SG UAF')
    return
end

Csf = 0.001;
n   = 1;

% 1. Rosenhow correlation
radicand = (g * (row_l_s - row_v_s)) / sur_s;
if ~isfinite(radicand) || radicand <= 0
    disp('Boiling sqrt term invalid in SG UAF')
    return
end

term1 = radicand^(1/2);
term2 = ((cpW_s * Te) / (Csf * latent_s * (Pra_Sg^n)))^3;

if ~isfinite(term1) || ~isfinite(term2) || term2 < 0
    disp('Boiling term invalid in SG UAF')
    return
end

q_sg = dyn_vis_s * latent_s * term1 * term2;
Q_sbyA_SG = q_sg; %#ok<NASGU>

if ~isfinite(q_sg) || q_sg < 0
    disp('q_sg invalid in SG UAF')
    return
end

% 2. Mostinski method
hb1_sg = 0.00417 * Pc^0.69 * (q_sg^0.7);
hb2_sg = (1.8*((P/Pc)^0.17)) + (4*((P/Pc)^1.2)) + (10*((P/Pc)^10));
hb_sg  = hb1_sg * hb2_sg;

if ~isfinite(hb1_sg) || hb1_sg < 0
    disp('hb1_sg invalid in SG UAF')
    return
end
if ~isfinite(hb2_sg) || hb2_sg < 0
    disp('hb2_sg invalid in SG UAF')
    return
end
if ~isfinite(hb_sg) || hb_sg <= 0
    disp('hb_sg invalid in SG UAF')
    return
end

%% ================== Tube side HTC calculation ==================
% Original oil-side model retained

den_t    = density_oil(To_av);
cp_t     = Cp_sf(To_av);
Kvis_t   = Kin_vis(To_av);
Therm_t  = Ther_con(To_av);
dyn_vis_t = Kvis_t * den_t;

if ~isfinite(den_t) || den_t <= 0
    disp('Tube-side density invalid in SG UAF')
    return
end
if ~isfinite(cp_t) || cp_t <= 0
    disp('Tube-side Cp invalid in SG UAF')
    return
end
if ~isfinite(Kvis_t) || Kvis_t <= 0
    disp('Tube-side kinematic viscosity invalid in SG UAF')
    return
end
if ~isfinite(Therm_t) || Therm_t <= 0
    disp('Tube-side thermal conductivity invalid in SG UAF')
    return
end
if ~isfinite(dyn_vis_t) || dyn_vis_t <= 0
    disp('Tube-side dynamic viscosity invalid in SG UAF')
    return
end

At_t  = (pi*(Di_t^2))/4;
Atp_t = (Nt*At_t)/nopass_t;

if ~isfinite(At_t) || At_t <= 0 || ~isfinite(Atp_t) || Atp_t <= 0
    disp('Tube-side area invalid in SG UAF')
    return
end

Gt_t = (mo/Atp_t);
Ut_t = Gt_t/den_t;
Ren_t = (Ut_t*den_t*Di_t)/dyn_vis_t;
Pr_t  = (cp_t*dyn_vis_t)/Therm_t;

if ~isfinite(Ren_t) || Ren_t <= 0
    disp('Tube-side Reynolds number invalid in SG UAF')
    return
end
if ~isfinite(Pr_t) || Pr_t <= 0
    disp('Tube-side Prandtl number invalid in SG UAF')
    return
end

% Original turbulent form retained exactly: natural log, not log10
logTerm = 1.58*log(Ren_t) - 3.28;
if ~isfinite(logTerm) || abs(logTerm) < epsx
    disp('Tube-side friction factor term invalid in SG UAF')
    return
end

f_t = logTerm^(-2);

den_nu = 1.07 + (12.7*((f_t/2)^(1/2))) * ((Pr_t^(2/3)) - 1);
if ~isfinite(den_nu) || abs(den_nu) < epsx
    disp('Tube-side Nusselt denominator invalid in SG UAF')
    return
end

NUs_t = ((f_t/2)*Ren_t*Pr_t) / den_nu;
hi_t_turb = (NUs_t*Therm_t) / Di_t;

if ~isfinite(NUs_t) || NUs_t < 0
    disp('Tube-side Nusselt invalid in SG UAF')
    return
end
if ~isfinite(hi_t_turb) || hi_t_turb <= 0
    disp('Tube-side HTC invalid in SG UAF')
    return
end

%% ================== Overall HTC ==================
wallTerm = (ro_t*log(ro_t/ri_t)) / Therma;

if ~isfinite(wallTerm) || wallTerm < 0
    disp('Wall term invalid in SG UAF')
    return
end

denU = ((ro_t/ri_t)*(1/hi_t_turb)) + (1/hb_sg) + wallTerm;

if ~isfinite(denU) || denU <= 0
    disp('Overall HTC denominator invalid in SG UAF')
    return
end

U = 1/denU;

if ~isreal(U)
    disp('HTC is imag for SG')
    U = real(U);
end

if ~isfinite(U) || U < 0
    disp('U invalid in SG UAF')
    U = 0;
end

%% ================== Correction factor ==================
% Keep original behavior: compute if you want, but final F = 1 for boiling
if mw == 0
    F = 1;
else
    denR = (Two - Twi);
    denS = (Toi - Twi);

    if abs(denR) < epsx || abs(denS) < epsx
        % keep alive, but boiling section uses F=1 anyway
        F = 1;
    else
        Rr = (Toi - Too)/denR;
        Ss = (Two - Twi)/denS;

        rootTerm = sqrt((Rr^2) + 1);

        a1 = (1 - Ss);
        a2 = (1 - (Rr*Ss));
        F_d1 = 2 - (Ss*(Rr + 1 - rootTerm));
        F_d2 = 2 - (Ss*(Rr + 1 + rootTerm));

        validF = true;

        if ~isfinite(Rr) || ~isfinite(Ss)
            validF = false;
        end
        if a1 <= 0 || a2 <= 0
            validF = false;
        end
        if F_d1 <= 0 || F_d2 <= 0
            validF = false;
        end
        if abs(Rr - 1) < epsx
            validF = false;
        end

        if validF
            num_F  = (sqrt((Rr^2)+1)) * log((1-Ss)/(1-(Rr*Ss)));
            Deno_F = (Rr-1) * log(F_d1/F_d2);

            if isfinite(num_F) && isfinite(Deno_F) && abs(Deno_F) > epsx
                F = num_F / Deno_F;
            else
                F = 1;
            end
        else
            F = 1;
        end
    end
end

% Original model behavior retained
F = 1;  % For boiling correction factor is one

%% ================== Final UAF ==================
UAF = U * Area * F;
UAF = UAF * 1e-3;

if ~isreal(UAF) || ~isfinite(UAF)
    disp('SG Corrected')
    UAF = 0;
end

end