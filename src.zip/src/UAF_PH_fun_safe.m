function [UAF,hi_t_turb,ho_she,F,U]=UAF_PH_fun_safe(mo,Toi,Too,mw,Twi,Two,Pres)
%% Preheater HTC (SAFE, behavior-preserving)
% Same physics/correlations as original code.
% Only adds numerical protection to avoid NaN/Inf/imaginary values.

global PH

epsx = 1e-12;

% Default outputs
UAF = 0;
hi_t_turb = 0;
ho_she = 0;
F = 0;
U = 0;

%% Basic input checks
if ~isfinite(mo) || ~isfinite(Toi) || ~isfinite(Too) || ~isfinite(mw) || ...
   ~isfinite(Twi) || ~isfinite(Two) || ~isfinite(Pres)
    disp('Invalid input in UAF_PH_fun_safe')
    return
end

if ~isreal(Toi),  Toi = real(Toi);  disp('Toi imaginary in UAF_PH_fun_safe'); end
if ~isreal(Too),  Too = real(Too);  disp('Too imaginary in UAF_PH_fun_safe'); end
if ~isreal(Twi),  Twi = real(Twi);  disp('Twi imaginary in UAF_PH_fun_safe'); end
if ~isreal(Two),  Two = real(Two);  disp('Two imaginary in UAF_PH_fun_safe'); end
if ~isreal(Pres), Pres = real(Pres); disp('Pres imaginary in UAF_PH_fun_safe'); end

Tw_av   = (Twi + Two)/2;
Toil_av = (Toi + Too)/2;

%% Geometry
tube_ID = PH.tube_ID;
ri_t    = tube_ID/2;
tube_OD = PH.tube_OD;
ro_t    = tube_OD/2;
L_t     = PH.tube_length;
No_tub  = PH.No_tubes;
PH.nopass_t = 2;

Area   = pi*tube_OD*L_t*(No_tub*2);
Therma = 49;

% Geometry validation
if ~isfinite(tube_ID) || ~isfinite(tube_OD) || ~isfinite(L_t) || ~isfinite(No_tub) || ...
   tube_ID <= 0 || tube_OD <= 0 || L_t <= 0 || No_tub <= 0 || ri_t <= 0 || ro_t <= 0
    disp('Invalid PH geometry in UAF_PH_fun_safe')
    return
end

if tube_OD <= tube_ID
    disp('PH tube_OD <= tube_ID in UAF_PH_fun_safe')
    return
end

if ~isfinite(Area) || Area <= 0
    disp('Invalid PH area in UAF_PH_fun_safe')
    return
end

%% ================== Tube side HTC calculation ==================
% Water side, original correlation retained

den_t     = XSteam('rho_pT',Pres,Tw_av);
cpW_t     = XSteam('Cp_pT',Pres,Tw_av);
cp_t      = cpW_t * 1000;
dyn_vis_t = XSteam('my_pT',Pres,Tw_av);
Th_t      = XSteam('tc_pT',Pres,Tw_av);

if ~isfinite(den_t) || den_t <= 0
    disp('Tube-side density invalid in PH UAF')
    return
end
if ~isfinite(cpW_t) || cpW_t <= 0
    disp('Tube-side Cp invalid in PH UAF')
    return
end
if ~isfinite(cp_t) || cp_t <= 0
    disp('Tube-side cp_t invalid in PH UAF')
    return
end
if ~isfinite(dyn_vis_t) || dyn_vis_t <= 0
    disp('Tube-side dynamic viscosity invalid in PH UAF')
    return
end
if ~isfinite(Th_t) || Th_t <= 0
    disp('Tube-side thermal conductivity invalid in PH UAF')
    return
end

kvis_t = dyn_vis_t/den_t; %#ok<NASGU>

At_t  = (pi*(tube_ID^2))/4;
Atp_t = (No_tub*At_t)/PH.nopass_t;

if ~isfinite(At_t) || At_t <= 0 || ~isfinite(Atp_t) || Atp_t <= 0
    disp('Tube-side area invalid in PH UAF')
    return
end

Gt_t  = (mw/Atp_t);
Ut_t  = Gt_t/den_t;
Ren_t = (Ut_t*den_t*tube_ID)/dyn_vis_t;
Pr_t  = (cp_t*dyn_vis_t)/Th_t;

if ~isfinite(Ren_t) || Ren_t <= 0
    disp('Tube-side Reynolds number invalid in PH UAF')
    return
end
if ~isfinite(Pr_t) || Pr_t <= 0
    disp('Tube-side Prandtl number invalid in PH UAF')
    return
end

% Original friction-factor form retained
logTerm = 3.64*log10(Ren_t) - 3.28;
if ~isfinite(logTerm) || abs(logTerm) < epsx
    disp('Tube-side friction factor term invalid in PH UAF')
    return
end

f_t = logTerm^(-2);

den_nu = 1.07 + (12.7*((f_t/2)^(1/2))) * ((Pr_t^(2/3)) - 1);
if ~isfinite(den_nu) || abs(den_nu) < epsx
    disp('Tube-side Nusselt denominator invalid in PH UAF')
    return
end

NUs_t = ((f_t/2)*Ren_t*Pr_t) / den_nu;
hi_t_turb = (NUs_t*Th_t)/tube_ID;

if ~isfinite(NUs_t) || NUs_t < 0
    disp('Tube-side Nusselt invalid in PH UAF')
    return
end
if ~isfinite(hi_t_turb) || hi_t_turb <= 0
    disp('Tube-side HTC invalid in PH UAF')
    return
end

%% ================== Shell side HTC calculation ==================
Di_s = PH.shell_ID;
ls   = (PH.tube_length/17);
Dotl = 0.25;
Pn   = 0.0238;
Pt   = Pn;

den_she  = density_oil(Toil_av);
cp_she   = Cp_sf(Toil_av);
Kvis_she = Kin_vis(Toil_av);
Th_she   = Ther_con(Toil_av);

dyn_vis_she = Kvis_she * den_she;

if ~isfinite(Di_s) || Di_s <= 0
    disp('Shell-side diameter invalid in PH UAF')
    return
end
if ~isfinite(ls) || ls <= 0
    disp('Shell-side baffle spacing invalid in PH UAF')
    return
end
if ~isfinite(den_she) || den_she <= 0
    disp('Shell-side density invalid in PH UAF')
    return
end
if ~isfinite(cp_she) || cp_she <= 0
    disp('Shell-side Cp invalid in PH UAF')
    return
end
if ~isfinite(Kvis_she) || Kvis_she <= 0
    disp('Shell-side kinematic viscosity invalid in PH UAF')
    return
end
if ~isfinite(Th_she) || Th_she <= 0
    disp('Shell-side thermal conductivity invalid in PH UAF')
    return
end
if ~isfinite(dyn_vis_she) || dyn_vis_she <= 0
    disp('Shell-side dynamic viscosity invalid in PH UAF')
    return
end

%% BELL Delaware method
sm = ls*(Di_s - Dotl + (((Dotl - tube_OD)/Pn) * (Pt - tube_OD)));

if ~isfinite(sm) || sm <= 0
    disp('Shell-side flow area sm invalid in PH UAF')
    return
end

Re_s = (tube_OD*mo)/(dyn_vis_she*sm);
if ~isfinite(Re_s) || Re_s <= 0
    disp('Shell-side Reynolds number invalid in PH UAF')
    return
end

j1 = 0.185*(Re_s^(-0.324));
Cs = cp_she;

ho_she = j1*Cs*(mo/sm)*(Th_she/(Cs*dyn_vis_she));

if ~isfinite(j1) || j1 <= 0
    disp('Shell-side j-factor invalid in PH UAF')
    return
end
if ~isfinite(ho_she) || ho_she <= 0
    disp('Shell-side HTC invalid in PH UAF')
    return
end

%% ================== Overall HTC calculation ==================
wallTerm = (ro_t*log(ro_t/ri_t))/(Therma);

if ~isfinite(wallTerm) || wallTerm < 0
    disp('Wall term invalid in PH UAF')
    return
end

denU = (1/ho_she) + ((1/hi_t_turb)*(tube_OD/tube_ID)) + wallTerm;

if ~isfinite(denU) || denU <= 0
    disp('Overall HTC denominator invalid in PH UAF')
    return
end

U = 1/denU;

if ~isreal(U)
    disp('U imaginary in PH UAF')
    U = real(U);
end

if ~isfinite(U) || U < 0
    U = 0;
end

%% ================== Correction factor of PH ==================
denR = (Two - Twi);
denS = (Toi - Twi);

if abs(denR) < epsx || abs(denS) < epsx
    disp('F denominator near zero in PH UAF')
    F = 0;
else
    Rr = (Toi - Too)/denR;
    Ss = denR/denS;

    % Keep original warning style, but do not pause
    if Rr == 0
        disp('Rr value should not be zero in PH UAF, kindly check in the code')
    end
    if Rr < 0 || Ss < 0
        disp('Rr or Ss contain negative number in PH UAF, Complex value may come')
    end

    if ~isfinite(Rr) || ~isfinite(Ss)
        disp('Rr or Ss invalid in PH UAF')
        F = 0;
    else
        rootTerm = sqrt((Rr^2)+1);

        a1 = (1 - Ss);
        a2 = (1 - (Rr*Ss));

        F_d1 = 2 - (Ss*(Rr + 1 - rootTerm));
        F_d2 = 2 - (Ss*(Rr + 1 + rootTerm));

        validF = true;

        if a1 <= 0 || a2 <= 0
            validF = false;
            disp('Invalid log argument in num_F of PH')
        end
        if F_d1 <= 0 || F_d2 <= 0
            validF = false;
            disp('Invalid log argument in Deno_F of PH')
        end
        if abs(Rr - 1) < epsx
            validF = false;
            disp('Rr close to 1, F singular in PH')
        end

        if validF
            num_F = rootTerm * log((1-Ss)/(1-(Rr*Ss)));
            Deno_F = (Rr-1) * log(F_d1/F_d2);

            if ~isfinite(num_F) || ~isreal(num_F)
                disp('num_F invalid in PH UAF')
                validF = false;
            end
            if ~isfinite(Deno_F) || abs(Deno_F) < epsx || ~isreal(Deno_F)
                disp('Deno_F invalid in PH UAF')
                validF = false;
            end

            if validF
                F = num_F / Deno_F;
            else
                F = 0;
            end
        else
            F = 0;
        end
    end
end

if ~isreal(F)
    disp('F imaginary number, Kindly check the input for UAF_PH_fun')
    F = real(F);
end

if ~isfinite(F) || isnan(F)
    F = 0;
end

if F > 1
    F = 1;
elseif F < 0
    F = 0;
end

%% Final UAF
UAF = U*Area*F;
UAF = UAF*1e-3;

if ~isreal(UAF) || ~isfinite(UAF)
    disp('PH Corrected')
    UAF = 0;
end

end