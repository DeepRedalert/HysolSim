
% % This file sets parameters of graphics 
% 
% set(0,'DefaultLineLineWidth', 5)           % Set Line thickness 
% set(0,'DefaultaxesLineWidth', 5)          %  Set Axes thickness
% set(0,'DefaultLineMarkerSize',10)        %  Set Marker size 
% 
% %  Set font size and type 
% 
% set(0,'DefaultaxesFontSize', 25)           
% set(0,'DefaultTextFontSize', 25) 
% set(0,'DefaultaxesFontName', 'arial') 
% 

% ---------- Global Graphics Settings ----------

% Line appearance
set(0,'DefaultLineLineWidth',6)          % balanced thickness
set(groot,'DefaultLineMarkerSize',10)

% Axes appearance
set(groot,'DefaultAxesLineWidth',4)        % crisp axes
set(groot,'DefaultAxesFontSize',40)
set(groot,'DefaultAxesFontName','Arial')
set(groot,'DefaultAxesFontWeight','bold')    % bold labels/ticks
set(groot,'DefaultAxesBox','on')             % box around plot
set(groot,'DefaultAxesTickDir','out')        % ticks outside
set(groot,'DefaultAxesTickLength',[0.02 0.02])

% Text appearance
set(groot,'DefaultTextFontSize',40)
set(groot,'DefaultTextFontName','Arial')
set(groot,'DefaultTextFontWeight','bold')

% Legend appearance
set(groot,'DefaultLegendFontSize',40)
set(groot,'DefaultLegendFontWeight','bold')
set(groot,'DefaultLegendBox','on')

% Grid appearance
set(groot,'DefaultAxesXGrid','on')
set(groot,'DefaultAxesYGrid','on')
set(groot,'DefaultAxesGridLineStyle','-')
set(groot,'DefaultAxesGridAlpha',0.35)

% Figure rendering (important for crisp output)
set(groot,'DefaultFigureRenderer','painters')

% Figure background
set(groot,'DefaultFigureColor','white')
