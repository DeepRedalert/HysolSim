function D2=Plot_hotSU_oil_only(Mode,Add_path,Type)
Mode;
global Type iter_scf

if Type==0
    load Day2_over_Oil_Const.mat
elseif Type==1
   load Day2_over_Oil_step.mat
elseif Type==2
    load Day2_over_Oil_Real.mat
elseif Type==3
    load Day2_over_Oil_Quad.mat
end

% set(0,'DefaultLineLineWidth',4)
% set(0,'DefaultLineMarkerSize',10)
% set(0,'DefaultAxesFontSize',18);
% set(0,'DefaultTextFontSize',20);

Solar_axis=round(iter_scf/60);

Solar_time=0:1:(Solar_axis-1);

SetGraphics;
if Type==0
    cd iMAGE/Type0/Day2_oilonly/
elseif Type==1
    cd iMAGE/Type1/Day2_oilonly/
elseif Type==2
    cd iMAGE/Type2/Day2_oilonly/
elseif Type==3
    cd iMAGE/Type3/Day2_oilonly/
end


figure(31)
figure1=figure(31);
axes1 = axes('Parent',figure1); % Create axes
plot(Solar_time/60,lfr_I_sec(:,1:Solar_axis))
legend('Solar radiation','fontsize',40)
%xlim([0 9])
xlabel('Time (Hrs)','FontWeight','bold')
ylabel('w/m^2','FontWeight','bold')
ylim([0 900])
if Type==0
    title('Constant radiation','FontWeight','bold')
elseif Type==1
    title('Step change radiation','FontWeight','bold')
elseif Type==2
    title('Real-time radiation','FontWeight','bold')
elseif Type==3
    title('Quadratic radiation','FontWeight','bold')
end
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(31).jpg');

figure(32)
figure1=figure(32);
axes1 = axes('Parent',figure1); % Create axes
plot(Xaxis(:,1:end),TW_in_HX,'-.b')
xlabel('Time (Hrs)','FontWeight','bold')
ylabel('Temperature ^oC','FontWeight','bold')
grid on
%xlim([0 9])
hx = legend('$T_{W,i,HX}$','Location','southeast','fontsize',40);
set(hx,'Interpreter','latex')
title('Temperature profile of water in HX','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(32).jpg');


figure(33)
figure1=figure(33);
axes1 = axes('Parent',figure1); % Create axes
plot(Xaxis,OP.SCF(15,1:end),'b','LineWidth',6)
hold on
plot(Xaxis,OP.HT_Temp(:,1:end),'g','LineWidth',6)
hold on
plot(Xa.X_SH,OP.SH(1,1:end-1),'k','LineWidth',6)
hold on
plot(XA.X_SG,OP.SG_temp,'m','LineWidth',6)
hold on
plot(Xa.X_PH,OP.PH(2,1:end-1),'r','LineWidth',6)
hold on
plot(Xaxis,OP.LT_Temp,'c','LineWidth',6)
hold off
grid on
%xlim([0 9])
hx=legend('$T_{(o,o,PTC)}$','$T_{(o,o,HT)}$','$T_{(o,o,SH)}$','$T_{(o,o,SG)}$','$T_{(o,o,PH)}$','$T_{(o,o,LT)}$','Location','southeast','fontsize',40);
set(hx,'Interpreter','latex')
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('Temperature ^oC','FontWeight','bold');
title('Output Oil Temprature profile','FontWeight','bold')
text(Xa.X_SH(1),OP.SH(1,1),'\bf \leftarrow SH connected 2nd day','FontSize',20)
text(Xa.X_PH(1),OP.PH(2,1),'\bf \leftarrow PH connected 2nd day','FontSize',20)
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(33).jpg');


figure(34)
figure1=figure(34);
axes1 = axes('Parent',figure1); % Create axes
plot(Xa.X_SH,OP.sh_tsout,'b','LineWidth',6)
hold on
plot(XA.X_SG,OP.SGTw(1:end-1),'g','LineWidth',6)
hold on
plot(Xa.X_PH,OP.ph_twout,'r','LineWidth',6)         %see graph
hold off
grid on; %xlim([0 9]);
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('Temperature ^oC','FontWeight','bold');
hx=legend('$T_{(st,o,SH)}$','$T_{(w,SG)}$','$T_{(w,o,PH)}$','Location','southeast','fontsize',40);
set(hx,'Interpreter','latex')
title('Water/Steam outlet temperature profile','FontWeight','bold')
text(Xa.X_SH(1),OP.sh_tsout(1),'\bf \leftarrow SH connected 2nd day','FontSize',20)
text(XA.X_SG(1),OP.SGTw(1),'\bf \leftarrow SG connected 2nd day','FontSize',20)
text(Xa.X_PH(1),OP.ph_twout(1),'\bf \leftarrow PH connected 2nd day','FontSize',20)
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(34).jpg');


figure(35)
figure1=figure(35);
axes1 = axes('Parent',figure1); % Create axes
plot(Xaxis,OP.SCF(1,1:end),'m','LineWidth',6)
hold on
plot(Xaxis,OP.SCF(8,1:end),'b','LineWidth',6)
hold on
plot(Xaxis,OP.SCF(15,1:end),'g','LineWidth',6)
hold off
grid on; %xlim([0 9]);
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('Temperature ^oC','FontWeight','bold');
hx=legend('T(o,o,33m)','T(o,o,264m)','T(o,o,500m)','Location','southeast','fontsize',40);
set(hx,'Interpreter','latex')
title('PTC oil outlet temperature profile','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(35).jpg');


figure(36)
figure1=figure(36);
axes1 = axes('Parent',figure1); % Create axes
plot(XA.X_SG,OP.SG_pressure)
xlabel('Time (Hrs)','FontWeight','bold')
ylabel('bar','FontWeight','bold')
grid on; %xlim([0 9]);
ylim([0 50])
title('Pressure Profiles','FontWeight','bold')
hx = legend('$P_{SG}$','fontsize',40);
set(hx,'Interpreter','latex')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(36).jpg');



figure(37)      %see graph
figure1=figure(37);
axes1 = axes('Parent',figure1); 
plot(Xaxis,POW.ms_SG)%SG.msgen
xlabel('Time (Hrs)','FontWeight','bold')
ylabel('kg/s','FontWeight','bold')
grid on; %xlim([0 9]);
title('Flowrate of steam Profile','FontWeight','bold')
hx = legend('$\dot{m}_{(st,o,SG)}$','fontsize',40);
set(hx,'Interpreter','latex')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(37).jpg');


figure(38)
figure1=figure(38);
axes1 = axes('Parent',figure1); 
plot(Xax.POW/3600,POWeT_pos_pow.powgen)
xlabel('Time(Hrs)','FontWeight','bold')
ylabel('MWe','FontWeight','bold')
legend('Electric Power','fontsize',40)
grid on; %xlim([0 9]);
title('Power Generation Electrical','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(38).jpg');


figure(39)
figure1=figure(39);
axes1 = axes('Parent',figure1); % Create axes
plot(XA.X_SG,OP.SG_temp,'m','LineWidth',6)
grid on; %xlim([0 9]);
ylim([0 300])
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('Temperature ^oC','FontWeight','bold');
title('SG Output Oil Temprature profile and SG pressure','FontWeight','bold')
hold on
yyaxis right
plot(XA.X_SG,OP.SG_pressure,'b','LineWidth',6)
ylabel('SG Pressure (bar)','FontWeight','bold');
hold off
hx=legend('$T_{(o,o,SG)}$','$P_{SG}$','Location','southeast','fontsize',40);
set(hx,'Interpreter','latex', 'fontsize', 40)
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
ylim([0 50])
saveas(gcf,'figure(39).jpg');



figure(40)
figure1=figure(40);
axes1 = axes('Parent',figure1); % Create axes
plot1=plot(Xaxis,OP.LT_Temp(1:end),'c','LineWidth',6);
ylabel('Temperature ^oC','FontWeight','bold')
ylim([0 300])
hold on
yyaxis right
plot2=plot(Xaxis(:,1:end),TW_in_HX,'b','LineWidth',6);
ylabel('Temperature ^oC','FontWeight','bold')
hold off
xlabel('Time (Hrs)','FontWeight','bold')
grid on; %xlim([0 9]);
hx = legend('$T_{(o,o,LT)}$','$T_{W,i,HX}$','Location','southeast','fontsize',40);
set(hx,'Interpreter','latex', 'fontsize', 40)
title('LT oil outlet temp & HX water inlet temp','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(40).jpg');


figure(41)
figure1=figure(41);
axes1 = axes('Parent',figure1); 
plot(Xa.X_SH,OP.SHU)
hold on
plot(XA.X_SG,OP.SGU,'m','LineWidth',6)
hold on
plot(Xa.X_PH,OP.PHU,'r','LineWidth',6)
hold off
grid on; %xlim([0 9]);
xlabel('Time (Hrs)','FontWeight','bold');
ylabel('W/(m^2 K)','FontWeight','bold');
hx=legend('$U_{SH}$','$U_{SG}$','$U_{PH}$','Location','northeast','fontsize',40);
set(hx,'Interpreter','latex')
title('Heat transfer coefficient','FontWeight','bold')
set(axes1,'XTick',[0 1 2 3 4 5 6 7 8 9],'XTickLabel',{'8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM'});
set(gcf,'units','normalized','outerposition',[0 0 1 1])
saveas(gcf,'figure(41).jpg');


D2=1;
cd(Add_path)
end