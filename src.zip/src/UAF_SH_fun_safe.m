function [UAF,hi_t_turb,ho_sh,F,U]=UAF_SH_fun_safe(mo,Toi,Too,mw,Tsi,Tso,Pres)
%% Superheater HTC (SAFE, behavior-preserving)
% Same physics/correlations as original code.
% Only adds numerical protection to avoid NaN/Inf/imaginary values.

global SH cycle Day F_SH %#ok<NUSED>

% Small number for safe division/log checks
epsx = 1e-12;

% Default outputs
UAF = 0;
hi_t_turb = 0;
ho_sh = 0;
F = 0;
U = 0;

%% Basic input checks
if ~isfinite(mo) || ~isfinite(Toi) || ~isfinite(Too) || ~isfinite(mw) || ...
   ~isfinite(Tsi) || ~isfinite(Tso) || ~isfinite(Pres)
    disp('Invalid input in UAF_SH_fun_safe')
    return
end

if Tsi > Tso
    disp('SH steam out temp lower than steam in temp')
end

if ~isreal(Tsi)
    disp('Tsi contain imaginary in fun UAF_SH_fun_safe')
    Tsi = real(Tsi);
end
if ~isreal(Tso)
    disp('Tso contain imaginary in fun UAF_SH_fun_safe')
    Tso = real(Tso);
end
if isnan(Tsi)
    disp('Tsi contain NAN in fun UAF_SH_fun_safe')
    return
end
if isnan(Tso)
    disp('Tso contain NAN in fun UAF_SH_fun_safe')
    return
end

Ts_av   = (Tsi + Tso)/2;
Toil_av = (Toi + Too)/2;

%% Geometry
tube_ID = SH.tube_ID;
ri_t    = tube_ID/2;
tube_OD = SH.tube_OD;
ro_t    = tube_OD/2;
L_t     = SH.tube_length;
No_tub  = SH.No_tubes;
SH.nopass_t = 2;

Area   = pi*tube_OD*L_t*(No_tub*2);
Therma = 49;

% Geometry validation
if tube_ID <= 0 || tube_OD <= 0 || L_t <= 0 || No_tub <= 0 || ...
   ri_t <= 0 || ro_t <= 0 || tube_OD <= tube_ID || Area <= 0
    disp('Invalid SH geometry in UAF_SH_fun_safe')
    return
end

%% Tube side HTC calculation: Petukhov & Kirillov correlation
Pres = round(Pres,3);

% Steam/water properties
den_t     = XSteam('rho_pT',Pres,Ts_av);
cpW_t     = XSteam('Cp_pT',Pres,Ts_av);
dyn_vis_t = XSteam('my_pT',Pres,Ts_av);
Th_t      = XSteam('tc_pT',Pres,Ts_av);

% Fallback if primary property call fails
if ~isfinite(cpW_t) || ~isfinite(den_t) || ~isfinite(Th_t)
    cpW_t = XSteam('CpV_p',Pres);
    den_t = XSteam('rhoV_p',Pres);
    Th_t  = XSteam('tcV_p',Pres);
end

% If viscosity failed, try keeping function alive with small positive value
if ~isfinite(dyn_vis_t) || dyn_vis_t <= 0
    disp('Dynamic viscosity invalid in SH UAF')
    dyn_vis_t = epsx;
end

if ~isfinite(cpW_t) || cpW_t <= 0
    disp('Sp. Heat capacity invalid in SH UAF')
    return
end
if ~isfinite(den_t) || den_t <= 0
    disp('Density invalid in SH UAF')
    return
end
if ~isfinite(Th_t) || Th_t <= 0
    disp('Thermal conductivity invalid in SH UAF')
    return
end

cp_t = cpW_t * 1000;
if ~isfinite(cp_t) || cp_t <= 0
    disp('cp_t invalid in SH UAF')
    return
end

kvis_t = dyn_vis_t / den_t; %#ok<NASGU>

At_t  = (pi*(tube_ID^2))/4;
Atp_t = (No_tub*At_t)/SH.nopass_t;

if At_t <= 0 || Atp_t <= 0
    disp('Tube flow area invalid in SH UAF')
    return
end

Gt_t  = mw / Atp_t;
Ut_t  = Gt_t / den_t;
Ren_t = (Ut_t*den_t*tube_ID) / dyn_vis_t;
Pr_t  = (cp_t*dyn_vis_t) / Th_t;

if ~isfinite(Ren_t) || Ren_t <= 0
    disp('Reynolds number invalid on tube side in SH UAF')
    return
end
if ~isfinite(Pr_t) || Pr_t <= 0
    disp('Prandtl number invalid on tube side in SH UAF')
    return
end

% Original turbulent correlation retained
logArg = 3.64*log10(Ren_t) - 3.28;
if ~isfinite(logArg) || abs(logArg) < epsx
    disp('Tube-side friction factor term invalid in SH UAF')
    return
end

f_t = logArg^(-2);

den_nu = 1.07 + (12.7*((f_t/2)^(1/2))) * ((Pr_t^(2/3)) - 1);
if ~isfinite(den_nu) || abs(den_nu) < epsx
    disp('Tube-side Nusselt denominator invalid in SH UAF')
    return
end

NUs_t = ((f_t/2)*Ren_t*Pr_t) / den_nu;
hi_t_turb = (NUs_t*Th_t) / tube_ID;

if ~isfinite(hi_t_turb) || hi_t_turb <= 0
    disp('Tube-side HTC invalid in SH UAF')
    return
end

%% Shell side HTC calculation
Di_s = SH.shell_ID;
ls   = (SH.tube_length/13);
Dotl = 0.3;
Pn   = 0.0238;
Pt   = Pn;

den_sh     = density_oil(Toil_av);
cp_sh      = Cp_sf(Toil_av);
Kvis_sh    = Kin_vis(Toil_av);
Th_sh      = Ther_con(Toil_av);
dyn_vis_sh = Kvis_sh * den_sh;

if ~isfinite(den_sh) || den_sh <= 0
    disp('Shell-side density invalid in SH UAF')
    return
end
if ~isfinite(cp_sh) || cp_sh <= 0
    disp('Shell-side cp invalid in SH UAF')
    return
end
if ~isfinite(Kvis_sh) || Kvis_sh <= 0
    disp('Shell-side kinematic viscosity invalid in SH UAF')
    return
end
if ~isfinite(Th_sh) || Th_sh <= 0
    disp('Shell-side thermal conductivity invalid in SH UAF')
    return
end
if ~isfinite(dyn_vis_sh) || dyn_vis_sh <= 0
    disp('Shell-side dynamic viscosity invalid in SH UAF')
    return
end

%% BELL Delaware method
sm = ls*(Di_s - Dotl + (((Dotl - tube_OD)/Pn) * (Pt - tube_OD)));

if ~isfinite(sm) || sm <= 0
    disp('Shell-side flow area Sm invalid in SH UAF')
    return
end

Re_s = (tube_OD*mo) / (dyn_vis_sh*sm);
if ~isfinite(Re_s) || Re_s <= 0
    disp('Shell-side Reynolds number invalid in SH UAF')
    return
end

j1 = 0.185*(Re_s^(-0.324));
Cs = cp_sh;

ho_sh = j1 * Cs * (mo/sm) * (Th_sh/(Cs*dyn_vis_sh));

if ~isfinite(ho_sh) || ho_sh <= 0
    disp('Shell-side HTC invalid in SH UAF')
    return
end

%% Overall HTC calculation by Delaware method
wallTerm = (ro_t*log(ro_t/ri_t))/Therma;

denU = ((ro_t/ri_t)*(1/hi_t_turb)) + (1/ho_sh) + wallTerm;

if ~isfinite(denU) || denU <= 0
    disp('U denominator invalid in SH UAF')
    return
end

U = 1/denU;

if ~isreal(U)
    disp('U of SH contain imaginary no')
    U = real(U);
end
if isnan(U) || ~isfinite(U)
    disp('U of SH contain NAN')
    return
end

%% Correction factor of SH
denR = (Tso - Tsi);
denS = (Toi - Tsi);

if abs(denR) < epsx || abs(denS) < epsx
    disp('F denominator near zero in SH UAF')
    F = 0;
else
    Rr = (Toi - Too) / denR;
    Ss = (Tso - Tsi) / denS;

    if ~isfinite(Rr) || ~isfinite(Ss)
        disp('Rr or Ss invalid in SH UAF')
        F = 0;
    else
        rootTerm = sqrt((Rr^2) + 1);

        a1 = (1 - Ss);
        a2 = (1 - (Rr*Ss));

        F_d1 = 2 - (Ss*(Rr + 1 - rootTerm));
        F_d2 = 2 - (Ss*(Rr + 1 + rootTerm));

        validF = true;

        if a1 <= 0 || a2 <= 0
            validF = false;
            disp('Invalid log argument in num_F of SH')
        end

        if F_d1 <= 0 || F_d2 <= 0
            validF = false;
            disp('Invalid log argument in Deno_F of SH')
        end

        if abs(Rr - 1) < epsx
            validF = false;
            disp('Rr close to 1, F singular in SH')
        end

        if validF
            num_F  = rootTerm * log(a1/a2);
            Deno_F = (Rr - 1) * log(F_d1/F_d2);

            if ~isfinite(num_F) || ~isreal(num_F)
                disp('num_F of SH contain imaginary no')
                validF = false;
            end

            if ~isfinite(Deno_F) || abs(Deno_F) < epsx || ~isreal(Deno_F)
                disp('Deno_F of SH invalid')
                validF = false;
            end

            if validF
                F = num_F / Deno_F;
            else
                F = 0;
            end
        else
            F = 0;
        end
    end
end

if ~isreal(F)
    disp('F of SH contain imaginary no')
    F = real(F);
end
if isnan(F) || ~isfinite(F)
    disp('HTC of SH contain NAN')
    F = 0;
end

if F > 1
    F = 1;
elseif F < 0
    F = 0;
end

if U < 0
    U = 0;
end

%% Final UAF
UAF = U*Area*F;
UAF = UAF*1e-3;

if ~isreal(UAF) || isnan(UAF) || ~isfinite(UAF)
    disp('SH Corrected')
    UAF = 0;
end

end